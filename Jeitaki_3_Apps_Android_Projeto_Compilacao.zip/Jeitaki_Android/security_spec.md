# JEITAKI Security Specification (Phase 0 — Payload-First Security TDD)

## 1. Data Invariants
1. **Default Deny**: All paths not explicitly matched are denied for read and write.
2. **PII Isolation**: User private contact info (`email`, `phone`, `lgpdConsent`) is stored exclusively in `/user_private/{userId}` and is readable/writable only by `isOwner(userId)` or `isAdmin()`.
3. **Professional Approval Gate**: Unapproved `professional_profiles` (`status != 'approved'`) cannot be read or listed by the public; they are accessible only to their owner (`resource.data.userId == request.auth.uid`) or `isAdmin()`. Furthermore, a professional cannot self-approve (`status` on create must be `'pending'`, and non-admin updates cannot change `status` to `'approved'`).
4. **Anti-Self-Review & Completed Service Requirement**: A `Review` can only be created by an authenticated, verified client (`clientId == request.auth.uid`), where `clientId != professionalUserId`, and `rating` is an integer/number between 1 and 5.
5. **Immutable Audit Logs**: `/audit_logs/{logId}` can only be created by `isAdmin()` and can never be updated or deleted.
6. **Bootstrapped Admin Verification**: `isAdmin()` requires `request.auth != null && request.auth.token.email_verified == true` and either matches the bootstrapped owner email (`ianmatheus1599@gmail.com`) or exists in `/admins/$(request.auth.uid)`.

## 2. The "Dirty Dozen" Payloads (Rejected with PERMISSION_DENIED)
1. **Shadow Field Injection on Profile**: `{ uid: "u1", displayName: "João", role: "client", isSuperAdmin: true }` -> Rejected by `.keys().hasOnly(...)`.
2. **Privilege Escalation on Profile Creation**: `{ uid: "u1", displayName: "João", role: "admin", ... }` by non-admin -> Rejected because `role` must be `'client'` or `'professional'` unless `isAdmin()`.
3. **Self-Approved Professional Creation**: `{ id: "p1", userId: "u1", status: "approved", ... }` by non-admin -> Rejected because `status == 'pending'` is required for non-admin creation.
4. **Cross-Professional Profile Tampering**: Professional A attempts to update Professional B's document -> Rejected because `existing().userId == request.auth.uid` fails.
5. **Unverified Email Admin Spoof**: Token has `email: "ianmatheus1599@gmail.com"` with `email_verified: false` -> Rejected by `request.auth.token.email_verified == true`.
6. **PII Scraping Attack**: User A attempts `get(/user_private/userB)` -> Rejected by `isOwner(userId) || isAdmin()`.
7. **Self-Review Attack**: Professional creates review where `clientId == professionalUserId` -> Rejected by `incoming().clientId != incoming().professionalUserId`.
8. **Out-of-Bounds Rating**: Review with `rating: 10` or `rating: 0` -> Rejected by `incoming().rating >= 1 && incoming().rating <= 5`.
9. **Terminal Service Request Tampering**: Updating a `service_requests` document after `existing().status == 'cancelada'` by non-admin -> Rejected by terminal state lock.
10. **Denial-of-Wallet 1MB String Injection**: Sending a 50,000-char `description` to `service_requests` -> Rejected by `incoming().description.size() <= 1000`.
11. **Audit Log Deletion/Modification**: Admin attempts to `delete` or `update` `/audit_logs/log1` -> Rejected by `allow update, delete: if false;`.
12. **Unauthorized Public Listing of Pending Requests**: Client attempts blanket `list` on `/service_requests` without filtering by `clientId == request.auth.uid` or `professionalUserId == request.auth.uid` -> Rejected by Query Enforcer on `resource.data`.
