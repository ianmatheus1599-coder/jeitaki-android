import { Category, City, PlatformSettings } from '../types/jeitaki';
import heroBannerImg from '../assets/images/hero_jeitaki_services_1793930029201.jpg';
import ctaBannerImg from '../assets/images/banner_profissional_cta_1793930030240.jpg';

export const HERO_BANNER_IMAGE = heroBannerImg;
export const CTA_BANNER_IMAGE = ctaBannerImg;

const NOW = '2026-11-05T12:00:00.000Z';

export const INITIAL_CITIES: City[] = [
  {
    id: 'breu-branco-pa',
    name: 'Breu Branco',
    state: 'PA',
    country: 'Brasil',
    slug: 'breu-branco-pa',
    isActive: true,
    neighborhoods: [
      'Centro',
      'Bela Vista',
      'Novo Horizonte',
      'Liberdade',
      'Santa Catarina',
      'Vila Permanente',
      'Nova Breu',
      'Castanheira',
      'Conquista',
      'Pioneiro',
      'Zona Rural / Vicinais',
    ],
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'tucurui-pa',
    name: 'Tucuruí',
    state: 'PA',
    country: 'Brasil',
    slug: 'tucurui-pa',
    isActive: false,
    neighborhoods: [
      'Centro',
      'Vila Permanente',
      'Nova Tucuruí',
      'Bela Vista',
      'Jardim Paraíso',
      'Getat',
      'Santa Mônica',
    ],
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'goianesia-do-para-pa',
    name: 'Goianésia do Pará',
    state: 'PA',
    country: 'Brasil',
    slug: 'goianesia-do-para-pa',
    isActive: false,
    neighborhoods: [
      'Centro',
      'Colegial',
      'Boa Vista',
      'Santa Luzia',
      'Novo Brasil',
    ],
    createdAt: NOW,
    updatedAt: NOW,
  },
];

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'eletricista',
    name: 'Eletricista',
    slug: 'eletricista',
    icon: 'Zap',
    description: 'Instalações elétricas, quadro de distribuição, disjuntores, tomadas, iluminação e manutenção preventiva.',
    isActive: true,
    order: 1,
    searchCount: 0,
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'pedreiro',
    name: 'Pedreiro',
    slug: 'pedreiro',
    icon: 'Hammer',
    description: 'Construção, alvenaria, reboco, contrapiso, assentamento de pisos, revestimentos e pequenas reformas.',
    isActive: true,
    order: 2,
    searchCount: 0,
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'encanador',
    name: 'Encanador',
    slug: 'encanador',
    icon: 'Droplets',
    description: 'Detecção e reparo de vazamentos, desentupimento, instalação de caixas d’água, torneiras e tubulações.',
    isActive: true,
    order: 3,
    searchCount: 0,
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'diarista',
    name: 'Diarista',
    slug: 'diarista',
    icon: 'Sparkles',
    description: 'Limpeza residencial, comercial, faxina pós-obra, organização de ambientes e conservação.',
    isActive: true,
    order: 4,
    searchCount: 0,
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'refrigeracao-e-ar-condicionado',
    name: 'Refrigeração e ar-condicionado',
    slug: 'refrigeracao-e-ar-condicionado',
    icon: 'Snowflake',
    description: 'Instalação, higienização, recarga de gás e manutenção de ar-condicionado split, geladeiras e freezers.',
    isActive: true,
    order: 5,
    searchCount: 0,
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'tecnico-de-cameras-e-alarmes',
    name: 'Técnico de câmeras e alarmes',
    slug: 'tecnico-de-cameras-e-alarmes',
    icon: 'ShieldCheck',
    description: 'CFTV, câmeras Wi-Fi e IP, cercas elétricas, alarmes residenciais, interfones e portões eletrônicos.',
    isActive: true,
    order: 6,
    searchCount: 0,
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'pintor',
    name: 'Pintor',
    slug: 'pintor',
    icon: 'Paintbrush',
    description: 'Pintura interna e externa, emassamento, texturas, impermeabilização e acabamento em madeira ou metal.',
    isActive: true,
    order: 7,
    searchCount: 0,
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'mecanico',
    name: 'Mecânico',
    slug: 'mecanico',
    icon: 'Wrench',
    description: 'Revisão automotiva e de motocicletas, freios, suspensão, troca de óleo, bateria e socorro mecânico.',
    isActive: true,
    order: 8,
    searchCount: 0,
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'montador-de-moveis',
    name: 'Montador de móveis',
    slug: 'montador-de-moveis',
    icon: 'Package',
    description: 'Montagem, desmontagem para mudança, regulagem de portas, instalação de painéis de TV e armários.',
    isActive: true,
    order: 9,
    searchCount: 0,
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'jardineiro',
    name: 'Jardineiro',
    slug: 'jardineiro',
    icon: 'Trees',
    description: 'Corte de grama, poda de árvores, limpeza de quintais e lotes, adubação e paisagismo residencial.',
    isActive: true,
    order: 10,
    searchCount: 0,
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'tecnico-de-informatica',
    name: 'Técnico de informática',
    slug: 'tecnico-de-informatica',
    icon: 'Laptop',
    description: 'Formatação de computadores e notebooks, remoção de vírus, upgrade de SSD, redes Wi-Fi e impressoras.',
    isActive: true,
    order: 11,
    searchCount: 0,
    createdAt: NOW,
    updatedAt: NOW,
  },
  {
    id: 'servicos-gerais',
    name: 'Serviços gerais',
    slug: 'servicos-gerais',
    icon: 'Briefcase',
    description: 'Pequenos reparos domésticos, marido de aluguel, instalação de suportes, cortinas, prateleiras e ajuda geral.',
    isActive: true,
    order: 12,
    searchCount: 0,
    createdAt: NOW,
    updatedAt: NOW,
  },
];

export const INITIAL_PLATFORM_SETTINGS: PlatformSettings = {
  id: 'main',
  heroTitle: 'O que você precisa resolver hoje?',
  heroSubtitle: 'Encontre profissionais da sua cidade em poucos cliques.',
  bannerTitle: 'Trabalha por conta própria em Breu Branco?',
  bannerSubtitle: 'Cadastre seu perfil gratuitamente no JEITAKI, divulgue seus serviços para moradores da região e receba pedidos de orçamento direto no seu WhatsApp.',
  bannerActive: true,
  monetizationEnabled: false,
  highlightPlanPrice: 'R$ 19,90/mês',
  termsContent: `1. OBJETO DA PLATAFORMA
O JEITAKI ("Precisou? Tem quem resolva!") é um catálogo e marketplace local que aproxima moradores de Breu Branco - PA (e futuras cidades habilitadas) de prestadores de serviços autônomos e pequenos negócios locais.

2. PAPEL DE INTERMEDIAÇÃO E ISENÇÃO DE GARANTIA
O JEITAKI atua exclusivamente como facilitador de contato inicial e divulgação de perfis profissionais. A negociação de valores, prazos, forma de pagamento e execução do serviço ocorre diretamente entre o cliente e o profissional (inclusive via WhatsApp). O JEITAKI não emprega os prestadores listados e não garante a qualidade, pontualidade ou resultado de todos os profissionais, embora mantenha ferramentas de moderação, verificação cadastral e avaliações reais da comunidade.

3. CADASTRO E VERACIDADE DAS INFORMAÇÕES
Clientes e profissionais comprometem-se a fornecer informações verdadeiras e atualizadas. Todo perfil profissional passa por análise administrativa antes de ser exibido publicamente na busca.

4. AVALIAÇÕES E CONDUTA
As avaliações refletem a experiência real de moradores após serviços concluídos. É vedada a criação de avaliações falsas, autoavaliações, comentários ofensivos ou manipulação de notas, sob pena de suspensão do perfil.

5. GRATUIDADE E PLANOS FUTUROS
O acesso para moradores e o Plano Básico para profissionais são gratuitos. Caso recursos opcionais de destaque patrocinado sejam disponibilizados futuramente, nenhuma cobrança será ativada sem prévia contratação e autorização expressa do profissional.`,
  privacyContent: `1. COMPROMISSO COM A LGPD (LEI Nº 13.709/2018)
O JEITAKI respeita a sua privacidade e protege seus dados pessoais em conformidade com a Lei Geral de Proteção de Dados Pessoais (LGPD).

2. DADOS COLETADOS E FINALIDADE
- Visitantes: podem pesquisar categorias e perfis públicos sem necessidade de cadastro.
- Clientes: ao solicitar orçamento ou criar conta, coletamos nome, telefone/WhatsApp, bairro e descrição da necessidade exclusivamente para viabilizar o atendimento pelo profissional escolhido.
- Profissionais: coletamos nome, telefone/WhatsApp comercial, categorias, bairros atendidos e fotos de portfólio. O telefone de contato público só é exibido mediante consentimento expresso no cadastro.

3. ISOLAMENTO DE DADOS PRIVADOS
Documentos pessoais sensíveis nunca são publicados. E-mails e dados privados de conta ficam isolados em coleção protegida por regras rigorosas de acesso (Row/Document Level Security), acessíveis apenas ao próprio titular e à administração autorizada.

4. COMPARTILHAMENTO PELO WHATSAPP
Ao clicar em abrir conversa no WhatsApp após registrar uma solicitação, o aplicativo apenas prepara a mensagem com os dados que você concordou em compartilhar para envio voluntário no seu aplicativo WhatsApp.

5. DIREITOS DO TITULAR E EXCLUSÃO DE DADOS
Você pode editar seus dados a qualquer momento em "Minha Conta" ou solicitar a exclusão completa da sua conta e dados pessoais através da página "Suporte e Denúncias" (opção Solicitação LGPD).`,
  updatedAt: NOW,
};

export const DEMO_TEST_PROFESSIONAL = {
  id: 'prof-demo-breu-branco',
  userId: 'demo-test-user',
  name: '[PERFIL FICTÍCIO DE TESTE] Raimundo Oliveira',
  commercialName: '[DEMO TESTE] Oliveira Elétrica & Climatização',
  slug: 'demo-oliveira-eletrica-breu-branco',
  cityId: 'breu-branco-pa',
  cityName: 'Breu Branco',
  neighborhoods: ['Centro', 'Bela Vista', 'Novo Horizonte', 'Vila Permanente'],
  categoryIds: ['eletricista', 'refrigeracao-e-ar-condicionado'],
  categoryNames: ['Eletricista', 'Refrigeração e ar-condicionado'],
  servicesOffered: [
    'Instalação de Ar-Condicionado Split',
    'Revisão de Quadro de Disjuntores',
    'Padrão de Entrada Equatorial',
  ],
  description:
    'ATENÇÃO: Este é um perfil fictício claramente identificado, disponível exclusivamente quando o Modo de Teste é ativado para validar o fluxo de orçamento, QR Code e abertura do WhatsApp em Breu Branco.',
  workingHours: 'Segunda a Sábado, das 07h30 às 18h00',
  attendanceTypes: ['domiciliar', 'estabelecimento'] as ('domiciliar' | 'estabelecimento')[],
  startingPrice: 80,
  whatsappPhone: '5594991000000',
  publicContactConsent: true,
  status: 'approved' as const,
  verificationNote: 'Perfil fictício identificado apenas para ambiente de testes.',
  documentVerified: true,
  isAvailable: true,
  isDemo: true,
  featuredPlan: 'free' as const,
  ratingAvg: 0,
  ratingCount: 0,
  completedJobsCount: 0,
  viewsCount: 0,
  whatsappClicksCount: 0,
  createdAt: NOW,
  updatedAt: NOW,
};

