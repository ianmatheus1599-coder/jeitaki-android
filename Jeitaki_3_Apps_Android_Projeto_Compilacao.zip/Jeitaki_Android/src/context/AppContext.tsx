import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  User,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  auth,
  BOOTSTRAPPED_ADMIN_EMAIL,
  db,
  googleProvider,
  handleFirestoreError,
} from '../lib/firebase';
import {
  AuditLog,
  Category,
  City,
  OperationType,
  PlatformSettings,
  ProfessionalProfile,
  ProfessionalStatus,
  Report,
  Review,
  ServiceRequest,
  ServiceRequestStatus,
  UserPrivate,
  UserProfile,
} from '../types/jeitaki';
import {
  DEMO_TEST_PROFESSIONAL,
  INITIAL_CATEGORIES,
  INITIAL_CITIES,
  INITIAL_PLATFORM_SETTINGS,
} from '../data/initialData';
import { generateSlug, validateReviewSubmission } from '../utils/jeitakiLogic';
import { IS_ANDROID_CONTAINER } from '../appVariant';

interface AppContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  userPrivate: UserPrivate | null;
  isAdmin: boolean;
  authReady: boolean;
  selectedCityId: string;
  setSelectedCityId: (cityId: string) => void;
  selectedCity: City;
  cities: City[];
  categories: Category[];
  professionals: ProfessionalProfile[];
  myProfessionalProfile: ProfessionalProfile | null;
  serviceRequests: ServiceRequest[];
  reviews: Review[];
  reports: Report[];
  auditLogs: AuditLog[];
  platformSettings: PlatformSettings;
  includeDemoProfiles: boolean;
  setIncludeDemoProfiles: (val: boolean) => void;
  // Auth
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (params: {
    name: string;
    email: string;
    password: string;
    phone: string;
    neighborhood: string;
  }) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  updateMyAccount: (params: {
    displayName: string;
    phone: string;
    neighborhood: string;
  }) => Promise<void>;
  // Professional
  saveProfessionalProfile: (
    data: Omit<
      ProfessionalProfile,
      | 'id'
      | 'userId'
      | 'slug'
      | 'status'
      | 'featuredPlan'
      | 'ratingAvg'
      | 'ratingCount'
      | 'completedJobsCount'
      | 'viewsCount'
      | 'whatsappClicksCount'
      | 'createdAt'
      | 'updatedAt'
    >
  ) => Promise<ProfessionalProfile>;
  toggleProfessionalAvailability: (isAvailable: boolean) => Promise<void>;
  incrementProfileView: (profId: string) => Promise<void>;
  // Service Requests
  createServiceRequest: (params: {
    professional: ProfessionalProfile;
    serviceTitle: string;
    description: string;
    neighborhood: string;
    preferredDate?: string;
    clientName: string;
    clientPhone: string;
    photoUrls?: string[];
    consentShared: boolean;
  }) => Promise<ServiceRequest>;
  markWhatsAppClicked: (requestId: string, profId: string) => Promise<void>;
  updateServiceRequestStatus: (
    requestId: string,
    status: ServiceRequestStatus,
    confirmCompletion?: boolean
  ) => Promise<void>;
  // Reviews & Reports
  submitReview: (params: {
    requestId: string;
    rating: number;
    comment: string;
  }) => Promise<void>;
  createReport: (params: {
    targetType: Report['targetType'];
    targetId: string;
    reason: string;
    details: string;
    reporterName?: string;
    reporterContact?: string;
  }) => Promise<void>;
  // Admin Operations
  adminSeedInitialData: () => Promise<void>;
  adminCreateDemoProfessional: () => Promise<void>;
  adminRemoveDemoProfessionals: () => Promise<void>;
  adminUpdateProfessionalStatus: (
    profId: string,
    status: ProfessionalStatus,
    verificationNote?: string,
    documentVerified?: boolean
  ) => Promise<void>;
  adminSaveCategory: (cat: Partial<Category> & { name: string; icon: string; description: string }) => Promise<void>;
  adminSaveCity: (city: Partial<City> & { name: string; state: string; neighborhoods: string[] }) => Promise<void>;
  adminSavePlatformSettings: (settings: PlatformSettings) => Promise<void>;
  adminUpdateReportStatus: (reportId: string, status: Report['status']) => Promise<void>;
  adminModerateReview: (reviewId: string, status: Review['status']) => Promise<void>;
  // Image compression helper
  compressImageFile: (file: File) => Promise<string>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [userPrivate, setUserPrivate] = useState<UserPrivate | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [authReady, setAuthReady] = useState(false);

  const [cities, setCities] = useState<City[]>(INITIAL_CITIES);
  const [selectedCityId, setSelectedCityId] = useState<string>('breu-branco-pa');
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [professionals, setProfessionals] = useState<ProfessionalProfile[]>([]);
  const [myProfessionalProfile, setMyProfessionalProfile] =
    useState<ProfessionalProfile | null>(null);
  const [serviceRequests, setServiceRequests] = useState<ServiceRequest[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [platformSettings, setPlatformSettings] = useState<PlatformSettings>(
    INITIAL_PLATFORM_SETTINGS
  );
  const [includeDemoProfiles, setIncludeDemoProfiles] = useState<boolean>(false);

  // 1. Auth Listener & Profile Bootstrap
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (!user) {
        setUserProfile(null);
        setUserPrivate(null);
        setIsAdmin(false);
        setMyProfessionalProfile(null);
        setServiceRequests([]);
        setReports([]);
        setAuditLogs([]);
        setAuthReady(true);
        return;
      }

      try {
        const isBootstrappedAdmin =
          user.email === BOOTSTRAPPED_ADMIN_EMAIL && user.emailVerified;
        let adminDocExists = false;
        if (!isBootstrappedAdmin && user.emailVerified) {
          try {
            const adminSnap = await getDoc(doc(db, 'admins', user.uid));
            adminDocExists = adminSnap.exists();
          } catch {
            adminDocExists = false;
          }
        }
        const computedAdmin = Boolean(isBootstrappedAdmin || adminDocExists);
        setIsAdmin(computedAdmin);

        if (user.emailVerified) {
          const profRef = doc(db, 'profiles', user.uid);
          const privRef = doc(db, 'user_private', user.uid);
          const [profSnap, privSnap] = await Promise.all([
            getDoc(profRef),
            getDoc(privRef),
          ]);
          const now = new Date().toISOString();

          if (!profSnap.exists()) {
            const newProfile: UserProfile = {
              uid: user.uid,
              displayName:
                (user.displayName || user.email?.split('@')[0] || 'Morador').slice(
                  0,
                  90
                ),
              role: computedAdmin ? 'admin' : 'client',
              cityId: 'breu-branco-pa',
              neighborhood: 'Centro',
              createdAt: now,
              updatedAt: now,
            };
            await setDoc(profRef, newProfile);
            setUserProfile(newProfile);
          } else {
            setUserProfile(profSnap.data() as UserProfile);
          }

          if (!privSnap.exists()) {
            const newPriv: UserPrivate = {
              uid: user.uid,
              email: (user.email || 'sem-email@jeitaki.local').slice(0, 150),
              phone: '',
              lgpdConsent: true,
              createdAt: now,
              updatedAt: now,
            };
            await setDoc(privRef, newPriv);
            setUserPrivate(newPriv);
          } else {
            setUserPrivate(privSnap.data() as UserPrivate);
          }
        }
      } catch (err) {
        console.warn('Erro ao sincronizar perfil inicial:', err);
      } finally {
        setAuthReady(true);
      }
    });
    return () => unsub();
  }, []);

  // 2. Public Collections Listeners (Cities, Categories, Approved Professionals, Reviews, Platform Settings)
  useEffect(() => {
    const citiesQuery = isAdmin
      ? collection(db, 'cities')
      : query(collection(db, 'cities'), where('isActive', '==', true));

    const unsubCities = onSnapshot(
      citiesQuery,
      (snap) => {
        if (!snap.empty) {
          const loaded = snap.docs.map((d) => d.data() as City);
          // Merge with initial cities so inactive expansion cities remain visible to admin
          const mergedMap = new Map<string, City>();
          INITIAL_CITIES.forEach((c) => mergedMap.set(c.id, c));
          loaded.forEach((c) => mergedMap.set(c.id, c));
          setCities(Array.from(mergedMap.values()));
        }
      },
      (err) => {
        console.warn('Cities fallback active:', err.message);
      }
    );

    const catQuery = isAdmin
      ? collection(db, 'categories')
      : query(collection(db, 'categories'), where('isActive', '==', true));

    const unsubCategories = onSnapshot(
      catQuery,
      (snap) => {
        if (!snap.empty) {
          const loaded = snap.docs.map((d) => d.data() as Category);
          const mergedMap = new Map<string, Category>();
          INITIAL_CATEGORIES.forEach((c) => mergedMap.set(c.id, c));
          loaded.forEach((c) => mergedMap.set(c.id, c));
          setCategories(
            Array.from(mergedMap.values()).sort((a, b) => a.order - b.order)
          );
        }
      },
      (err) => {
        console.warn('Categories fallback active:', err.message);
      }
    );

    const profsQuery = isAdmin
      ? collection(db, 'professional_profiles')
      : query(
          collection(db, 'professional_profiles'),
          where('status', '==', 'approved')
        );

    const unsubProfs = onSnapshot(
      profsQuery,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as ProfessionalProfile);
        setProfessionals(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'professional_profiles');
      }
    );

    const reviewsQuery = isAdmin
      ? collection(db, 'reviews')
      : query(collection(db, 'reviews'), where('status', '==', 'published'));

    const unsubReviews = onSnapshot(
      reviewsQuery,
      (snap) => {
        setReviews(
          snap.docs
            .map((d) => d.data() as Review)
            .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
        );
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'reviews');
      }
    );

    const unsubSettings = onSnapshot(
      doc(db, 'platform_settings', 'main'),
      (snap) => {
        if (snap.exists()) {
          setPlatformSettings(snap.data() as PlatformSettings);
        }
      },
      () => {
        // Keep default settings if not created yet
      }
    );

    return () => {
      unsubCities();
      unsubCategories();
      unsubProfs();
      unsubReviews();
      unsubSettings();
    };
  }, [isAdmin]);

  // 3. Authenticated User Listeners (My Professional Profile, Service Requests, Admin Reports & Logs)
  useEffect(() => {
    if (!authReady || !currentUser || !currentUser.emailVerified) {
      return;
    }

    // Listen to own professional profile (even if pending/rejected)
    const myProfQuery = query(
      collection(db, 'professional_profiles'),
      where('userId', '==', currentUser.uid)
    );
    const unsubMyProf = onSnapshot(
      myProfQuery,
      (snap) => {
        if (!snap.empty) {
          setMyProfessionalProfile(snap.docs[0].data() as ProfessionalProfile);
        } else {
          setMyProfessionalProfile(null);
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'professional_profiles');
      }
    );

    // Service requests: if admin, fetch all; otherwise fetch client's and professional's requests
    let unsubClientReqs = () => {};
    let unsubProfReqs = () => {};

    if (isAdmin) {
      unsubClientReqs = onSnapshot(
        collection(db, 'service_requests'),
        (snap) => {
          setServiceRequests(
            snap.docs
              .map((d) => d.data() as ServiceRequest)
              .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
          );
        },
        (err) =>
          handleFirestoreError(err, OperationType.LIST, 'service_requests')
      );
    } else {
      let clientDocs: ServiceRequest[] = [];
      let profDocs: ServiceRequest[] = [];
      const mergeRequests = () => {
        const map = new Map<string, ServiceRequest>();
        clientDocs.forEach((r) => map.set(r.id, r));
        profDocs.forEach((r) => map.set(r.id, r));
        setServiceRequests(
          Array.from(map.values()).sort((a, b) =>
            b.createdAt.localeCompare(a.createdAt)
          )
        );
      };

      unsubClientReqs = onSnapshot(
        query(
          collection(db, 'service_requests'),
          where('clientId', '==', currentUser.uid)
        ),
        (snap) => {
          clientDocs = snap.docs.map((d) => d.data() as ServiceRequest);
          mergeRequests();
        },
        (err) =>
          handleFirestoreError(err, OperationType.LIST, 'service_requests')
      );

      unsubProfReqs = onSnapshot(
        query(
          collection(db, 'service_requests'),
          where('professionalUserId', '==', currentUser.uid)
        ),
        (snap) => {
          profDocs = snap.docs.map((d) => d.data() as ServiceRequest);
          mergeRequests();
        },
        (err) =>
          handleFirestoreError(err, OperationType.LIST, 'service_requests')
      );
    }

    let unsubReports = () => {};
    let unsubLogs = () => {};

    if (isAdmin) {
      unsubReports = onSnapshot(
        collection(db, 'reports'),
        (snap) => {
          setReports(
            snap.docs
              .map((d) => d.data() as Report)
              .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
          );
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'reports')
      );

      unsubLogs = onSnapshot(
        collection(db, 'audit_logs'),
        (snap) => {
          setAuditLogs(
            snap.docs
              .map((d) => d.data() as AuditLog)
              .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
          );
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'audit_logs')
      );
    }

    return () => {
      unsubMyProf();
      unsubClientReqs();
      unsubProfReqs();
      unsubReports();
      unsubLogs();
    };
  }, [authReady, currentUser, isAdmin]);

  const selectedCity =
    cities.find((c) => c.id === selectedCityId) || INITIAL_CITIES[0];

  // Auth Handlers
  const loginWithGoogle = async () => {
    // The Firebase Web popup is not compatible with Android WebView OAuth.
    // Keep the supported e-mail/password flow for Android builds.
    if (IS_ANDROID_CONTAINER) {
      throw new Error('No APK, entre com e-mail e senha. O login Google exige configuração nativa adicional.');
    }
    await signInWithPopup(auth, googleProvider);
  };

  const loginWithEmail = async (email: string, pass: string) => {
    await signInWithEmailAndPassword(auth, email.trim(), pass);
  };

  const registerWithEmail = async (params: {
    name: string;
    email: string;
    password: string;
    phone: string;
    neighborhood: string;
  }) => {
    const cred = await createUserWithEmailAndPassword(
      auth,
      params.email.trim(),
      params.password
    );
    await updateProfile(cred.user, { displayName: params.name.trim() });
    try {
      await sendEmailVerification(cred.user);
    } catch {
      // Optional verification email sent
    }
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email.trim());
  };

  const logout = async () => {
    await signOut(auth);
  };

  const updateMyAccount = async (params: {
    displayName: string;
    phone: string;
    neighborhood: string;
  }) => {
    if (!currentUser) throw new Error('Faça login primeiro.');
    const now = new Date().toISOString();
    const profRef = doc(db, 'profiles', currentUser.uid);
    const privRef = doc(db, 'user_private', currentUser.uid);

    const updatedProfile: UserProfile = {
      uid: currentUser.uid,
      displayName: params.displayName.trim().slice(0, 90),
      role: userProfile?.role || 'client',
      cityId: selectedCityId,
      neighborhood: params.neighborhood.trim().slice(0, 75),
      createdAt: userProfile?.createdAt || now,
      updatedAt: now,
    };

    const updatedPrivate: UserPrivate = {
      uid: currentUser.uid,
      email: (currentUser.email || userPrivate?.email || '').slice(0, 150),
      phone: params.phone.trim().slice(0, 25),
      lgpdConsent: true,
      createdAt: userPrivate?.createdAt || now,
      updatedAt: now,
    };

    try {
      await setDoc(profRef, updatedProfile);
      await setDoc(privRef, updatedPrivate);
      setUserProfile(updatedProfile);
      setUserPrivate(updatedPrivate);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `profiles/${currentUser.uid}`);
    }
  };

  // Image Compression Helper (client-side canvas resize <= 800px, JPEG 0.72)
  const compressImageFile = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
      if (!allowedTypes.includes(file.type)) {
        reject(
          new Error('Formato inválido. Envie apenas imagens JPG, PNG ou WebP.')
        );
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        reject(new Error('A imagem deve ter no máximo 5 MB.'));
        return;
      }

      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Falha ao ler arquivo de imagem.'));
      reader.onload = () => {
        const img = new Image();
        img.onerror = () => reject(new Error('Imagem corrompida ou inválida.'));
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const maxDim = 640;
          let { width, height } = img;
          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            reject(new Error('Erro ao processar imagem.'));
            return;
          }
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
          if (dataUrl.length > 140000) {
            resolve(canvas.toDataURL('image/jpeg', 0.5));
          } else {
            resolve(dataUrl);
          }
        };
        img.src = reader.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  // Save or Update Professional Profile
  const saveProfessionalProfile = async (
    data: Omit<
      ProfessionalProfile,
      | 'id'
      | 'userId'
      | 'slug'
      | 'status'
      | 'featuredPlan'
      | 'ratingAvg'
      | 'ratingCount'
      | 'completedJobsCount'
      | 'viewsCount'
      | 'whatsappClicksCount'
      | 'createdAt'
      | 'updatedAt'
    >
  ): Promise<ProfessionalProfile> => {
    if (!currentUser || !currentUser.emailVerified) {
      throw new Error(
        'Entre com uma conta verificada (Google ou e-mail confirmado) para cadastrar seu perfil profissional.'
      );
    }

    const now = new Date().toISOString();
    const profId = myProfessionalProfile?.id || `prof-${currentUser.uid.slice(0, 20)}`;
    const slug = `${generateSlug(data.commercialName || data.name)}-${currentUser.uid
      .slice(0, 5)
      .toLowerCase()}`;

    const record: ProfessionalProfile = {
      id: profId,
      userId: currentUser.uid,
      name: data.name.trim().slice(0, 95),
      ...(data.commercialName?.trim()
        ? { commercialName: data.commercialName.trim().slice(0, 95) }
        : {}),
      slug,
      cityId: data.cityId,
      cityName: data.cityName,
      neighborhoods: data.neighborhoods.slice(0, 25),
      categoryIds: data.categoryIds.slice(0, 10),
      categoryNames: data.categoryNames.slice(0, 10),
      servicesOffered: data.servicesOffered.slice(0, 20),
      description: data.description.trim().slice(0, 1150),
      ...(data.photoUrl ? { photoUrl: data.photoUrl } : {}),
      ...(data.portfolioUrls && data.portfolioUrls.length > 0
        ? { portfolioUrls: data.portfolioUrls.slice(0, 6) }
        : {}),
      workingHours: data.workingHours.trim().slice(0, 150),
      attendanceTypes: data.attendanceTypes.slice(0, 3),
      ...(typeof data.startingPrice === 'number' && data.startingPrice > 0
        ? { startingPrice: data.startingPrice }
        : {}),
      whatsappPhone: data.whatsappPhone.replace(/\D/g, '').slice(0, 18),
      publicContactConsent: Boolean(data.publicContactConsent),
      status: myProfessionalProfile?.status === 'suspended' ? 'suspended' : 'pending',
      isAvailable: data.isAvailable,
      isDemo: false,
      featuredPlan: myProfessionalProfile?.featuredPlan || 'free',
      ratingAvg: myProfessionalProfile?.ratingAvg || 0,
      ratingCount: myProfessionalProfile?.ratingCount || 0,
      completedJobsCount: myProfessionalProfile?.completedJobsCount || 0,
      viewsCount: myProfessionalProfile?.viewsCount || 0,
      whatsappClicksCount: myProfessionalProfile?.whatsappClicksCount || 0,
      createdAt: myProfessionalProfile?.createdAt || now,
      updatedAt: now,
    };

    try {
      await setDoc(doc(db, 'professional_profiles', profId), record);
      // Also update user role to professional if currently client
      if (userProfile && userProfile.role === 'client') {
        const updatedUser: UserProfile = {
          ...userProfile,
          role: 'professional',
          updatedAt: now,
        };
        await setDoc(doc(db, 'profiles', currentUser.uid), updatedUser);
        setUserProfile(updatedUser);
      }
      return record;
    } catch (err) {
      handleFirestoreError(
        err,
        OperationType.WRITE,
        `professional_profiles/${profId}`
      );
    }
  };

  const toggleProfessionalAvailability = async (isAvailable: boolean) => {
    if (!myProfessionalProfile) return;
    const now = new Date().toISOString();
    try {
      await setDoc(doc(db, 'professional_profiles', myProfessionalProfile.id), {
        ...myProfessionalProfile,
        isAvailable,
        updatedAt: now,
      });
    } catch (err) {
      handleFirestoreError(
        err,
        OperationType.UPDATE,
        `professional_profiles/${myProfessionalProfile.id}`
      );
    }
  };

  const incrementProfileView = async (profId: string) => {
    const target = professionals.find((p) => p.id === profId);
    if (!target) return;
    try {
      await setDoc(doc(db, 'professional_profiles', profId), {
        ...target,
        viewsCount: (target.viewsCount || 0) + 1,
        updatedAt: new Date().toISOString(),
      });
    } catch {
      // Non-critical metric increment
    }
  };

  // Service Request Creation
  const createServiceRequest = async (params: {
    professional: ProfessionalProfile;
    serviceTitle: string;
    description: string;
    neighborhood: string;
    preferredDate?: string;
    clientName: string;
    clientPhone: string;
    photoUrls?: string[];
    consentShared: boolean;
  }): Promise<ServiceRequest> => {
    const now = new Date().toISOString();
    const requestId = `req-${Date.now()}-${Math.random()
      .toString(36)
      .slice(2, 7)}`;
    if (!currentUser || !currentUser.emailVerified) {
      throw new Error('Para solicitar orçamento, entre na sua conta e confirme o e-mail.');
    }
    if (params.professional.status !== 'approved') {
      throw new Error('Este profissional ainda não está aprovado para receber pedidos.');
    }
    const clientId = currentUser.uid;

    const newReq: ServiceRequest = {
      id: requestId,
      clientId,
      clientName: params.clientName.trim().slice(0, 95),
      clientPhone: params.clientPhone.trim().slice(0, 22),
      professionalId: params.professional.id,
      professionalUserId: params.professional.userId,
      professionalName:
        params.professional.commercialName || params.professional.name,
      categoryId: params.professional.categoryIds[0] || 'servicos-gerais',
      serviceTitle: params.serviceTitle.trim().slice(0, 115),
      description: params.description.trim().slice(0, 950),
      cityId: params.professional.cityId,
      cityName: params.professional.cityName,
      neighborhood: params.neighborhood.trim().slice(0, 75),
      ...(params.preferredDate?.trim()
        ? { preferredDate: params.preferredDate.trim().slice(0, 75) }
        : {}),
      ...(params.photoUrls && params.photoUrls.length > 0
        ? { photoUrls: params.photoUrls.slice(0, 3) }
        : {}),
      status: 'nova',
      whatsappClicked: false,
      clientConfirmedCompletion: false,
      professionalConfirmedCompletion: false,
      reviewed: false,
      consentShared: Boolean(params.consentShared),
      lastUpdatedBy: clientId,
      createdAt: now,
      updatedAt: now,
    };

    try {
      await setDoc(doc(db, 'service_requests', requestId), newReq);
      return newReq;
    } catch (err) {
      handleFirestoreError(
        err,
        OperationType.CREATE,
        `service_requests/${requestId}`
      );
    }
  };

  const markWhatsAppClicked = async (requestId: string, profId: string) => {
    const now = new Date().toISOString();
    const targetReq = serviceRequests.find((r) => r.id === requestId);
    if (targetReq && currentUser && currentUser.emailVerified) {
      try {
        await setDoc(doc(db, 'service_requests', requestId), {
          ...targetReq,
          whatsappClicked: true,
          status: targetReq.status === 'nova' ? 'em_contato' : targetReq.status,
          lastUpdatedBy: currentUser.uid,
          updatedAt: now,
        });
      } catch {
        // Ignore if visitor created request without session
      }
    }
    const targetProf = professionals.find((p) => p.id === profId);
    if (targetProf) {
      try {
        await setDoc(doc(db, 'professional_profiles', profId), {
          ...targetProf,
          whatsappClicksCount: (targetProf.whatsappClicksCount || 0) + 1,
          updatedAt: now,
        });
      } catch {
        // Ignore non-critical metric update
      }
    }
  };

  const updateServiceRequestStatus = async (
    requestId: string,
    status: ServiceRequestStatus,
    confirmCompletion = false
  ) => {
    if (!currentUser) throw new Error('Autenticação necessária.');
    const target = serviceRequests.find((r) => r.id === requestId);
    if (!target) throw new Error('Solicitação não localizada.');

    const now = new Date().toISOString();
    const isClient = currentUser.uid === target.clientId;
    const isProf = currentUser.uid === target.professionalUserId;

    const clientConfirmed =
      confirmCompletion && isClient
        ? true
        : target.clientConfirmedCompletion;
    const profConfirmed =
      confirmCompletion && isProf
        ? true
        : target.professionalConfirmedCompletion;

    const finalStatus: ServiceRequestStatus =
      (clientConfirmed && profConfirmed) || (isAdmin && status === 'concluida')
        ? 'concluida'
        : status;

    const updated: ServiceRequest = {
      ...target,
      status: finalStatus,
      clientConfirmedCompletion: clientConfirmed,
      professionalConfirmedCompletion: profConfirmed,
      lastUpdatedBy: currentUser.uid,
      updatedAt: now,
    };

    try {
      await setDoc(doc(db, 'service_requests', requestId), updated);
      if (finalStatus === 'concluida' && target.status !== 'concluida') {
        const prof = professionals.find((p) => p.id === target.professionalId);
        if (prof) {
          await setDoc(doc(db, 'professional_profiles', prof.id), {
            ...prof,
            completedJobsCount: (prof.completedJobsCount || 0) + 1,
            updatedAt: now,
          });
        }
      }
    } catch (err) {
      handleFirestoreError(
        err,
        OperationType.UPDATE,
        `service_requests/${requestId}`
      );
    }
  };

  // Submit Review
  const submitReview = async (params: {
    requestId: string;
    rating: number;
    comment: string;
  }) => {
    if (!currentUser) throw new Error('Faça login para avaliar.');
    const targetReq = serviceRequests.find((r) => r.id === params.requestId);
    const validation = validateReviewSubmission({
      clientId: currentUser.uid,
      professionalUserId: targetReq?.professionalUserId || '',
      request: targetReq,
      existingReviews: reviews,
      rating: params.rating,
      comment: params.comment,
    });

    if (!validation.valid || !targetReq) {
      throw new Error(validation.error || 'Avaliação inválida.');
    }

    const now = new Date().toISOString();
    const reviewId = `rev-${targetReq.id}`;
    const newReview: Review = {
      id: reviewId,
      requestId: targetReq.id,
      clientId: currentUser.uid,
      clientName: userProfile?.displayName || currentUser.displayName || 'Morador',
      professionalId: targetReq.professionalId,
      professionalUserId: targetReq.professionalUserId,
      rating: params.rating,
      comment: params.comment.trim().slice(0, 580),
      status: 'pending',
      createdAt: now,
      updatedAt: now,
    };

    try {
      await setDoc(doc(db, 'reviews', reviewId), newReview);
      await setDoc(doc(db, 'service_requests', targetReq.id), {
        ...targetReq,
        reviewed: true,
        lastUpdatedBy: currentUser.uid,
        updatedAt: now,
      });

      // Avaliações aguardam moderação; métricas só mudam após aprovação administrativa.
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `reviews/${reviewId}`);
    }
  };

  const createReport = async (params: {
    targetType: Report['targetType'];
    targetId: string;
    reason: string;
    details: string;
    reporterName?: string;
    reporterContact?: string;
  }) => {
    const now = new Date().toISOString();
    const reportId = `rep-${Date.now()}-${Math.random()
      .toString(36)
      .slice(2, 6)}`;
    const reporterId =
      currentUser && currentUser.emailVerified ? currentUser.uid : 'visitante';

    const report: Report = {
      id: reportId,
      reporterId,
      ...(params.reporterName?.trim()
        ? { reporterName: params.reporterName.trim().slice(0, 90) }
        : {}),
      ...(params.reporterContact?.trim()
        ? { reporterContact: params.reporterContact.trim().slice(0, 110) }
        : {}),
      targetType: params.targetType,
      targetId: params.targetId.slice(0, 120),
      reason: params.reason.trim().slice(0, 115),
      details: params.details.trim().slice(0, 950),
      status: 'open',
      createdAt: now,
      updatedAt: now,
    };

    try {
      await setDoc(doc(db, 'reports', reportId), report);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `reports/${reportId}`);
    }
  };

  // Admin Operations + Audit Logger
  const logAdminAction = async (
    action: string,
    targetType: string,
    targetId: string,
    details: string
  ) => {
    if (!currentUser || !isAdmin) return;
    const logId = `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const entry: AuditLog = {
      id: logId,
      adminUid: currentUser.uid,
      adminEmail: currentUser.email || BOOTSTRAPPED_ADMIN_EMAIL,
      action: action.slice(0, 110),
      targetType: targetType.slice(0, 60),
      targetId: targetId.slice(0, 120),
      details: details.slice(0, 550),
      createdAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'audit_logs', logId), entry);
  };

  const adminSeedInitialData = async () => {
    if (!isAdmin || !currentUser) {
      throw new Error('Apenas o administrador pode sincronizar a base inicial.');
    }
    try {
      for (const city of INITIAL_CITIES) {
        await setDoc(doc(db, 'cities', city.id), city);
      }
      for (const cat of INITIAL_CATEGORIES) {
        await setDoc(doc(db, 'categories', cat.id), cat);
      }
      await setDoc(
        doc(db, 'platform_settings', 'main'),
        INITIAL_PLATFORM_SETTINGS
      );
      await logAdminAction(
        'seed_initial_data',
        'system',
        'breu-branco-pa',
        'Sincronizou cidades, 12 categorias iniciais e configurações da plataforma no banco.'
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'cities/categories');
    }
  };

  const adminCreateDemoProfessional = async () => {
    if (!isAdmin || !currentUser) return;
    const now = new Date().toISOString();
    const demoId = 'prof-demo-breu-branco';
    const demoProf: ProfessionalProfile = {
      id: demoId,
      userId: currentUser.uid,
      name: '[DEMO TESTE] Raimundo Oliveira',
      commercialName: '[PERFIL FICTÍCIO DE TESTE] Oliveira Elétrica & Clima',
      slug: 'demo-oliveira-eletrica-breu-branco',
      cityId: 'breu-branco-pa',
      cityName: 'Breu Branco',
      neighborhoods: ['Centro', 'Bela Vista', 'Novo Horizonte', 'Vila Permanente'],
      categoryIds: ['eletricista', 'refrigeracao-e-ar-condicionado'],
      categoryNames: ['Eletricista', 'Refrigeração e ar-condicionado'],
      servicesOffered: [
        'Instalação de Ar-Condicionado Split',
        'Revisão de Quadro de Disjuntores',
        'Padrão de Entrada Equatorial',
      ],
      description:
        'ATENÇÃO: Este é um perfil fictício identificado exclusivamente para testes operacionais do fluxo de busca, orçamento e WhatsApp em Breu Branco.',
      workingHours: 'Segunda a Sábado, das 07h30 às 18h00',
      attendanceTypes: ['domiciliar', 'estabelecimento'],
      startingPrice: 80,
      whatsappPhone: '5594991000000',
      publicContactConsent: true,
      status: 'approved',
      verificationNote: 'Perfil de demonstração técnica claramente identificado.',
      documentVerified: true,
      isAvailable: true,
      isDemo: true,
      featuredPlan: 'free',
      ratingAvg: 5,
      ratingCount: 1,
      completedJobsCount: 1,
      viewsCount: 1,
      whatsappClicksCount: 0,
      createdAt: now,
      updatedAt: now,
    };

    try {
      await setDoc(doc(db, 'professional_profiles', demoId), demoProf);
      setIncludeDemoProfiles(true);
      await logAdminAction(
        'create_demo_profile',
        'professional',
        demoId,
        'Criou perfil de demonstração identificado ([DEMO TESTE]) para validação.'
      );
    } catch (err) {
      handleFirestoreError(
        err,
        OperationType.CREATE,
        `professional_profiles/${demoId}`
      );
    }
  };

  const adminRemoveDemoProfessionals = async () => {
    if (!isAdmin) return;
    const demos = professionals.filter((p) => p.isDemo);
    for (const d of demos) {
      await deleteDoc(doc(db, 'professional_profiles', d.id));
    }
    setIncludeDemoProfiles(false);
    await logAdminAction(
      'remove_demo_profiles',
      'professional',
      'all_demos',
      `Removeu ${demos.length} perfil(is) de demonstração do banco.`
    );
  };

  const adminUpdateProfessionalStatus = async (
    profId: string,
    status: ProfessionalStatus,
    verificationNote?: string,
    documentVerified?: boolean
  ) => {
    if (!isAdmin) throw new Error('Acesso restrito ao administrador.');
    const target = professionals.find((p) => p.id === profId);
    if (!target) return;
    const now = new Date().toISOString();
    const updated: ProfessionalProfile = {
      ...target,
      status,
      ...(verificationNote !== undefined
        ? { verificationNote: verificationNote.trim().slice(0, 380) }
        : {}),
      ...(documentVerified !== undefined ? { documentVerified } : {}),
      updatedAt: now,
    };
    try {
      await setDoc(doc(db, 'professional_profiles', profId), updated);
      await logAdminAction(
        `status_${status}`,
        'professional',
        profId,
        `Alterou status do profissional ${target.name} para ${status}.`
      );
    } catch (err) {
      handleFirestoreError(
        err,
        OperationType.UPDATE,
        `professional_profiles/${profId}`
      );
    }
  };

  const adminSaveCategory = async (
    cat: Partial<Category> & { name: string; icon: string; description: string }
  ) => {
    if (!isAdmin) throw new Error('Acesso restrito ao administrador.');
    const now = new Date().toISOString();
    const slug = cat.slug || generateSlug(cat.name);
    const id = cat.id || slug;
    const existing = categories.find((c) => c.id === id);

    const record: Category = {
      id,
      name: cat.name.trim().slice(0, 75),
      slug,
      icon: cat.icon.trim() || 'Briefcase',
      description: cat.description.trim().slice(0, 290),
      isActive: cat.isActive !== undefined ? cat.isActive : true,
      order: cat.order ?? existing?.order ?? categories.length + 1,
      searchCount: existing?.searchCount || 0,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };

    try {
      await setDoc(doc(db, 'categories', id), record);
      await logAdminAction(
        existing ? 'update_category' : 'create_category',
        'category',
        id,
        `Salvou categoria ${record.name} (ativa: ${record.isActive}).`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `categories/${id}`);
    }
  };

  const adminSaveCity = async (
    city: Partial<City> & {
      name: string;
      state: string;
      neighborhoods: string[];
    }
  ) => {
    if (!isAdmin) throw new Error('Acesso restrito ao administrador.');
    const now = new Date().toISOString();
    const slug =
      city.slug || generateSlug(`${city.name}-${city.state}`);
    const id = city.id || slug;
    const existing = cities.find((c) => c.id === id);

    const record: City = {
      id,
      name: city.name.trim().slice(0, 75),
      state: city.state.trim().toUpperCase().slice(0, 5),
      country: 'Brasil',
      slug,
      isActive: city.isActive !== undefined ? city.isActive : true,
      neighborhoods: city.neighborhoods
        .map((n) => n.trim())
        .filter(Boolean)
        .slice(0, 55),
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };

    try {
      await setDoc(doc(db, 'cities', id), record);
      await logAdminAction(
        existing ? 'update_city' : 'create_city',
        'city',
        id,
        `Salvou cidade ${record.name} - ${record.state} (ativa: ${record.isActive}).`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `cities/${id}`);
    }
  };

  const adminSavePlatformSettings = async (settings: PlatformSettings) => {
    if (!isAdmin) throw new Error('Acesso restrito ao administrador.');
    const now = new Date().toISOString();
    const updated: PlatformSettings = {
      ...settings,
      id: 'main',
      updatedAt: now,
    };
    try {
      await setDoc(doc(db, 'platform_settings', 'main'), updated);
      setPlatformSettings(updated);
      await logAdminAction(
        'update_platform_settings',
        'platform_settings',
        'main',
        'Atualizou textos institucionais, banner ou políticas da plataforma.'
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'platform_settings/main');
    }
  };

  const adminUpdateReportStatus = async (
    reportId: string,
    status: Report['status']
  ) => {
    if (!isAdmin) return;
    const target = reports.find((r) => r.id === reportId);
    if (!target) return;
    try {
      await updateDoc(doc(db, 'reports', reportId), {
        status,
        updatedAt: new Date().toISOString(),
      });
      await logAdminAction(
        `report_${status}`,
        'report',
        reportId,
        `Atualizou denúncia/chamado ${reportId} para ${status}.`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `reports/${reportId}`);
    }
  };

  const adminModerateReview = async (
    reviewId: string,
    status: Review['status']
  ) => {
    if (!isAdmin) return;
    const target = reviews.find((r) => r.id === reviewId);
    if (!target) return;
    try {
      await setDoc(doc(db, 'reviews', reviewId), {
        ...target,
        status,
        updatedAt: new Date().toISOString(),
      });
      const allReviews = await getDocs(query(collection(db, 'reviews'), where('professionalId', '==', target.professionalId)));
      const published = allReviews.docs.map(d => d.data() as Review).filter(r => r.status === 'published');
      const average = published.length ? published.reduce((sum, r) => sum + r.rating, 0) / published.length : 0;
      await updateDoc(doc(db, 'professional_profiles', target.professionalId), {
        ratingAvg: Number(average.toFixed(2)),
        ratingCount: published.length,
        updatedAt: new Date().toISOString(),
      });
      await logAdminAction(
        `review_${status}`,
        'review',
        reviewId,
        `Moderou avaliação ${reviewId} para status ${status}.`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `reviews/${reviewId}`);
    }
  };

  const effectiveProfessionals = React.useMemo(() => {
    if (!includeDemoProfiles) return professionals;
    const exists = professionals.some((p) => p.id === DEMO_TEST_PROFESSIONAL.id);
    return exists ? professionals : [...professionals, DEMO_TEST_PROFESSIONAL];
  }, [professionals, includeDemoProfiles]);

  return (
    <AppContext.Provider
      value={{
        currentUser,
        userProfile,
        userPrivate,
        isAdmin,
        authReady,
        selectedCityId,
        setSelectedCityId,
        selectedCity,
        cities,
        categories,
        professionals: effectiveProfessionals,
        myProfessionalProfile,
        serviceRequests,
        reviews,
        reports,
        auditLogs,
        platformSettings,
        includeDemoProfiles,
        setIncludeDemoProfiles,
        loginWithGoogle,
        loginWithEmail,
        registerWithEmail,
        resetPassword,
        logout,
        updateMyAccount,
        saveProfessionalProfile,
        toggleProfessionalAvailability,
        incrementProfileView,
        createServiceRequest,
        markWhatsAppClicked,
        updateServiceRequestStatus,
        submitReview,
        createReport,
        adminSeedInitialData,
        adminCreateDemoProfessional,
        adminRemoveDemoProfessionals,
        adminUpdateProfessionalStatus,
        adminSaveCategory,
        adminSaveCity,
        adminSavePlatformSettings,
        adminUpdateReportStatus,
        adminModerateReview,
        compressImageFile,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp deve ser usado dentro de AppProvider');
  return ctx;
}
