// Build one shared source tree into three independent Android applications.
export type JeitakiAppVariant = 'cliente' | 'profissional' | 'admin';
const value = import.meta.env.VITE_APP_VARIANT;
export const APP_VARIANT: JeitakiAppVariant = value === 'profissional' || value === 'admin' ? value : 'cliente';
export const APP_LABELS: Record<JeitakiAppVariant, string> = {
  cliente: 'Jeitaki Cliente',
  profissional: 'Jeitaki Profissional',
  admin: 'Jeitaki Administrador',
};
import { Capacitor } from '@capacitor/core';
export const IS_ANDROID_CONTAINER = Capacitor.isNativePlatform();
