import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import {
  AlertCircle,
  ArrowRight,
  Check,
  Clock,
  Download,
  Flag,
  MapPin,
  MessageCircle,
  QrCode,
  Search,
  Share2,
  ShieldCheck,
  Star,
  UserCheck,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CategoryIcon, OFFICIAL_BRAND_LOGO } from '../components/CategoryIcon';
import { CTA_BANNER_IMAGE, HERO_BANNER_IMAGE } from '../data/initialData';
import { ProfessionalProfile } from '../types/jeitaki';
import { filterAndSortProfessionals } from '../utils/jeitakiLogic';

// Reusable Professional Card (Zero-Pill Metadata Discipline)
export const ProfessionalCard: React.FC<{
  prof: ProfessionalProfile;
  onRequestQuote: (prof: ProfessionalProfile) => void;
}> = ({ prof, onRequestQuote }) => {
  const attendanceLabel = prof.attendanceTypes
    .map((t) =>
      t === 'domiciliar'
        ? 'Atendimento em domicílio'
        : t === 'remoto'
        ? 'Remoto'
        : 'No estabelecimento'
    )
    .join(' · ');

  return (
    <article className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col justify-between gap-4 hover:border-slate-300 transition-colors">
      <div className="space-y-3">
        {/* Quiet 1-line text kicker (no pills) */}
        <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
          <span className="truncate font-medium text-[#0B4F24]">
            {prof.categoryNames.join(' · ')}
          </span>
          <span className="shrink-0 tabular-nums">
            {prof.isAvailable ? 'Disponível' : 'Agenda pausada'}
          </span>
        </div>

        {prof.isDemo && (
          <p className="text-[11px] font-semibold text-amber-800">
            Perfil fictício identificado para demonstração operacional
          </p>
        )}

        <div className="flex items-start gap-3.5">
          {prof.photoUrl ? (
            <img
              src={prof.photoUrl}
              alt={prof.commercialName || prof.name}
              referrerPolicy="no-referrer"
              className="w-14 h-14 rounded-2xl object-cover border border-slate-200 shrink-0"
            />
          ) : (
            <div className="w-14 h-14 rounded-2xl bg-[#0B4F24] text-[#F59E0B] font-display font-bold text-lg flex items-center justify-center shrink-0">
              {(prof.commercialName || prof.name).slice(0, 2).toUpperCase()}
            </div>
          )}

          <div className="min-w-0 flex-1">
            <Link
              to={`/profissional/${prof.slug}`}
              className="font-display text-base font-bold text-[#0B4F24] hover:text-[#16A34A] transition-colors block truncate"
            >
              {prof.commercialName || prof.name}
            </Link>
            <p className="text-xs text-slate-500 truncate mt-0.5">
              {prof.cityName} · Bairros: {prof.neighborhoods.slice(0, 3).join(', ')}
              {prof.neighborhoods.length > 3
                ? ` +${prof.neighborhoods.length - 3}`
                : ''}
            </p>
            <div className="mt-1 flex items-center gap-2 text-xs text-slate-600 tabular-nums">
              {prof.ratingCount > 0 ? (
                <span className="inline-flex items-center gap-1 font-semibold text-[#0B4F24]">
                  <Star className="w-3.5 h-3.5 text-[#F59E0B] fill-[#F59E0B]" />
                  {prof.ratingAvg.toFixed(1)} ({prof.ratingCount}{' '}
                  {prof.ratingCount === 1 ? 'avaliação' : 'avaliações'})
                </span>
              ) : (
                <span className="text-slate-500">Sem avaliações ainda</span>
              )}
              <span aria-hidden="true">·</span>
              <span>
                {prof.documentVerified
                  ? 'Cadastro verificado'
                  : 'Cadastro aprovado'}
              </span>
            </div>
          </div>
        </div>

        <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
          {prof.description}
        </p>

        <div className="pt-1 text-xs text-slate-500 space-y-1">
          <p className="truncate">
            <strong className="text-slate-700 font-medium">Serviços:</strong>{' '}
            {prof.servicesOffered.join(' · ')}
          </p>
          <p className="truncate">
            {attendanceLabel}
            {typeof prof.startingPrice === 'number' && prof.startingPrice > 0
              ? ` · A partir de R$ ${prof.startingPrice.toFixed(2)}`
              : ''}
          </p>
        </div>
      </div>

      <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2.5">
        <Link
          to={`/profissional/${prof.slug}`}
          className="min-h-[44px] px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-[#0B4F24] hover:bg-slate-50 flex items-center justify-center whitespace-nowrap"
        >
          Ver Perfil
        </Link>
        <button
          type="button"
          disabled={!prof.isAvailable}
          onClick={() => onRequestQuote(prof)}
          className="min-h-[44px] px-3 py-2 rounded-xl bg-[#16A34A] text-white text-xs font-bold hover:bg-[#15803d] transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap disabled:opacity-50"
        >
          <span>Solicitar orçamento</span>
        </button>
      </div>
    </article>
  );
};

// Empty Search Suggestion Component
const CategorySuggestionBox: React.FC<{
  defaultCategoryName?: string;
  neighborhood?: string;
}> = ({ defaultCategoryName = '', neighborhood = '' }) => {
  const { createReport, selectedCity } = useApp();
  const [suggestedCategory, setSuggestedCategory] = useState(
    defaultCategoryName
  );
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [consent, setConsent] = useState(true);
  const [sent, setSent] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!suggestedCategory.trim() || !consent) return;
    setSubmitting(true);
    try {
      await createReport({
        targetType: 'category_suggestion',
        targetId: selectedCity.id,
        reason: `Aviso/Sugestão: ${suggestedCategory.trim()}`,
        details: `Cidade: ${selectedCity.name} | Bairro: ${
          neighborhood || 'Qualquer'
        } | Especialidade solicitada: ${suggestedCategory.trim()}`,
        reporterName: contactName,
        reporterContact: contactPhone,
      });
      setSent(true);
    } finally {
      setSubmitting(false);
    }
  };

  if (sent) {
    return (
      <div className="mt-4 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
        Seu pedido de aviso/sugestão para{' '}
        <strong>{suggestedCategory}</strong> em {selectedCity.name} foi
        registrado com sucesso!
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="mt-5 p-5 rounded-2xl bg-[#F6FAF7] border border-slate-200 max-w-lg mx-auto text-left space-y-3"
    >
      <h4 className="font-display text-sm font-bold text-[#0B4F24]">
        Solicitar aviso ou sugerir profissional / categoria
      </h4>
      <p className="text-xs text-slate-600">
        Deixe o serviço que você procura para priorizarmos o credenciamento de
        profissionais em {selectedCity.name}.
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        <input
          type="text"
          required
          value={suggestedCategory}
          onChange={(e) => setSuggestedCategory(e.target.value)}
          placeholder="Qual serviço ou categoria precisa?"
          className="px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
        />
        <input
          type="text"
          value={contactPhone}
          onChange={(e) => setContactPhone(e.target.value)}
          placeholder="Seu WhatsApp para aviso (opcional)"
          className="px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
        />
      </div>
      <input
        type="text"
        value={contactName}
        onChange={(e) => setContactName(e.target.value)}
        placeholder="Seu nome (opcional)"
        className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
      />
      <label className="flex items-start gap-2 text-[11px] text-slate-600 cursor-pointer">
        <input
          type="checkbox"
          required
          checked={consent}
          onChange={(e) => setConsent(e.target.checked)}
          className="mt-0.5 rounded border-slate-300"
        />
        <span>
          Autorizo o registro desta sugestão e eventual aviso quando houver
          profissionais disponíveis na minha região (LGPD).
        </span>
      </label>
      <button
        type="submit"
        disabled={submitting}
        className="min-h-[40px] px-4 py-2 rounded-xl bg-[#0B4F24] text-white text-xs font-semibold hover:bg-[#0E662F]"
      >
        {submitting ? 'Enviando...' : 'Receber Aviso / Enviar Sugestão'}
      </button>
    </form>
  );
};

// 1. HOME PAGE (/)
export const HomePage: React.FC<{
  onRequestQuote: (prof: ProfessionalProfile) => void;
  onOpenShareQR: () => void;
}> = ({ onRequestQuote, onOpenShareQR }) => {
  const {
    cities,
    selectedCityId,
    setSelectedCityId,
    selectedCity,
    categories,
    professionals,
    platformSettings,
    includeDemoProfiles,
  } = useApp();

  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedHood, setSelectedHood] = useState('todos');
  const [showSuggestions, setShowSuggestions] = useState(false);

  const activeCategories = useMemo(
    () => categories.filter((c) => c.isActive),
    [categories]
  );

  const matchingSuggestions = useMemo(() => {
    if (!searchQuery.trim()) return activeCategories.slice(0, 5);
    const q = searchQuery.toLowerCase();
    return activeCategories
      .filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q)
      )
      .slice(0, 5);
  }, [searchQuery, activeCategories]);

  const approvedProfs = useMemo(
    () =>
      filterAndSortProfessionals(professionals, {
        cityId: selectedCityId,
        includeDemo: includeDemoProfiles,
      }),
    [professionals, selectedCityId, includeDemoProfiles]
  );

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (searchQuery.trim()) params.set('q', searchQuery.trim());
    if (selectedHood !== 'todos') params.set('bairro', selectedHood);
    navigate(`/busca?${params.toString()}`);
  };

  return (
    <div className="space-y-16 pb-8">
      {/* Hero Section */}
      <section className="bg-[#0B4F24] text-white pt-8 pb-12 sm:py-14 border-b border-emerald-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
              {/* Regional trust selector */}
              <div className="flex flex-wrap items-center gap-2 text-xs text-emerald-100">
                <MapPin className="w-4 h-4 text-[#F59E0B] shrink-0" />
                <span>Atendimento local em</span>
                <label htmlFor="hero-city-select" className="sr-only">
                  Cidade selecionada
                </label>
                <select
                  id="hero-city-select"
                  value={selectedCityId}
                  onChange={(e) => setSelectedCityId(e.target.value)}
                  className="bg-emerald-950/90 text-[#F59E0B] font-semibold rounded-lg px-2.5 py-1 border border-emerald-700 focus:outline-none focus:border-[#F59E0B]"
                >
                  {cities
                    .filter((c) => c.isActive)
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} - {c.state}
                      </option>
                    ))}
                </select>
                <span aria-hidden="true">·</span>
                <span className="text-[#F59E0B] font-semibold">
                  Precisou? Tem quem resolva!
                </span>
              </div>

              <div className="space-y-3 max-w-2xl">
                <h1
                  className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-tight text-white"
                  style={{ textWrap: 'balance' }}
                >
                  {platformSettings.heroTitle ||
                    'O que você precisa resolver hoje?'}
                </h1>
                <p className="text-base sm:text-lg text-emerald-100 leading-relaxed">
                  {platformSettings.heroSubtitle ||
                    'Encontre profissionais da sua cidade em poucos cliques.'}
                </p>
              </div>

              {/* Search Bar with Category Suggestions */}
              <form
                onSubmit={handleSearchSubmit}
                className="bg-white p-2 sm:p-2.5 rounded-2xl shadow-lg text-[#0B4F24] relative"
              >
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-center">
                  <div className="sm:col-span-6 lg:col-span-7 relative">
                    <label htmlFor="home-search-input" className="sr-only">
                      Buscar por serviço, categoria ou nome do profissional
                    </label>
                    <div className="flex items-center px-3 py-2.5">
                      <Search className="w-5 h-5 text-slate-400 shrink-0 mr-2.5" />
                      <input
                        id="home-search-input"
                        type="text"
                        value={searchQuery}
                        onFocus={() => setShowSuggestions(true)}
                        onBlur={() =>
                          setTimeout(() => setShowSuggestions(false), 180)
                        }
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Ex: Eletricista, pedreiro, ar-condicionado..."
                        className="w-full text-sm text-[#0B4F24] placeholder:text-slate-400 focus:outline-none"
                      />
                    </div>

                    {showSuggestions && matchingSuggestions.length > 0 && (
                      <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-20">
                        <p className="px-3 py-1 text-[11px] font-semibold text-slate-400">
                          Sugestões de categorias em {selectedCity.name}
                        </p>
                        {matchingSuggestions.map((cat) => (
                          <button
                            key={cat.id}
                            type="button"
                            onMouseDown={() =>
                              navigate(`/categoria/${cat.slug}`)
                            }
                            className="w-full px-3 py-2 text-left text-xs text-[#0B4F24] hover:bg-slate-50 flex items-center justify-between"
                          >
                            <span className="font-medium">{cat.name}</span>
                            <span className="text-slate-400">Ver categoria</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="sm:col-span-3 lg:col-span-3 border-t sm:border-t-0 sm:border-l border-slate-200 px-3 py-2">
                    <label htmlFor="home-hood-select" className="sr-only">
                      Selecionar bairro
                    </label>
                    <select
                      id="home-hood-select"
                      value={selectedHood}
                      onChange={(e) => setSelectedHood(e.target.value)}
                      className="w-full text-xs sm:text-sm text-slate-700 bg-transparent focus:outline-none"
                    >
                      <option value="todos">Todos os bairros</option>
                      {selectedCity.neighborhoods.map((n) => (
                        <option key={n} value={n}>
                          {n}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="sm:col-span-3 lg:col-span-2">
                    <button
                      type="submit"
                      className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-[#16A34A] text-white font-bold text-sm hover:bg-[#15803d] transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap"
                    >
                      <span>Buscar</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </form>

              {/* Quick Popular Categories */}
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-emerald-100">
                <span className="text-[#F59E0B] font-semibold">
                  Mais procurados:
                </span>
                {activeCategories.slice(0, 5).map((cat, idx) => (
                  <React.Fragment key={cat.id}>
                    {idx > 0 && <span aria-hidden="true">·</span>}
                    <Link
                      to={`/categoria/${cat.slug}`}
                      className="hover:text-[#F59E0B] underline underline-offset-4 transition-colors"
                    >
                      {cat.name}
                    </Link>
                  </React.Fragment>
                ))}
              </div>
            </div>

            {/* Right Column Visual Anchor with Official Jeita Aqui Breu Branco Identity */}
            <div className="lg:col-span-5 flex flex-col">
              <div className="relative rounded-2xl overflow-hidden border border-emerald-800/80 bg-emerald-950 h-full min-h-[290px] flex flex-col justify-between">
                <img
                  src={HERO_BANNER_IMAGE}
                  alt="Profissional de manutenção residencial em Breu Branco"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-cover opacity-35"
                />
                <div className="relative z-10 p-6 flex flex-col items-center justify-center flex-1 text-center space-y-3">
                  <div className="bg-white rounded-3xl p-4 shadow-lg border-2 border-[#F59E0B]">
                    <img
                      src={OFFICIAL_BRAND_LOGO}
                      alt="Logo Oficial Jeita Aqui Breu Branco"
                      referrerPolicy="no-referrer"
                      className="w-40 h-40 sm:w-44 sm:h-44 object-contain mx-auto"
                    />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-[#F59E0B]">
                      Comunidade de {selectedCity.name} - {selectedCity.state}
                    </p>
                    <p className="text-xs sm:text-sm font-medium text-emerald-50 mt-0.5 max-w-sm">
                      Orçamento rápido e contato direto pelo WhatsApp sem taxas
                      para moradores.
                    </p>
                  </div>
                  <div className="pt-1 flex flex-wrap items-center justify-center gap-2.5">
                    <Link
                      to="/baixar-app"
                      className="min-h-[40px] px-4 py-2 rounded-xl bg-[#F59E0B] text-[#0B4F24] text-xs font-bold hover:bg-[#fbbf24] transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                    >
                      <Download className="w-4 h-4" />
                      <span>Baixar App / .APK</span>
                    </Link>
                    <button
                      type="button"
                      onClick={onOpenShareQR}
                      className="min-h-[40px] px-3.5 py-2 rounded-xl bg-white/15 text-white border border-white/25 text-xs font-semibold hover:bg-white/25 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                    >
                      <QrCode className="w-4 h-4 text-[#F59E0B]" />
                      <span>QR Code</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-bold text-[#0B4F24]">
              Categorias de Serviços em {selectedCity.name}
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Escolha a especialidade que você precisa para ver os profissionais
              atendendo sua região.
            </p>
          </div>
          <Link
            to="/busca"
            className="text-xs font-semibold text-[#0B4F24] hover:text-[#16A34A] inline-flex items-center gap-1 whitespace-nowrap"
          >
            <span>Explorar todas as categorias</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5">
          {activeCategories.map((cat) => (
            <Link
              key={cat.id}
              to={`/categoria/${cat.slug}`}
              className="group bg-white rounded-2xl border border-slate-200 p-4 hover:border-[#16A34A] transition-colors flex flex-col justify-between gap-3"
            >
              <div className="w-11 h-11 rounded-xl bg-[#F6FAF7] text-[#0B4F24] group-hover:bg-[#0B4F24] group-hover:text-[#F59E0B] transition-colors flex items-center justify-center">
                <CategoryIcon name={cat.icon} className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-display text-sm font-bold text-[#0B4F24]">
                  {cat.name}
                </h3>
                <p className="text-xs text-slate-500 line-clamp-2 mt-1 leading-relaxed">
                  {cat.description}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Approved Professionals Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-bold text-[#0B4F24]">
              Profissionais Aprovados em {selectedCity.name}
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Perfis reais verificados pela administração do JEITAKI.
            </p>
          </div>
          <Link
            to="/busca"
            className="text-xs font-semibold text-[#0B4F24] hover:text-[#16A34A] inline-flex items-center gap-1 whitespace-nowrap"
          >
            <span>Filtrar por bairro ou preço</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {approvedProfs.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {approvedProfs.slice(0, 6).map((prof) => (
              <ProfessionalCard
                key={prof.id}
                prof={prof}
                onRequestQuote={onRequestQuote}
              />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-[#F6FAF7] text-[#0B4F24] flex items-center justify-center mx-auto">
              <UserCheck className="w-6 h-6 text-[#16A34A]" />
            </div>
            <div className="max-w-lg mx-auto space-y-1.5">
              <h3 className="font-display text-base font-bold text-[#0B4F24]">
                Ainda não encontramos profissionais dessa categoria em sua
                região.
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                O JEITAKI não exibe perfis falsos. Os primeiros prestadores de
                serviços reais de {selectedCity.name} - {selectedCity.state}{' '}
                estão sendo credenciados e aprovados pela administração.
              </p>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
              <Link
                to="/seja-profissional"
                className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#16A34A] text-white text-xs font-bold hover:bg-[#15803d] flex items-center gap-2"
              >
                <span>Sou Profissional: Cadastrar Meu Perfil Grátis</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <button
                type="button"
                onClick={onOpenShareQR}
                className="min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-[#0B4F24] hover:bg-slate-50 flex items-center gap-2"
              >
                <QrCode className="w-4 h-4" />
                <span>Convidar Profissionais via QR Code</span>
              </button>
            </div>
          </div>
        )}
      </section>

      {/* How It Works Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        <div>
          <h2 className="font-display text-2xl font-bold text-[#0B4F24]">
            Como funciona o JEITAKI
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Simples, transparente e sem burocracia para quem mora em{' '}
            {selectedCity.name}.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              step: '01. Encontre o profissional',
              desc: 'Pesquise pela categoria ou serviço que precisa no seu bairro sem precisar criar conta para consultar.',
            },
            {
              step: '02. Solicite seu orçamento',
              desc: 'Preencha um pedido rápido descrevendo o serviço e o bairro de atendimento em poucos segundos.',
            },
            {
              step: '03. Combine diretamente',
              desc: 'Abra a conversa direto no WhatsApp do profissional com a mensagem pronta e combine valores e horários.',
            },
            {
              step: '04. Avalie o atendimento',
              desc: 'Após o serviço concluído, deixe sua nota de 1 a 5 estrelas para ajudar outros moradores da cidade.',
            },
          ].map((item) => (
            <div
              key={item.step}
              className="bg-white rounded-2xl border border-slate-200 p-5 space-y-2"
            >
              <h3 className="font-display text-sm font-bold text-[#0B4F24]">
                {item.step}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Banner Inviting Professionals */}
      {platformSettings.bannerActive && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="bg-[#0B4F24] rounded-3xl overflow-hidden border border-slate-800 grid grid-cols-1 lg:grid-cols-12 items-stretch">
            <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-center space-y-4">
              <p className="text-xs font-semibold text-[#F59E0B]">
                Cadastro 100% Gratuito para Prestadores de Serviços
              </p>
              <h2
                className="font-display text-2xl sm:text-3xl font-bold text-white"
                style={{ textWrap: 'balance' }}
              >
                {platformSettings.bannerTitle}
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed max-w-xl">
                {platformSettings.bannerSubtitle}
              </p>
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <Link
                  to="/seja-profissional"
                  className="min-h-[48px] px-6 py-3 rounded-xl bg-[#16A34A] text-white font-bold text-sm hover:bg-[#15803d] transition-colors inline-flex items-center gap-2"
                >
                  <span>Cadastrar Meu Perfil Profissional</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <button
                  type="button"
                  onClick={onOpenShareQR}
                  className="min-h-[48px] px-5 py-3 rounded-xl border border-slate-600 text-white font-semibold text-xs hover:bg-slate-800 transition-colors inline-flex items-center gap-2"
                >
                  <QrCode className="w-4 h-4 text-[#F59E0B]" />
                  <span>Compartilhar Link / QR Code</span>
                </button>
              </div>
            </div>
            <div className="lg:col-span-5 min-h-[220px]">
              <img
                src={CTA_BANNER_IMAGE}
                alt="Prestador de serviços autônomo conferindo pedidos no celular"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </section>
      )}
    </div>
  );
};

// 2. SEARCH PAGE (/busca)
export const SearchPage: React.FC<{
  onRequestQuote: (prof: ProfessionalProfile) => void;
}> = ({ onRequestQuote }) => {
  const {
    cities,
    selectedCityId,
    setSelectedCityId,
    selectedCity,
    categories,
    professionals,
    includeDemoProfiles,
    setIncludeDemoProfiles,
    isAdmin,
  } = useApp();

  const [searchParams] = useSearchParams();
  const [queryText, setQueryText] = useState(searchParams.get('q') || '');
  const [categoryId, setCategoryId] = useState(
    searchParams.get('categoria') || 'todas'
  );
  const [neighborhood, setNeighborhood] = useState(
    searchParams.get('bairro') || 'todos'
  );
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [maxPrice, setMaxPrice] = useState<string>('');
  const [minRating, setMinRating] = useState<string>('0');

  const activeCategories = categories.filter((c) => c.isActive);

  const filteredProfs = useMemo(
    () =>
      filterAndSortProfessionals(professionals, {
        cityId: selectedCityId,
        neighborhood,
        categoryId,
        query: queryText,
        onlyAvailable,
        maxPrice: maxPrice ? Number(maxPrice) : undefined,
        minRating: Number(minRating) > 0 ? Number(minRating) : undefined,
        includeDemo: includeDemoProfiles,
      }),
    [
      professionals,
      selectedCityId,
      neighborhood,
      categoryId,
      queryText,
      onlyAvailable,
      maxPrice,
      minRating,
      includeDemoProfiles,
    ]
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
            Buscar Profissionais em {selectedCity.name} - {selectedCity.state}
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
            Filtre por bairro, categoria, disponibilidade, faixa de preço ou
            avaliação.
          </p>
        </div>

        <label className="inline-flex items-center gap-2 text-xs text-slate-600 bg-white px-3 py-2 rounded-xl border border-slate-200 cursor-pointer">
          <input
            type="checkbox"
            checked={includeDemoProfiles}
            onChange={(e) => setIncludeDemoProfiles(e.target.checked)}
            className="rounded border-slate-300"
          />
          <span>Modo de Teste: Exibir perfil fictício identificado ([DEMO TESTE])</span>
        </label>
      </div>

      {/* Filters Panel */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          <div>
            <label
              htmlFor="search-q"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Nome ou serviço
            </label>
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                id="search-q"
                type="text"
                value={queryText}
                onChange={(e) => setQueryText(e.target.value)}
                placeholder="Ex: disjuntor, vazamento, pintura..."
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:border-[#0B4F24]"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="search-cat"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Categoria
            </label>
            <select
              id="search-cat"
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:border-[#0B4F24]"
            >
              <option value="todas">Todas as categorias</option>
              {activeCategories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="search-city"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Cidade
            </label>
            <select
              id="search-city"
              value={selectedCityId}
              onChange={(e) => {
                setSelectedCityId(e.target.value);
                setNeighborhood('todos');
              }}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:border-[#0B4F24]"
            >
              {cities
                .filter((c) => c.isActive)
                .map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} - {c.state}
                  </option>
                ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="search-hood"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Bairro / Região
            </label>
            <select
              id="search-hood"
              value={neighborhood}
              onChange={(e) => setNeighborhood(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:border-[#0B4F24]"
            >
              <option value="todos">Todos os bairros de {selectedCity.name}</option>
              {selectedCity.neighborhoods.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-4">
            <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={onlyAvailable}
                onChange={(e) => setOnlyAvailable(e.target.checked)}
                className="rounded border-slate-300 text-[#0B4F24]"
              />
              <span>Apenas profissionais disponíveis agora</span>
            </label>

            <div className="flex items-center gap-2">
              <label
                htmlFor="search-max-price"
                className="text-xs font-medium text-slate-700"
              >
                Preço inicial até (R$):
              </label>
              <input
                id="search-max-price"
                type="number"
                min={0}
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                placeholder="Qualquer"
                className="w-24 px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs tabular-nums"
              />
            </div>

            <div className="flex items-center gap-2">
              <label
                htmlFor="search-min-rating"
                className="text-xs font-medium text-slate-700"
              >
                Avaliação mínima:
              </label>
              <select
                id="search-min-rating"
                value={minRating}
                onChange={(e) => setMinRating(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
              >
                <option value="0">Todas</option>
                <option value="4">4.0+ estrelas</option>
                <option value="4.5">4.5+ estrelas</option>
              </select>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              setQueryText('');
              setCategoryId('todas');
              setNeighborhood('todos');
              setOnlyAvailable(false);
              setMaxPrice('');
              setMinRating('0');
            }}
            className="text-xs font-semibold text-slate-500 hover:text-[#0B4F24]"
          >
            Limpar filtros
          </button>
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between text-xs text-slate-600 tabular-nums">
        <span>
          Exibindo <strong>{filteredProfs.length}</strong>{' '}
          {filteredProfs.length === 1
            ? 'profissional aprovado'
            : 'profissionais aprovados'}{' '}
          em {selectedCity.name}
        </span>
      </div>

      {/* Results Grid or Required Empty State */}
      {filteredProfs.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredProfs.map((prof) => (
            <ProfessionalCard
              key={prof.id}
              prof={prof}
              onRequestQuote={onRequestQuote}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
          <p className="font-display text-base font-bold text-[#0B4F24]">
            Ainda não encontramos profissionais dessa categoria em sua região.
          </p>
          <p className="text-xs text-slate-600 mt-1 max-w-md mx-auto">
            Você pode solicitar um aviso para quando um profissional for
            aprovado no seu bairro ou cadastrar seu próprio serviço caso atue na
            área.
          </p>
          <CategorySuggestionBox
            defaultCategoryName={
              categoryId !== 'todas'
                ? categories.find((c) => c.id === categoryId)?.name || ''
                : queryText
            }
            neighborhood={neighborhood !== 'todos' ? neighborhood : ''}
          />
        </div>
      )}
    </div>
  );
};

// 3. CATEGORY PAGE (/categoria/:slug)
export const CategoryPage: React.FC<{
  onRequestQuote: (prof: ProfessionalProfile) => void;
}> = ({ onRequestQuote }) => {
  const { slug } = useParams<{ slug: string }>();
  const {
    categories,
    professionals,
    selectedCityId,
    selectedCity,
    includeDemoProfiles,
  } = useApp();

  const [neighborhood, setNeighborhood] = useState('todos');

  const category = categories.find((c) => c.slug === slug || c.id === slug);

  const profs = useMemo(
    () =>
      filterAndSortProfessionals(professionals, {
        cityId: selectedCityId,
        categoryId: category?.id || slug,
        neighborhood,
        includeDemo: includeDemoProfiles,
      }),
    [professionals, selectedCityId, category, slug, neighborhood, includeDemoProfiles]
  );

  if (!category) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
          Categoria não encontrada
        </h1>
        <Link
          to="/busca"
          className="inline-flex min-h-[44px] items-center px-5 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-semibold"
        >
          Voltar para a busca
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-[#0B4F24] text-[#F59E0B] flex items-center justify-center shrink-0">
            <CategoryIcon name={category.icon} className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-500">
              Categoria em {selectedCity.name} - {selectedCity.state}
            </p>
            <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
              {category.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              {category.description}
            </p>
          </div>
        </div>

        <div className="shrink-0">
          <label
            htmlFor="cat-hood-filter"
            className="block text-xs font-semibold text-slate-700 mb-1"
          >
            Filtrar por bairro:
          </label>
          <select
            id="cat-hood-filter"
            value={neighborhood}
            onChange={(e) => setNeighborhood(e.target.value)}
            className="px-3.5 py-2 rounded-xl border border-slate-300 text-xs bg-white"
          >
            <option value="todos">Todos os bairros</option>
            {selectedCity.neighborhoods.map((h) => (
              <option key={h} value={h}>
                {h}
              </option>
            ))}
          </select>
        </div>
      </div>

      {profs.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {profs.map((prof) => (
            <ProfessionalCard
              key={prof.id}
              prof={prof}
              onRequestQuote={onRequestQuote}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
          <p className="font-display text-base font-bold text-[#0B4F24]">
            Ainda não encontramos profissionais dessa categoria em sua região.
          </p>
          <CategorySuggestionBox
            defaultCategoryName={category.name}
            neighborhood={neighborhood !== 'todos' ? neighborhood : ''}
          />
        </div>
      )}
    </div>
  );
};

// 4. PROFESSIONAL PUBLIC PROFILE PAGE (/profissional/:slugOrId)
export const ProfessionalPublicPage: React.FC<{
  onRequestQuote: (prof: ProfessionalProfile) => void;
  onShareProf: (prof: ProfessionalProfile) => void;
  onReportTarget: (target: {
    type: 'professional' | 'review';
    id: string;
    name: string;
  }) => void;
}> = ({ onRequestQuote, onShareProf, onReportTarget }) => {
  const { slugOrId } = useParams<{ slugOrId: string }>();
  const {
    professionals,
    myProfessionalProfile,
    reviews,
    incrementProfileView,
  } = useApp();

  const prof = useMemo(() => {
    const found = professionals.find(
      (p) => p.slug === slugOrId || p.id === slugOrId
    );
    if (found) return found;
    if (
      myProfessionalProfile &&
      (myProfessionalProfile.slug === slugOrId ||
        myProfessionalProfile.id === slugOrId)
    ) {
      return myProfessionalProfile;
    }
    return null;
  }, [professionals, myProfessionalProfile, slugOrId]);

  useEffect(() => {
    if (prof && prof.status === 'approved') {
      incrementProfileView(prof.id);
    }
  }, [prof?.id]);

  const profReviews = useMemo(
    () =>
      reviews.filter(
        (r) => r.professionalId === prof?.id && r.status === 'published'
      ),
    [reviews, prof?.id]
  );

  if (!prof) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
          Perfil profissional não encontrado ou aguardando aprovação
        </h1>
        <p className="text-xs text-slate-600 max-w-md mx-auto">
          Apenas perfis aprovados pela moderação do JEITAKI ficam disponíveis
          para consulta pública.
        </p>
        <Link
          to="/busca"
          className="inline-flex min-h-[44px] items-center px-5 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-semibold"
        >
          Buscar Profissionais em Breu Branco
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {prof.status !== 'approved' && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-950 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-amber-700 shrink-0" />
          <div>
            <strong>Visualização privada do seu perfil:</strong> Este perfil
            está com status <strong>{prof.status}</strong> e ainda não aparece
            na busca pública.
          </div>
        </div>
      )}

      {/* Main Profile Header Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-start gap-5">
            {prof.photoUrl ? (
              <img
                src={prof.photoUrl}
                alt={prof.commercialName || prof.name}
                referrerPolicy="no-referrer"
                className="w-24 h-24 rounded-2xl object-cover border border-slate-200 shrink-0"
              />
            ) : (
              <div className="w-24 h-24 rounded-2xl bg-[#0B4F24] text-[#F59E0B] font-display font-bold text-2xl flex items-center justify-center shrink-0">
                {(prof.commercialName || prof.name).slice(0, 2).toUpperCase()}
              </div>
            )}

            <div className="space-y-2">
              <div className="text-xs text-slate-500 font-medium">
                {prof.categoryNames.join(' · ')}
              </div>
              <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0B4F24]">
                {prof.commercialName || prof.name}
              </h1>
              {prof.commercialName && (
                <p className="text-xs text-slate-500">
                  Responsável: {prof.name}
                </p>
              )}

              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600 tabular-nums pt-1">
                <span className="inline-flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#16A34A]" />
                  {prof.cityName} - PA
                </span>
                <span aria-hidden="true">·</span>
                <span className="inline-flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  {prof.workingHours}
                </span>
                <span aria-hidden="true">·</span>
                {profReviews.length > 0 ? (
                  <span className="inline-flex items-center gap-1 font-semibold text-[#0B4F24]">
                    <Star className="w-3.5 h-3.5 text-[#F59E0B] fill-[#F59E0B]" />
                    {prof.ratingAvg.toFixed(1)} ({profReviews.length}{' '}
                    {profReviews.length === 1 ? 'avaliação' : 'avaliações'})
                  </span>
                ) : (
                  <span>Sem avaliações registradas ainda</span>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row md:flex-col gap-2.5 shrink-0">
            <button
              type="button"
              disabled={!prof.isAvailable}
              onClick={() => onRequestQuote(prof)}
              className="min-h-[48px] px-6 py-3 rounded-xl bg-[#16A34A] text-white font-bold text-sm hover:bg-[#15803d] transition-colors flex items-center justify-center gap-2 whitespace-nowrap disabled:opacity-50"
            >
              <MessageCircle className="w-4 h-4" />
              <span>
                {prof.isAvailable
                  ? 'Solicitar orçamento'
                  : 'Agenda temporariamente pausada'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => onShareProf(prof)}
              className="min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-[#0B4F24] hover:bg-slate-50 flex items-center justify-center gap-2 whitespace-nowrap"
            >
              <Share2 className="w-4 h-4" />
              <span>Compartilhar profissional / QR Code</span>
            </button>
          </div>
        </div>

        {/* Transparent Verification Note */}
        <div className="p-4 rounded-2xl bg-[#F6FAF7] border border-slate-200 flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-[#0B4F24] shrink-0 mt-0.5" />
          <div className="text-xs text-slate-600 space-y-0.5">
            <p className="font-semibold text-[#0B4F24]">
              Status de verificação cadastral:{' '}
              {prof.documentVerified
                ? 'Informações de cadastro e contato conferidas pela administração'
                : 'Cadastro básico aprovado (sem verificação documental presencial)'}
            </p>
            <p>
              O JEITAKI recomenda sempre alinhar orçamento, prazos e referências
              diretamente com o prestador antes de iniciar o serviço.
            </p>
          </div>
        </div>

        {/* Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2 border-t border-slate-100">
          <div className="md:col-span-2 space-y-4">
            <div>
              <h2 className="font-display text-base font-bold text-[#0B4F24] mb-1.5">
                Sobre o profissional
              </h2>
              <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                {prof.description}
              </p>
            </div>

            <div>
              <h2 className="font-display text-base font-bold text-[#0B4F24] mb-2">
                Serviços oferecidos
              </h2>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-700">
                {prof.servicesOffered.map((srv) => (
                  <li key={srv} className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#16A34A] shrink-0" />
                    <span>{srv}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-[#F6FAF7] rounded-2xl p-5 border border-slate-200 space-y-3 text-xs">
            <h3 className="font-display text-sm font-bold text-[#0B4F24]">
              Informações de Atendimento
            </h3>
            <div>
              <span className="text-slate-500 block">Cidade e Bairros Atendidos:</span>
              <span className="font-medium text-[#0B4F24]">
                {prof.cityName}: {prof.neighborhoods.join(', ')}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Modalidade:</span>
              <span className="font-medium text-[#0B4F24]">
                {prof.attendanceTypes
                  .map((t) =>
                    t === 'domiciliar'
                      ? 'Atendimento em domicílio'
                      : t === 'remoto'
                      ? 'Remoto'
                      : 'No estabelecimento'
                  )
                  .join(' · ')}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Horário de Atendimento:</span>
              <span className="font-medium text-[#0B4F24]">
                {prof.workingHours}
              </span>
            </div>
            {typeof prof.startingPrice === 'number' && prof.startingPrice > 0 && (
              <div>
                <span className="text-slate-500 block">Preço inicial referencial:</span>
                <span className="font-bold text-[#0B4F24] text-sm tabular-nums">
                  A partir de R$ {prof.startingPrice.toFixed(2)}
                </span>
              </div>
            )}
            <div className="pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() =>
                  onReportTarget({
                    type: 'professional',
                    id: prof.id,
                    name: prof.commercialName || prof.name,
                  })
                }
                className="text-slate-500 hover:text-red-600 inline-flex items-center gap-1.5 font-medium"
              >
                <Flag className="w-3.5 h-3.5" />
                <span>Denunciar este perfil</span>
              </button>
            </div>
          </div>
        </div>

        {/* Portfolio Gallery */}
        {prof.portfolioUrls && prof.portfolioUrls.length > 0 && (
          <div className="pt-4 border-t border-slate-100 space-y-3">
            <h2 className="font-display text-base font-bold text-[#0B4F24]">
              Galeria de Trabalhos Executados
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {prof.portfolioUrls.map((url, idx) => (
                <div
                  key={idx}
                  className="aspect-4/3 rounded-2xl overflow-hidden border border-slate-200 bg-slate-100"
                >
                  <img
                    src={url}
                    alt={`Trabalho executado ${idx + 1} por ${prof.name}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Real Reviews Section */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-display text-lg font-bold text-[#0B4F24]">
              Avaliações Reais de Clientes ({profReviews.length})
            </h2>
            <p className="text-xs text-slate-500">
              Apenas moradores com serviço confirmado como concluído podem
              avaliar.
            </p>
          </div>
        </div>

        {profReviews.length > 0 ? (
          <div className="divide-y divide-slate-100">
            {profReviews.map((rev) => (
              <div key={rev.id} className="py-4 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#0B4F24]">
                      {rev.clientName}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="inline-flex items-center gap-0.5 text-[#F59E0B] font-semibold tabular-nums">
                      <Star className="w-3.5 h-3.5 fill-[#F59E0B]" />
                      {rev.rating.toFixed(1)}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="text-slate-400 tabular-nums">
                      {new Date(rev.createdAt).toLocaleDateString('pt-BR')}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      onReportTarget({
                        type: 'review',
                        id: rev.id,
                        name: `Avaliação de ${rev.clientName}`,
                      })
                    }
                    className="text-slate-400 hover:text-red-600 text-[11px]"
                  >
                    Denunciar
                  </button>
                </div>
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {rev.comment}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-500 py-4">
            Este profissional ainda não possui avaliações publicadas. Contrate
            pelo JEITAKI e seja o primeiro a avaliar após a conclusão do
            serviço!
          </p>
        )}
      </div>
    </div>
  );
};

// 5. STANDALONE QUOTE PAGE (/orcamento/:profId)
export const StandaloneQuotePage: React.FC<{
  onRequestQuote: (prof: ProfessionalProfile) => void;
}> = ({ onRequestQuote }) => {
  const { profId } = useParams<{ profId: string }>();
  const { professionals } = useApp();
  const prof = professionals.find(
    (p) => p.id === profId || p.slug === profId
  );

  useEffect(() => {
    if (prof) {
      onRequestQuote(prof);
    }
  }, [prof?.id]);

  if (!prof) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center space-y-4">
        <h1 className="font-display text-xl font-bold text-[#0B4F24]">
          Selecione um profissional para solicitar orçamento
        </h1>
        <Link
          to="/busca"
          className="inline-flex min-h-[44px] items-center px-5 py-2.5 rounded-xl bg-[#16A34A] text-white text-xs font-bold"
        >
          Ir para Busca de Profissionais
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto px-4 py-12 text-center space-y-4">
      <h1 className="font-display text-xl font-bold text-[#0B4F24]">
        Solicitar Orçamento para {prof.commercialName || prof.name}
      </h1>
      <button
        type="button"
        onClick={() => onRequestQuote(prof)}
        className="min-h-[48px] px-6 py-3 rounded-xl bg-[#16A34A] text-white text-sm font-bold"
      >
        Abrir Formulário de Orçamento
      </button>
    </div>
  );
};
