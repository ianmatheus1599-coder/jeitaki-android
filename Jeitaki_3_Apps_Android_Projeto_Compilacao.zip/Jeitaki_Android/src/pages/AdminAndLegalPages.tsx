import React, { useMemo, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  AlertTriangle,
  BarChart3,
  Building2,
  CheckCircle2,
  ClipboardList,
  Download,
  FileText,
  FolderKanban,
  Lock,
  Plus,
  RefreshCw,
  Shield,
  ShieldAlert,
  Trash2,
  Users,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { BOOTSTRAPPED_ADMIN_EMAIL } from '../lib/firebase';
import { IS_ANDROID_CONTAINER } from '../appVariant';
import {
  ProfessionalStatus,
  ServiceRequestStatus,
} from '../types/jeitaki';
import {
  calculatePlatformMetrics,
  exportToCSV,
  STATUS_LABELS,
} from '../utils/jeitakiLogic';

// Shared Admin Shell & Authorization Gate
const AdminShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, isAdmin, loginWithGoogle } = useApp();
  const location = useLocation();

  if (!currentUser || !isAdmin) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-5">
          <div className="w-12 h-12 rounded-2xl bg-[#0B4F24] text-[#F59E0B] flex items-center justify-center">
            <Lock className="w-6 h-6" />
          </div>
          <div className="space-y-2">
            <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
              Painel Administrativo Protegido
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Por segurança, o JEITAKI não utiliza senha administrativa fixa no
              código nem painel aberto ao público. O acesso administrativo exige
              autenticação verificada do proprietário do projeto.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-[#F6FAF7] border border-slate-200 space-y-2 text-xs text-slate-700">
            <p className="font-bold text-[#0B4F24]">
              Procedimento seguro para autorizar sua conta administrativa:
            </p>
            <ol className="list-decimal list-inside space-y-1.5">
              <li>
                Sua conta principal (<strong>{BOOTSTRAPPED_ADMIN_EMAIL}</strong>)
                já está pré-autorizada nas Regras de Segurança do banco de dados
                exigindo e-mail verificado.
              </li>
              <li>
                {IS_ANDROID_CONTAINER ? 'No APK, entre com e-mail e senha previamente habilitados no Firebase.' : 'Entre com Google usando a conta proprietária verificada para acessar o painel.'}
              </li>
              <li>
                Caso deseje autorizar outro administrador no futuro, basta
                adicionar um documento na coleção <code>/admins/&#123;uid&#125;</code>{' '}
                do Firestore com o UID do usuário.
              </li>
            </ol>
          </div>

          {currentUser && !isAdmin && (
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
              Você está conectado como <strong>{currentUser.email}</strong>, que
              não possui permissão de administrador.
            </div>
          )}

          <div className="flex flex-wrap gap-3">
            {IS_ANDROID_CONTAINER ? <Link to="/entrar" className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-bold">Entrar com e-mail e senha</Link> : <button
              type="button"
              onClick={loginWithGoogle}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-bold hover:bg-[#0E662F]"
            >
              Entrar com Google (Administrador)
            </button>}
            <Link
              to="/"
              className="min-h-[44px] px-5 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 flex items-center"
            >
              Voltar ao Início
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const navItems = [
    { to: '/admin', label: 'Visão Geral', icon: BarChart3 },
    { to: '/admin/profissionais', label: 'Profissionais', icon: Users },
    { to: '/admin/solicitacoes', label: 'Solicitações', icon: ClipboardList },
    {
      to: '/admin/categorias-cidades',
      label: 'Categorias e Cidades',
      icon: FolderKanban,
    },
    {
      to: '/admin/relatorios',
      label: 'Relatórios, Conteúdo e Logs',
      icon: FileText,
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Admin Sub-Navigation */}
      <div className="bg-white rounded-2xl border border-slate-200 p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 px-2">
          <Shield className="w-5 h-5 text-[#16A34A]" />
          <span className="font-display text-sm font-bold text-[#0B4F24]">
            Administração JEITAKI
          </span>
        </div>

        <nav
          aria-label="Menu Administrativo"
          className="flex flex-wrap items-center gap-1.5"
        >
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = location.pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-[#0B4F24] text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>

      {children}
    </div>
  );
};

// 12. ADMIN DASHBOARD PAGE (/admin)
export const AdminDashboardPage: React.FC = () => {
  const {
    professionals,
    serviceRequests,
    categories,
    cities,
    reports,
    includeDemoProfiles,
    adminSeedInitialData,
    adminCreateDemoProfessional,
    adminRemoveDemoProfessionals,
  } = useApp();

  const [daysFilter, setDaysFilter] = useState<'all' | '7' | '30'>('all');
  const [syncMsg, setSyncMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const filteredRequests = useMemo(() => {
    if (daysFilter === 'all') return serviceRequests;
    const days = Number(daysFilter);
    const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
    return serviceRequests.filter(
      (r) => new Date(r.createdAt).getTime() >= cutoff
    );
  }, [serviceRequests, daysFilter]);

  const metrics = useMemo(
    () =>
      calculatePlatformMetrics(
        filteredRequests,
        professionals,
        categories,
        includeDemoProfiles
      ),
    [filteredRequests, professionals, categories, includeDemoProfiles]
  );

  const hasDemo = professionals.some((p) => p.isDemo);

  const handleSeed = async () => {
    setBusy(true);
    setSyncMsg(null);
    try {
      await adminSeedInitialData();
      setSyncMsg(
        'Base inicial de Breu Branco (cidades, 12 categorias e textos) sincronizada no Firestore com sucesso!'
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <AdminShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white rounded-2xl border border-slate-200 p-6">
          <div>
            <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
              Indicadores Reais da Plataforma
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Métricas separadas por etapa operacional — sem números fictícios.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <label htmlFor="admin-date-filter" className="text-xs text-slate-600">
              Período:
            </label>
            <select
              id="admin-date-filter"
              value={daysFilter}
              onChange={(e) =>
                setDaysFilter(e.target.value as 'all' | '7' | '30')
              }
              className="px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
            >
              <option value="all">Todo o histórico</option>
              <option value="7">Últimos 7 dias</option>
              <option value="30">Últimos 30 dias</option>
            </select>

            <button
              type="button"
              disabled={busy}
              onClick={handleSeed}
              className="min-h-[40px] px-3.5 py-2 rounded-xl bg-[#0B4F24] text-white text-xs font-semibold flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#16A34A]" />
              <span>Sincronizar Base no Banco</span>
            </button>

            {!hasDemo ? (
              <button
                type="button"
                disabled={busy}
                onClick={adminCreateDemoProfessional}
                className="min-h-[40px] px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-[#0B4F24] hover:bg-slate-50"
              >
                Criar Perfil Fictício de Teste ([DEMO])
              </button>
            ) : (
              <button
                type="button"
                disabled={busy}
                onClick={adminRemoveDemoProfessionals}
                className="min-h-[40px] px-3.5 py-2 rounded-xl border border-red-200 bg-red-50 text-xs font-semibold text-red-700"
              >
                Remover Perfil de Teste ([DEMO])
              </button>
            )}
          </div>
        </div>

        {syncMsg && (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
            {syncMsg}
          </div>
        )}

        {/* Separated KPI Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 tabular-nums">
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <span className="text-xs text-slate-500 block">
              Profissionais Cadastrados
            </span>
            <span className="font-display text-2xl font-bold text-[#0B4F24] mt-1 block">
              {metrics.totalProfessionals}
            </span>
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <span className="text-xs text-slate-500 block">
              Profissionais Aprovados
            </span>
            <span className="font-display text-2xl font-bold text-emerald-700 mt-1 block">
              {metrics.approvedProfessionals}
            </span>
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <span className="text-xs text-slate-500 block">
              Cadastros Pendentes
            </span>
            <span className="font-display text-2xl font-bold text-amber-600 mt-1 block">
              {metrics.pendingProfessionals}
            </span>
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <span className="text-xs text-slate-500 block">
              Solicitações Criadas
            </span>
            <span className="font-display text-2xl font-bold text-[#0B4F24] mt-1 block">
              {metrics.requestsCreated}
            </span>
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <span className="text-xs text-slate-500 block">
              Cliques no WhatsApp
            </span>
            <span className="font-display text-2xl font-bold text-[#0B4F24] mt-1 block">
              {metrics.whatsappClicks}
            </span>
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <span className="text-xs text-slate-500 block">
              Orçamentos Registrados
            </span>
            <span className="font-display text-2xl font-bold text-[#0B4F24] mt-1 block">
              {metrics.quotesSent}
            </span>
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <span className="text-xs text-slate-500 block">
              Contratações Confirmadas
            </span>
            <span className="font-display text-2xl font-bold text-[#0B4F24] mt-1 block">
              {metrics.hiresConfirmed}
            </span>
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <span className="text-xs text-slate-500 block">
              Serviços Concluídos Confirmados
            </span>
            <span className="font-display text-2xl font-bold text-[#16A34A] mt-1 block">
              {metrics.completedConfirmed}
            </span>
          </div>
        </div>

        {/* Visual Breakdowns */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <h2 className="font-display text-base font-bold text-[#0B4F24]">
              Funil Real de Solicitações ({filteredRequests.length})
            </h2>
            {filteredRequests.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">
                Nenhuma solicitação registrada no período selecionado.
              </p>
            ) : (
              <div className="space-y-3 tabular-nums">
                {(
                  [
                    'nova',
                    'em_contato',
                    'orcamento_enviado',
                    'aceita',
                    'em_andamento',
                    'concluida',
                    'cancelada',
                  ] as ServiceRequestStatus[]
                ).map((st) => {
                  const count = filteredRequests.filter(
                    (r) => r.status === st
                  ).length;
                  const pct = Math.round(
                    (count / filteredRequests.length) * 100
                  );
                  return (
                    <div key={st} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-medium text-slate-700">
                          {STATUS_LABELS[st]}
                        </span>
                        <span className="font-semibold text-[#0B4F24]">
                          {count} ({pct}%)
                        </span>
                      </div>
                      <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                        <div
                          className="h-full bg-[#16A34A]"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <h2 className="font-display text-base font-bold text-[#0B4F24]">
              Solicitações por Cidade e Denúncias Abertas
            </h2>
            <div className="space-y-3 text-xs tabular-nums">
              {cities.map((c) => {
                const cityReqs = filteredRequests.filter(
                  (r) => r.cityId === c.id
                ).length;
                const cityProfs = professionals.filter(
                  (p) => p.cityId === c.id && !p.isDemo
                ).length;
                return (
                  <div
                    key={c.id}
                    className="p-3.5 rounded-xl bg-[#F6FAF7] border border-slate-200 flex items-center justify-between"
                  >
                    <div>
                      <span className="font-bold text-[#0B4F24]">
                        {c.name} - {c.state}
                      </span>
                      <span className="ml-2 text-slate-500">
                        ({c.isActive ? 'Ativa' : 'Preparada para expansão'})
                      </span>
                    </div>
                    <div className="text-slate-700">
                      {cityProfs} prof. · {cityReqs} solic.
                    </div>
                  </div>
                );
              })}

              <div className="p-3.5 rounded-xl bg-[#F6FAF7] border border-slate-200 flex items-center justify-between">
                <span className="font-semibold text-[#0B4F24]">
                  Denúncias / Chamados de Suporte / LGPD em aberto
                </span>
                <span className="font-bold text-[#0B4F24]">
                  {reports.filter((r) => r.status === 'open').length}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AdminShell>
  );
};

// 13. ADMIN PROFESSIONALS MANAGEMENT (/admin/profissionais)
export const AdminProfessionalsPage: React.FC = () => {
  const { professionals, adminUpdateProfessionalStatus } = useApp();
  const [filterStatus, setFilterStatus] = useState<string>('todos');
  const [notes, setNotes] = useState<Record<string, string>>({});

  const list = professionals.filter((p) =>
    filterStatus === 'todos' ? true : p.status === filterStatus
  );

  return (
    <AdminShell>
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-xl font-bold text-[#0B4F24]">
              Gestão e Aprovação de Profissionais ({list.length})
            </h1>
            <p className="text-xs text-slate-500">
              Aprove, solicite correção cadastral ou suspenda perfis.
            </p>
          </div>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3.5 py-2 rounded-xl border border-slate-300 text-xs bg-white"
          >
            <option value="todos">Todos os status</option>
            <option value="pending">Pendentes de aprovação</option>
            <option value="approved">Aprovados</option>
            <option value="correction_needed">Correção solicitada</option>
            <option value="rejected">Rejeitados</option>
            <option value="suspended">Suspensos</option>
          </select>
        </div>

        {list.length === 0 ? (
          <p className="text-xs text-slate-500 py-8 text-center">
            Nenhum profissional encontrado com este filtro.
          </p>
        ) : (
          <div className="space-y-4">
            {list.map((prof) => (
              <div
                key={prof.id}
                className="p-5 rounded-2xl bg-[#F6FAF7] border border-slate-200 space-y-3"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="text-xs text-slate-500">
                      Status atual:{' '}
                      <strong className="text-[#0B4F24]">{prof.status}</strong> ·
                      Cidade: {prof.cityName} · WhatsApp: {prof.whatsappPhone}
                    </div>
                    <h3 className="font-display text-base font-bold text-[#0B4F24] mt-0.5">
                      {prof.commercialName || prof.name}{' '}
                      {prof.isDemo ? '(PERFIL FICTÍCIO DE TESTE)' : ''}
                    </h3>
                    <p className="text-xs text-slate-600">
                      Categorias: {prof.categoryNames.join(', ')} · Bairros:{' '}
                      {prof.neighborhoods.join(', ')}
                    </p>
                  </div>

                  <Link
                    to={`/profissional/${prof.slug}`}
                    className="text-xs font-semibold text-[#0B4F24] underline"
                  >
                    Abrir Perfil
                  </Link>
                </div>

                <p className="text-xs text-slate-700">{prof.description}</p>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 pt-2 border-t border-slate-200">
                  <input
                    type="text"
                    value={notes[prof.id] ?? prof.verificationNote ?? ''}
                    onChange={(e) =>
                      setNotes((prev) => ({
                        ...prev,
                        [prof.id]: e.target.value,
                      }))
                    }
                    placeholder="Observação administrativa ou motivo de correção..."
                    className="flex-1 px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  />

                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        adminUpdateProfessionalStatus(
                          prof.id,
                          'approved',
                          notes[prof.id],
                          true
                        )
                      }
                      className="min-h-[38px] px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-bold"
                    >
                      Aprovar
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        adminUpdateProfessionalStatus(
                          prof.id,
                          'correction_needed',
                          notes[prof.id] || 'Revise seus dados cadastrais.'
                        )
                      }
                      className="min-h-[38px] px-3 py-1.5 rounded-xl bg-amber-500 text-white text-xs font-bold"
                    >
                      Pedir Correção
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        adminUpdateProfessionalStatus(
                          prof.id,
                          'suspended',
                          notes[prof.id]
                        )
                      }
                      className="min-h-[38px] px-3 py-1.5 rounded-xl bg-red-600 text-white text-xs font-bold"
                    >
                      Suspender
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AdminShell>
  );
};

// 14. ADMIN REQUESTS MANAGEMENT (/admin/solicitacoes)
export const AdminRequestsPage: React.FC = () => {
  const { serviceRequests, updateServiceRequestStatus } = useApp();
  const [statusFilter, setStatusFilter] = useState<string>('todas');

  const filtered = serviceRequests.filter((r) =>
    statusFilter === 'todas' ? true : r.status === statusFilter
  );

  return (
    <AdminShell>
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-xl font-bold text-[#0B4F24]">
              Gestão de Solicitações e Serviços Concluídos ({filtered.length})
            </h1>
            <p className="text-xs text-slate-500">
              Acompanhe todas as solicitações registradas e confirme conclusões
              por revisão administrativa quando necessário.
            </p>
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3.5 py-2 rounded-xl border border-slate-300 text-xs bg-white"
          >
            <option value="todas">Todos os estados</option>
            <option value="nova">Nova</option>
            <option value="em_contato">Em contato</option>
            <option value="orcamento_enviado">Orçamento enviado</option>
            <option value="aceita">Aceita</option>
            <option value="em_andamento">Serviço em andamento</option>
            <option value="concluida">Concluída</option>
            <option value="cancelada">Cancelada</option>
          </select>
        </div>

        {filtered.length === 0 ? (
          <p className="text-xs text-slate-500 py-8 text-center">
            Nenhuma solicitação encontrada para este filtro.
          </p>
        ) : (
          <div className="space-y-3">
            {filtered.map((req) => (
              <div
                key={req.id}
                className="p-4 rounded-2xl bg-[#F6FAF7] border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1 text-xs">
                  <div className="text-slate-500 tabular-nums">
                    #{req.id.slice(-6)} ·{' '}
                    {new Date(req.createdAt).toLocaleString('pt-BR')} ·{' '}
                    {req.cityName} ({req.neighborhood})
                  </div>
                  <div className="font-bold text-[#0B4F24] text-sm">
                    {req.serviceTitle} — Cliente: {req.clientName} ({req.clientPhone})
                  </div>
                  <div className="text-slate-600">
                    Profissional: <strong>{req.professionalName}</strong> ·
                    Clique WhatsApp: {req.whatsappClicked ? 'Sim' : 'Não'}
                  </div>
                  <p className="text-slate-600">{req.description}</p>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  <select
                    value={req.status}
                    onChange={(e) =>
                      updateServiceRequestStatus(
                        req.id,
                        e.target.value as ServiceRequestStatus,
                        e.target.value === 'concluida'
                      )
                    }
                    className="px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold"
                  >
                    <option value="nova">Nova</option>
                    <option value="em_contato">Em contato</option>
                    <option value="orcamento_enviado">Orçamento enviado</option>
                    <option value="aceita">Aceita</option>
                    <option value="em_andamento">Serviço em andamento</option>
                    <option value="concluida">Concluída (Confirmada)</option>
                    <option value="cancelada">Cancelada</option>
                  </select>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AdminShell>
  );
};

// 15. ADMIN CATEGORIES & CITIES MANAGEMENT (/admin/categorias-cidades)
export const AdminCategoriesCitiesPage: React.FC = () => {
  const {
    categories,
    cities,
    adminSaveCategory,
    adminSaveCity,
  } = useApp();

  const [catName, setCatName] = useState('');
  const [catIcon, setCatIcon] = useState('Briefcase');
  const [catDesc, setCatDesc] = useState('');

  const [cityName, setCityName] = useState('');
  const [cityState, setCityState] = useState('PA');
  const [cityHoods, setCityHoods] = useState('');

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName.trim() || !catDesc.trim()) return;
    await adminSaveCategory({
      name: catName,
      icon: catIcon,
      description: catDesc,
      isActive: true,
    });
    setCatName('');
    setCatDesc('');
  };

  const handleAddCity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cityName.trim() || !cityHoods.trim()) return;
    await adminSaveCity({
      name: cityName,
      state: cityState,
      neighborhoods: cityHoods.split(',').map((h) => h.trim()),
      isActive: true,
    });
    setCityName('');
    setCityHoods('');
  };

  return (
    <AdminShell>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Categories Management */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
          <h2 className="font-display text-lg font-bold text-[#0B4F24]">
            Gerenciar Categorias ({categories.length})
          </h2>

          <form
            onSubmit={handleAddCategory}
            className="p-4 rounded-2xl bg-[#F6FAF7] border border-slate-200 space-y-3"
          >
            <h3 className="text-xs font-bold text-[#0B4F24]">
              Adicionar ou Atualizar Categoria
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <input
                type="text"
                required
                value={catName}
                onChange={(e) => setCatName(e.target.value)}
                placeholder="Nome da categoria"
                className="sm:col-span-2 px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
              />
              <select
                value={catIcon}
                onChange={(e) => setCatIcon(e.target.value)}
                className="px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
              >
                {[
                  'Zap',
                  'Hammer',
                  'Droplets',
                  'Sparkles',
                  'Snowflake',
                  'ShieldCheck',
                  'Paintbrush',
                  'Wrench',
                  'Package',
                  'Trees',
                  'Laptop',
                  'Briefcase',
                ].map((ic) => (
                  <option key={ic} value={ic}>
                    Ícone: {ic}
                  </option>
                ))}
              </select>
            </div>
            <input
              type="text"
              required
              value={catDesc}
              onChange={(e) => setCatDesc(e.target.value)}
              placeholder="Descrição clara dos serviços da categoria"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
            />
            <button
              type="submit"
              className="min-h-[38px] px-4 py-2 rounded-xl bg-[#0B4F24] text-white text-xs font-bold inline-flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4 text-[#16A34A]" />
              <span>Salvar Categoria</span>
            </button>
          </form>

          <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
            {categories.map((cat) => (
              <div
                key={cat.id}
                className="p-3 rounded-xl border border-slate-200 flex items-center justify-between gap-3 text-xs"
              >
                <div>
                  <span className="font-bold text-[#0B4F24]">{cat.name}</span>
                  <p className="text-slate-500 line-clamp-1">{cat.description}</p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    adminSaveCategory({
                      ...cat,
                      isActive: !cat.isActive,
                    })
                  }
                  className={`px-3 py-1.5 rounded-lg font-semibold shrink-0 ${
                    cat.isActive
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {cat.isActive ? 'Ativa' : 'Desativada'}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Multi-City Expansion Management */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
          <div>
            <h2 className="font-display text-lg font-bold text-[#0B4F24]">
              Expansão Multi-Cidades e Bairros ({cities.length})
            </h2>
            <p className="text-xs text-slate-500">
              Breu Branco está ativa inicialmente. Você pode ativar Tucuruí,
              Goianésia do Pará ou cadastrar novas cidades a qualquer momento.
            </p>
          </div>

          <form
            onSubmit={handleAddCity}
            className="p-4 rounded-2xl bg-[#F6FAF7] border border-slate-200 space-y-3"
          >
            <h3 className="text-xs font-bold text-[#0B4F24]">
              Cadastrar Nova Cidade ou Atualizar Bairros
            </h3>
            <div className="grid grid-cols-3 gap-2.5">
              <input
                type="text"
                required
                value={cityName}
                onChange={(e) => setCityName(e.target.value)}
                placeholder="Ex: Novo Repartimento"
                className="col-span-2 px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
              />
              <input
                type="text"
                required
                value={cityState}
                onChange={(e) => setCityState(e.target.value)}
                placeholder="UF (PA)"
                className="px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
              />
            </div>
            <input
              type="text"
              required
              value={cityHoods}
              onChange={(e) => setCityHoods(e.target.value)}
              placeholder="Bairros separados por vírgula (Ex: Centro, Bela Vista, Novo Horizonte)"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
            />
            <button
              type="submit"
              className="min-h-[38px] px-4 py-2 rounded-xl bg-[#0B4F24] text-white text-xs font-bold inline-flex items-center gap-1.5"
            >
              <Building2 className="w-4 h-4 text-[#16A34A]" />
              <span>Salvar Cidade</span>
            </button>
          </form>

          <div className="space-y-3">
            {cities.map((c) => (
              <div
                key={c.id}
                className="p-4 rounded-xl border border-slate-200 space-y-2 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#0B4F24] text-sm">
                    {c.name} - {c.state}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      adminSaveCity({
                        ...c,
                        isActive: !c.isActive,
                      })
                    }
                    className={`px-3 py-1.5 rounded-lg font-semibold ${
                      c.isActive
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        : 'bg-amber-50 text-amber-900 border border-amber-200'
                    }`}
                  >
                    {c.isActive ? 'Cidade Ativa' : 'Ativar Cidade'}
                  </button>
                </div>
                <p className="text-slate-600">
                  Bairros ({c.neighborhoods.length}):{' '}
                  {c.neighborhoods.join(', ')}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AdminShell>
  );
};

// 16. ADMIN REPORTS, CSV EXPORT, CONTENT CMS, MONETIZATION & AUDIT LOGS (/admin/relatorios)
export const AdminReportsPage: React.FC = () => {
  const {
    professionals,
    serviceRequests,
    reports,
    reviews,
    auditLogs,
    platformSettings,
    adminSavePlatformSettings,
    adminUpdateReportStatus,
    adminModerateReview,
  } = useApp();

  const [settingsForm, setSettingsForm] = useState(platformSettings);
  const [savedCms, setSavedCms] = useState(false);

  const downloadCSV = (filename: string, rows: Record<string, unknown>[]) => {
    const csvContent = exportToCSV(rows);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSaveCMS = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavedCms(false);
    await adminSavePlatformSettings(settingsForm);
    setSavedCms(true);
  };

  return (
    <AdminShell>
      <div className="space-y-8">
        {/* CSV Exports */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
          <h1 className="font-display text-xl font-bold text-[#0B4F24]">
            Exportação de Relatórios em CSV
          </h1>
          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() =>
                downloadCSV(
                  'jeitaki-profissionais.csv',
                  professionals.map((p) => ({
                    id: p.id,
                    nome: p.name,
                    nome_comercial: p.commercialName || '',
                    cidade: p.cityName,
                    categorias: p.categoryNames.join('; '),
                    whatsapp: p.whatsappPhone,
                    status: p.status,
                    avaliacao_media: p.ratingAvg,
                    servicos_concluidos: p.completedJobsCount,
                    criado_em: p.createdAt,
                  }))
                )
              }
              className="min-h-[42px] px-4 py-2 rounded-xl bg-[#0B4F24] text-white text-xs font-bold inline-flex items-center gap-2"
            >
              <Download className="w-4 h-4 text-[#16A34A]" />
              <span>Exportar Profissionais (CSV)</span>
            </button>

            <button
              type="button"
              onClick={() =>
                downloadCSV(
                  'jeitaki-solicitacoes.csv',
                  serviceRequests.map((r) => ({
                    id: r.id,
                    cliente: r.clientName,
                    telefone_cliente: r.clientPhone,
                    profissional: r.professionalName,
                    servico: r.serviceTitle,
                    cidade: r.cityName,
                    bairro: r.neighborhood,
                    status: r.status,
                    clicou_whatsapp: r.whatsappClicked,
                    data: r.createdAt,
                  }))
                )
              }
              className="min-h-[42px] px-4 py-2 rounded-xl bg-[#0B4F24] text-white text-xs font-bold inline-flex items-center gap-2"
            >
              <Download className="w-4 h-4 text-[#16A34A]" />
              <span>Exportar Solicitações (CSV)</span>
            </button>

            <button
              type="button"
              onClick={() =>
                downloadCSV(
                  'jeitaki-historico-admin.csv',
                  auditLogs.map((l) => ({
                    id: l.id,
                    admin: l.adminEmail,
                    acao: l.action,
                    alvo: `${l.targetType}:${l.targetId}`,
                    detalhes: l.details,
                    data: l.createdAt,
                  }))
                )
              }
              className="min-h-[42px] px-4 py-2 rounded-xl border border-slate-300 text-[#0B4F24] text-xs font-bold inline-flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>Exportar Histórico Administrativo (CSV)</span>
            </button>
          </div>
        </div>

        {/* Moderation of Reports, Denúncias & Reviews */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <h2 className="font-display text-base font-bold text-[#0B4F24]">
              Moderação de Denúncias, Sugestões e LGPD ({reports.length})
            </h2>
            {reports.length === 0 ? (
              <p className="text-xs text-slate-500 py-4">
                Nenhuma denúncia ou solicitação pendente.
              </p>
            ) : (
              <div className="space-y-3 max-h-[360px] overflow-y-auto">
                {reports.map((rep) => (
                  <div
                    key={rep.id}
                    className="p-3.5 rounded-xl bg-[#F6FAF7] border border-slate-200 space-y-1.5 text-xs"
                  >
                    <div className="flex justify-between">
                      <span className="font-bold text-[#0B4F24]">
                        [{rep.targetType}] {rep.reason}
                      </span>
                      <span className="text-slate-500">{rep.status}</span>
                    </div>
                    <p className="text-slate-600">{rep.details}</p>
                    <div className="flex gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() =>
                          adminUpdateReportStatus(rep.id, 'resolved')
                        }
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-semibold"
                      >
                        Marcar Resolvido
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          adminUpdateReportStatus(rep.id, 'dismissed')
                        }
                        className="px-2.5 py-1 rounded-lg border border-slate-300 text-slate-600"
                      >
                        Arquivar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <h2 className="font-display text-base font-bold text-[#0B4F24]">
              Moderação de Avaliações ({reviews.length})
            </h2>
            {reviews.length === 0 ? (
              <p className="text-xs text-slate-500 py-4">
                Nenhuma avaliação registrada até o momento.
              </p>
            ) : (
              <div className="space-y-3 max-h-[360px] overflow-y-auto">
                {reviews.map((rev) => (
                  <div
                    key={rev.id}
                    className="p-3.5 rounded-xl bg-[#F6FAF7] border border-slate-200 space-y-1.5 text-xs"
                  >
                    <div className="flex justify-between">
                      <span className="font-bold text-[#0B4F24]">
                        {rev.clientName} ({rev.rating} ★)
                      </span>
                      <span className="text-slate-500">{rev.status}</span>
                    </div>
                    <p className="text-slate-600">{rev.comment}</p>
                    <div className="flex gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() =>
                          adminModerateReview(
                            rev.id,
                            rev.status === 'published' ? 'hidden' : 'published'
                          )
                        }
                        className="px-2.5 py-1 rounded-lg border border-slate-300 text-[#0B4F24] font-semibold"
                      >
                        {rev.status === 'published'
                          ? 'Ocultar Avaliação'
                          : 'Republicar'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Editable Home Texts, Banners, Legal Docs & Future Monetization */}
        <form
          onSubmit={handleSaveCMS}
          className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display text-lg font-bold text-[#0B4F24]">
                Gerenciamento de Textos, Banners, Termos e Monetização Futura
              </h2>
              <p className="text-xs text-slate-500">
                Altere textos da página inicial, banners e políticas sem editar
                código.
              </p>
            </div>
            {savedCms && (
              <span className="text-xs font-bold text-emerald-700">
                Configurações salvas!
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Título Principal da Tela Inicial
              </label>
              <input
                type="text"
                value={settingsForm.heroTitle}
                onChange={(e) =>
                  setSettingsForm({ ...settingsForm, heroTitle: e.target.value })
                }
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Subtítulo da Tela Inicial
              </label>
              <input
                type="text"
                value={settingsForm.heroSubtitle}
                onChange={(e) =>
                  setSettingsForm({
                    ...settingsForm,
                    heroSubtitle: e.target.value,
                  })
                }
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Título do Banner para Profissionais
              </label>
              <input
                type="text"
                value={settingsForm.bannerTitle}
                onChange={(e) =>
                  setSettingsForm({
                    ...settingsForm,
                    bannerTitle: e.target.value,
                  })
                }
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Subtítulo do Banner
              </label>
              <input
                type="text"
                value={settingsForm.bannerSubtitle}
                onChange={(e) =>
                  setSettingsForm({
                    ...settingsForm,
                    bannerSubtitle: e.target.value,
                  })
                }
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
              />
            </div>
          </div>

          {/* Future Monetization Config (Disabled by Default) */}
          <div className="p-4 rounded-2xl bg-[#F6FAF7] border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-[#0B4F24]">
                  Estrutura de Monetização Futura (Atualmente Desativada / 100%
                  Gratuita)
                </h3>
                <p className="text-[11px] text-slate-500">
                  Plano Básico: Gratuito · Plano Destaque Futuro sugerido:{' '}
                  {settingsForm.highlightPlanPrice} (Nenhuma cobrança ativa sem
                  sua autorização).
                </p>
              </div>
              <span className="text-xs font-semibold text-emerald-700">
                Cobrança Desativada
              </span>
            </div>
          </div>

          <button
            type="submit"
            className="min-h-[42px] px-5 py-2.5 rounded-xl bg-[#16A34A] text-white text-xs font-bold"
          >
            Salvar Textos e Configurações da Plataforma
          </button>
        </form>

        {/* Audit Logs */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
          <h2 className="font-display text-base font-bold text-[#0B4F24]">
            Histórico de Ações Administrativas ({auditLogs.length})
          </h2>
          {auditLogs.length === 0 ? (
            <p className="text-xs text-slate-500">
              Nenhuma ação administrativa registrada ainda.
            </p>
          ) : (
            <div className="space-y-2 max-h-[260px] overflow-y-auto text-xs tabular-nums">
              {auditLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 rounded-xl bg-[#F6FAF7] border border-slate-200 flex flex-wrap justify-between gap-2"
                >
                  <span>
                    <strong className="text-[#0B4F24]">{log.action}:</strong>{' '}
                    {log.details}
                  </span>
                  <span className="text-slate-400">
                    {log.adminEmail} ·{' '}
                    {new Date(log.createdAt).toLocaleString('pt-BR')}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </AdminShell>
  );
};

// 17. SUPPORT, REPORTS & LGPD DELETION PAGE (/suporte)
export const SupportAndReportsPage: React.FC = () => {
  const { createReport, userProfile, userPrivate } = useApp();
  const [targetType, setTargetType] =
    useState<
      'support' | 'professional' | 'review' | 'lgpd_deletion'
    >('support');
  const [reason, setReason] = useState('Dúvida ou suporte técnico');
  const [details, setDetails] = useState('');
  const [name, setName] = useState(userProfile?.displayName || '');
  const [contact, setContact] = useState(
    userPrivate?.email || userPrivate?.phone || ''
  );
  const [sent, setSent] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (details.trim().length < 5) return;
    setSubmitting(true);
    try {
      await createReport({
        targetType,
        targetId: 'plataforma',
        reason,
        details,
        reporterName: name,
        reporterContact: contact,
      });
      setSent(true);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
          Suporte, Denúncias e Direitos LGPD
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-1">
          Canal direto para moradores e profissionais de Breu Branco relatarem
          problemas, denunciarem perfis ou solicitarem exclusão de dados
          pessoais.
        </p>
      </div>

      {sent ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
            Sua solicitação foi registrada com protocolo no banco de dados e
            encaminhada para análise da administração do JEITAKI.
          </div>
          <button
            type="button"
            onClick={() => {
              setSent(false);
              setDetails('');
            }}
            className="min-h-[40px] px-4 py-2 rounded-xl bg-[#0B4F24] text-white text-xs font-semibold"
          >
            Enviar outra solicitação
          </button>
        </div>
      ) : (
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-4"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="sup-type"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Tipo de atendimento *
              </label>
              <select
                id="sup-type"
                value={targetType}
                onChange={(e) => {
                  const val = e.target.value as typeof targetType;
                  setTargetType(val);
                  if (val === 'lgpd_deletion') {
                    setReason('Solicitação de exclusão de dados pessoais (LGPD)');
                  }
                }}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs bg-white"
              >
                <option value="support">Suporte ou dúvida geral</option>
                <option value="professional">
                  Denunciar perfil profissional ou conduta
                </option>
                <option value="review">Denunciar avaliação indevida</option>
                <option value="lgpd_deletion">
                  Solicitar exclusão de conta e dados pessoais (LGPD)
                </option>
              </select>
            </div>

            <div>
              <label
                htmlFor="sup-reason"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Assunto resumido *
              </label>
              <input
                id="sup-reason"
                type="text"
                required
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="sup-name"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Seu nome *
              </label>
              <input
                id="sup-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
              />
            </div>

            <div>
              <label
                htmlFor="sup-contact"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Seu WhatsApp ou e-mail para retorno *
              </label>
              <input
                id="sup-contact"
                type="text"
                required
                value={contact}
                onChange={(e) => setContact(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="sup-details"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Descrição detalhada *
            </label>
            <textarea
              id="sup-details"
              required
              rows={4}
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              placeholder="Informe os detalhes do seu pedido, nome do perfil denunciado ou dados que deseja excluir..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="min-h-[48px] px-6 py-3 rounded-xl bg-[#0B4F24] text-white font-bold text-xs hover:bg-[#0E662F]"
          >
            {submitting
              ? 'Registrando...'
              : 'Enviar Solicitação para a Administração'}
          </button>
        </form>
      )}
    </div>
  );
};

// 18. TERMS OF USE PAGE (/termos)
export const TermsPage: React.FC = () => {
  const { platformSettings } = useApp();
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-4">
        <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
          Termos de Uso — JEITAKI
        </h1>
        <p className="text-xs text-slate-400">
          Última atualização:{' '}
          {new Date(platformSettings.updatedAt).toLocaleDateString('pt-BR')}
        </p>
        <div className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line">
          {platformSettings.termsContent}
        </div>
      </div>
    </div>
  );
};

// 19. PRIVACY POLICY & LGPD PAGE (/privacidade)
export const PrivacyPage: React.FC = () => {
  const { platformSettings } = useApp();
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-4">
        <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
          Política de Privacidade e Adequação à LGPD
        </h1>
        <p className="text-xs text-slate-400">
          Última atualização:{' '}
          {new Date(platformSettings.updatedAt).toLocaleDateString('pt-BR')}
        </p>
        <div className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line">
          {platformSettings.privacyContent}
        </div>
        <div className="pt-4 border-t border-slate-100">
          <Link
            to="/suporte"
            className="inline-flex min-h-[40px] items-center px-4 py-2 rounded-xl bg-[#0B4F24] text-white text-xs font-semibold"
          >
            Solicitar Exclusão ou Alteração de Dados Pessoais (LGPD)
          </Link>
        </div>
      </div>
    </div>
  );
};

// 20. NOT FOUND PAGE (*)
export const NotFoundPage: React.FC = () => (
  <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
    <h1 className="font-display text-3xl font-extrabold text-[#0B4F24]">
      Página não encontrada
    </h1>
    <p className="text-xs sm:text-sm text-slate-600">
      O endereço que você acessou não existe ou foi movido.
    </p>
    <div className="flex justify-center gap-3 pt-2">
      <Link
        to="/"
        className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-bold flex items-center"
      >
        Ir para a Página Inicial
      </Link>
      <Link
        to="/busca"
        className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#16A34A] text-white text-xs font-bold flex items-center"
      >
        Buscar Profissionais
      </Link>
    </div>
  </div>
);
