import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  Check,
  Clock,
  Edit3,
  ExternalLink,
  Eye,
  LogOut,
  MessageCircle,
  PauseCircle,
  PlayCircle,
  QrCode,
  Shield,
  Star,
  Upload,
  UserCheck,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { IS_ANDROID_CONTAINER, APP_VARIANT } from '../appVariant';
import { OFFICIAL_BRAND_LOGO } from '../components/CategoryIcon';
import {
  AttendanceType,
  ProfessionalProfile,
  ServiceRequest,
  ServiceRequestStatus,
} from '../types/jeitaki';
import {
  buildWhatsAppQuoteUrl,
  isValidBrazilianPhone,
  STATUS_LABELS,
} from '../utils/jeitakiLogic';

// 6. AUTH PAGE (/entrar)
export const AuthPage: React.FC = () => {
  const {
    currentUser,
    loginWithGoogle,
    loginWithEmail,
    registerWithEmail,
    resetPassword,
    selectedCity,
  } = useApp();
  const navigate = useNavigate();

  const [mode, setMode] = useState<'login' | 'register' | 'reset'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [neighborhood, setNeighborhood] = useState(
    selectedCity.neighborhoods[0] || 'Centro'
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [infoMessage, setInfoMessage] = useState<string | null>(null);

  if (currentUser) {
    return (
      <div className="max-w-md mx-auto px-4 py-12">
        <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center mx-auto">
            <UserCheck className="w-6 h-6" />
          </div>
          <h1 className="font-display text-xl font-bold text-[#0B4F24]">
            Você já está conectado
          </h1>
          <p className="text-xs text-slate-600">
            Conectado como <strong>{currentUser.email}</strong>
          </p>
          <div className="flex flex-col gap-2.5 pt-2">
            <Link
              to="/minha-conta"
              className="min-h-[44px] rounded-xl bg-[#0B4F24] text-white text-xs font-bold flex items-center justify-center"
            >
              Ir para Minha Conta
            </Link>
            {APP_VARIANT === 'profissional' && <Link
              to="/seja-profissional"
              className="min-h-[44px] rounded-xl bg-[#16A34A] text-white text-xs font-bold flex items-center justify-center"
            >
              Cadastrar ou Acessar Área do Profissional
            </Link>}
          </div>
        </div>
      </div>
    );
  }

  const handleGoogle = async () => {
    setError(null);
    setLoading(true);
    try {
      await loginWithGoogle();
      navigate('/minha-conta');
    } catch (err: unknown) {
      setError(
        err instanceof Error
          ? err.message
          : 'Não foi possível concluir o login com Google.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfoMessage(null);
    setLoading(true);
    try {
      if (mode === 'login') {
        await loginWithEmail(email, password);
        navigate(APP_VARIANT === 'admin' ? '/admin' : APP_VARIANT === 'profissional' ? '/painel-profissional' : '/minha-conta');
      } else if (mode === 'register') {
        if (name.trim().length < 2) {
          throw new Error('Informe seu nome completo.');
        }
        if (password.length < 6) {
          throw new Error('A senha deve ter pelo menos 6 caracteres.');
        }
        await registerWithEmail({
          name,
          email,
          password,
          phone,
          neighborhood,
        });
        setInfoMessage(
          'Conta criada! Confira seu e-mail e confirme o endereço antes de utilizar o aplicativo.'
        );
      } else {
        await resetPassword(email);
        setInfoMessage(
          'Enviamos um link de recuperação de senha para o seu e-mail.'
        );
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('operation-not-allowed')) {
        setError(
          'Para usar o aplicativo Android, é necessário ativar E-mail/senha no Firebase > Authentication > Método de login.'
        );
      } else {
        setError(msg);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-10">
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6">
        <div className="space-y-2 text-center">
          <img
            src={OFFICIAL_BRAND_LOGO}
            alt="Logo Oficial Jeita Aqui Breu Branco"
            referrerPolicy="no-referrer"
            className="w-28 h-28 object-contain mx-auto"
          />
          <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
            {mode === 'login'
              ? 'Entrar no Jeita Aqui'
              : mode === 'register'
              ? 'Criar Conta no Jeita Aqui'
              : 'Recuperar Acesso'}
          </h1>
          <p className="text-xs text-slate-500">
            Acompanhe solicitações, avalie serviços concluídos ou cadastre seu
            perfil profissional em {selectedCity.name}.
          </p>
        </div>

        {/* Google popup only works in browsers, not in Android WebView. */}
        {!IS_ANDROID_CONTAINER ? <button
          type="button"
          disabled={loading}
          onClick={handleGoogle}
          className="w-full min-h-[48px] px-4 py-3 rounded-xl bg-[#0B4F24] text-white font-bold text-xs sm:text-sm hover:bg-[#0E662F] transition-colors flex items-center justify-center gap-2.5 shadow-xs"
        >
          <span>Continuar com Conta Google (Acesso Verificado)</span>
        </button> : <p className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs text-emerald-900">No aplicativo Android, utilize e-mail e senha. Você precisa habilitar o provedor E-mail/senha no Firebase Authentication.</p>}

        <div className="relative flex py-1 items-center">
          <div className="grow border-t border-slate-200" />
          <span className="shrink mx-3 text-[11px] text-slate-400">
            ou utilize seu e-mail
          </span>
          <div className="grow border-t border-slate-200" />
        </div>

        {/* Mode Switcher */}
        <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-xl">
          <button
            type="button"
            onClick={() => setMode('login')}
            className={`py-2 text-xs font-semibold rounded-lg transition-colors ${
              mode === 'login'
                ? 'bg-white text-[#0B4F24] shadow-xs'
                : 'text-slate-600'
            }`}
          >
            Entrar
          </button>
          <button
            type="button"
            onClick={() => setMode('register')}
            className={`py-2 text-xs font-semibold rounded-lg transition-colors ${
              mode === 'register'
                ? 'bg-white text-[#0B4F24] shadow-xs'
                : 'text-slate-600'
            }`}
          >
            Criar conta
          </button>
          <button
            type="button"
            onClick={() => setMode('reset')}
            className={`py-2 text-xs font-semibold rounded-lg transition-colors ${
              mode === 'reset'
                ? 'bg-white text-[#0B4F24] shadow-xs'
                : 'text-slate-600'
            }`}
          >
            Recuperar
          </button>
        </div>

        {error && (
          <div
            role="alert"
            className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800"
          >
            {error}
          </div>
        )}

        {infoMessage && (
          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
            {infoMessage}
          </div>
        )}

        <form onSubmit={handleEmailSubmit} className="space-y-3.5">
          {mode === 'register' && (
            <>
              <div>
                <label
                  htmlFor="auth-name"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Nome completo *
                </label>
                <input
                  id="auth-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Seu nome"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label
                    htmlFor="auth-phone"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    WhatsApp
                  </label>
                  <input
                    id="auth-phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="(94) 99123-4567"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
                <div>
                  <label
                    htmlFor="auth-hood"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Bairro
                  </label>
                  <select
                    id="auth-hood"
                    value={neighborhood}
                    onChange={(e) => setNeighborhood(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs bg-white"
                  >
                    {selectedCity.neighborhoods.map((h) => (
                      <option key={h} value={h}>
                        {h}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </>
          )}

          <div>
            <label
              htmlFor="auth-email"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              E-mail *
            </label>
            <input
              id="auth-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seuemail@exemplo.com"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
            />
          </div>

          {mode !== 'reset' && (
            <div>
              <label
                htmlFor="auth-pass"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Senha *
              </label>
              <input
                id="auth-pass"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Mínimo 6 caracteres"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full min-h-[44px] rounded-xl bg-[#16A34A] text-white font-bold text-xs hover:bg-[#15803d] transition-colors"
          >
            {loading
              ? 'Processando...'
              : mode === 'login'
              ? 'Entrar com E-mail'
              : mode === 'register'
              ? 'Cadastrar Conta'
              : 'Enviar Link de Recuperação'}
          </button>
        </form>
      </div>
    </div>
  );
};

// 7. MY ACCOUNT PAGE (/minha-conta)
export const MyAccountPage: React.FC = () => {
  const {
    currentUser,
    userProfile,
    userPrivate,
    isAdmin,
    myProfessionalProfile,
    selectedCity,
    updateMyAccount,
    logout,
  } = useApp();
  const navigate = useNavigate();

  const [displayName, setDisplayName] = useState(
    userProfile?.displayName || currentUser?.displayName || ''
  );
  const [phone, setPhone] = useState(userPrivate?.phone || '');
  const [neighborhood, setNeighborhood] = useState(
    userProfile?.neighborhood || selectedCity.neighborhoods[0] || 'Centro'
  );
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  if (!currentUser) {
    return (
      <div className="max-w-md mx-auto px-4 py-14 text-center space-y-4">
        <h1 className="font-display text-xl font-bold text-[#0B4F24]">
          Entre para acessar sua conta
        </h1>
        <Link
          to="/entrar"
          className="inline-flex min-h-[44px] items-center px-6 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-bold"
        >
          Ir para Login / Cadastro
        </Link>
      </div>
    );
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    try {
      await updateMyAccount({ displayName, phone, neighborhood });
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white rounded-2xl border border-slate-200 p-6">
        <div>
          <p className="text-xs text-slate-500">
            Conta autenticada · Perfil:{' '}
            {isAdmin
              ? 'Administrador'
              : myProfessionalProfile
              ? 'Profissional e Cliente'
              : 'Morador / Cliente'}
          </p>
          <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
            {userProfile?.displayName || currentUser.displayName || 'Minha Conta'}
          </h1>
          <p className="text-xs text-slate-500">{currentUser.email}</p>
        </div>

        <button
          type="button"
          onClick={async () => {
            await logout();
            navigate('/');
          }}
          className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 inline-flex items-center gap-2 self-start"
        >
          <LogOut className="w-4 h-4" />
          <span>Sair da Conta</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <form
          onSubmit={handleSave}
          className="md:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 space-y-4"
        >
          <h2 className="font-display text-base font-bold text-[#0B4F24]">
            Meus Dados Cadastrais
          </h2>

          {saved && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
              Dados atualizados com sucesso!
            </div>
          )}

          <div>
            <label
              htmlFor="acc-name"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Nome de exibição
            </label>
            <input
              id="acc-name"
              type="text"
              required
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="acc-phone"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Telefone / WhatsApp privado
              </label>
              <input
                id="acc-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="(94) 99123-4567"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
              />
            </div>

            <div>
              <label
                htmlFor="acc-hood"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Meu bairro em {selectedCity.name}
              </label>
              <select
                id="acc-hood"
                value={neighborhood}
                onChange={(e) => setNeighborhood(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs bg-white"
              >
                {selectedCity.neighborhoods.map((h) => (
                  <option key={h} value={h}>
                    {h}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-bold hover:bg-[#0E662F]"
          >
            {saving ? 'Salvando...' : 'Salvar Alterações'}
          </button>
        </form>

        {/* Quick Actions Sidebar */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
          <h2 className="font-display text-base font-bold text-[#0B4F24]">
            Acessos Rápidos
          </h2>
          <Link
            to="/minhas-solicitacoes"
            className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-[#F6FAF7] border border-slate-200 text-xs font-semibold text-[#0B4F24] hover:border-[#16A34A] flex items-center justify-between"
          >
            <span>Minhas Solicitações de Orçamento</span>
          </Link>
          <Link
            to={
              myProfessionalProfile
                ? '/painel-profissional'
                : '/seja-profissional'
            }
            className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-[#F6FAF7] border border-slate-200 text-xs font-semibold text-[#0B4F24] hover:border-[#16A34A] flex items-center justify-between"
          >
            <span>
              {myProfessionalProfile
                ? 'Meu Painel de Profissional'
                : 'Cadastrar como Profissional'}
            </span>
          </Link>
          {isAdmin && (
            <Link
              to="/admin"
              className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-[#0B4F24] text-[#F59E0B] text-xs font-bold flex items-center justify-between"
            >
              <span>Painel Administrativo</span>
              <Shield className="w-4 h-4" />
            </Link>
          )}
          <Link
            to="/suporte"
            className="w-full min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-600 hover:text-red-600 flex items-center justify-between"
          >
            <span>Privacidade / Solicitar Exclusão (LGPD)</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

// 8. MY REQUESTS PAGE (/minhas-solicitacoes)
export const MyRequestsPage: React.FC = () => {
  const {
    currentUser,
    serviceRequests,
    professionals,
    updateServiceRequestStatus,
    submitReview,
    markWhatsAppClicked,
  } = useApp();

  const [reviewingReq, setReviewingReq] = useState<ServiceRequest | null>(null);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [reviewError, setReviewError] = useState<string | null>(null);
  const [submittingReview, setSubmittingReview] = useState(false);

  if (!currentUser) {
    return (
      <div className="max-w-lg mx-auto px-4 py-14 text-center space-y-4">
        <h1 className="font-display text-xl font-bold text-[#0B4F24]">
          Entre para acompanhar suas solicitações
        </h1>
        <p className="text-xs text-slate-600">
          Para proteger sua privacidade, apenas o cliente e o profissional
          autorizados podem consultar o histórico de solicitações.
        </p>
        <Link
          to="/entrar"
          className="inline-flex min-h-[44px] items-center px-6 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-bold"
        >
          Entrar na Minha Conta
        </Link>
      </div>
    );
  }

  const clientRequests = serviceRequests.filter(
    (r) => r.clientId === currentUser.uid
  );

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewingReq) return;
    setReviewError(null);
    setSubmittingReview(true);
    try {
      await submitReview({
        requestId: reviewingReq.id,
        rating,
        comment,
      });
      setReviewingReq(null);
      setComment('');
      setRating(5);
    } catch (err: unknown) {
      setReviewError(
        err instanceof Error ? err.message : 'Erro ao enviar avaliação.'
      );
    } finally {
      setSubmittingReview(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
          Minhas Solicitações de Orçamento
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-1">
          Acompanhe o andamento dos seus pedidos, confirme a conclusão do
          serviço e avalie o atendimento.
        </p>
      </div>

      {clientRequests.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-3">
          <p className="font-display text-base font-bold text-[#0B4F24]">
            Você ainda não possui solicitações vinculadas à sua conta.
          </p>
          <Link
            to="/busca"
            className="inline-flex min-h-[44px] items-center px-5 py-2.5 rounded-xl bg-[#16A34A] text-white text-xs font-bold"
          >
            Buscar Profissionais
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {clientRequests.map((req) => {
            const prof = professionals.find((p) => p.id === req.professionalId);
            const waData = buildWhatsAppQuoteUrl({
              phone: prof?.whatsappPhone || '',
              serviceTitle: req.serviceTitle,
              neighborhood: req.neighborhood,
              cityName: req.cityName,
              description: req.description,
            });

            return (
              <div
                key={req.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div className="text-xs text-slate-500 tabular-nums">
                    Pedido #{req.id.slice(-6)} ·{' '}
                    {new Date(req.createdAt).toLocaleDateString('pt-BR')} ·{' '}
                    {req.cityName} ({req.neighborhood})
                  </div>
                  <div className="text-xs font-bold text-[#0B4F24]">
                    Status: {STATUS_LABELS[req.status]}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-2 space-y-1.5">
                    <h3 className="font-display text-base font-bold text-[#0B4F24]">
                      {req.serviceTitle} — {req.professionalName}
                    </h3>
                    <p className="text-xs text-slate-600">{req.description}</p>
                    <p className="text-[11px] text-slate-500">
                      Confirmação de conclusão: Cliente (
                      {req.clientConfirmedCompletion ? 'Confirmado' : 'Pendente'}
                      ) · Profissional (
                      {req.professionalConfirmedCompletion
                        ? 'Confirmado'
                        : 'Pendente'}
                      )
                    </p>
                  </div>

                  <div className="flex flex-col gap-2 justify-center">
                    {prof && (
                      <a
                        href={waData.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={() => markWhatsAppClicked(req.id, prof.id)}
                        className="min-h-[40px] px-3 py-2 rounded-xl bg-[#16A34A] text-white text-xs font-bold flex items-center justify-center gap-1.5"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>Conversar no WhatsApp</span>
                      </a>
                    )}

                    {req.status !== 'concluida' && req.status !== 'cancelada' && (
                      <div className="flex flex-wrap gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            updateServiceRequestStatus(
                              req.id,
                              'concluida',
                              true
                            )
                          }
                          className="flex-1 min-h-[40px] px-3 py-2 rounded-xl bg-[#0B4F24] text-white text-xs font-semibold"
                        >
                          {req.clientConfirmedCompletion
                            ? 'Aguardando confirmação do profissional'
                            : 'Confirmar Conclusão do Serviço'}
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            updateServiceRequestStatus(req.id, 'cancelada')
                          }
                          className="min-h-[40px] px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-600 hover:text-red-600"
                        >
                          Cancelar
                        </button>
                      </div>
                    )}

                    {req.status === 'concluida' && !req.reviewed && (
                      <button
                        type="button"
                        onClick={() => setReviewingReq(req)}
                        className="min-h-[40px] px-3 py-2 rounded-xl bg-[#F59E0B] text-[#0B4F24] text-xs font-bold flex items-center justify-center gap-1.5"
                      >
                        <Star className="w-4 h-4 fill-[#0B4F24]" />
                        <span>Avaliar Atendimento (1 a 5 estrelas)</span>
                      </button>
                    )}

                    {req.reviewed && (
                      <span className="text-xs font-semibold text-emerald-700 text-center">
                        Avaliação enviada ✓
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Review Modal */}
      {reviewingReq && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4"
        >
          <div className="w-full max-w-md bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-base font-bold text-[#0B4F24]">
                Avaliar {reviewingReq.professionalName}
              </h2>
              <button
                type="button"
                onClick={() => setReviewingReq(null)}
                aria-label="Fechar avaliação"
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {reviewError && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700">
                {reviewError}
              </div>
            )}

            <form onSubmit={handleReviewSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  Sua nota de 1 a 5 estrelas:
                </label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      aria-label={`${star} estrelas`}
                      className="min-h-[44px] min-w-[44px] rounded-xl border border-slate-200 flex items-center justify-center"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= rating
                            ? 'text-[#F59E0B] fill-[#F59E0B]'
                            : 'text-slate-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label
                  htmlFor="rev-comment"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Seu comentário sobre o serviço concluído *
                </label>
                <textarea
                  id="rev-comment"
                  required
                  rows={3}
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Conte como foi a pontualidade, qualidade e atendimento..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              <button
                type="submit"
                disabled={submittingReview}
                className="w-full min-h-[44px] rounded-xl bg-[#16A34A] text-white font-bold text-xs"
              >
                {submittingReview ? 'Publicando...' : 'Publicar Avaliação Real'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

// Shared Form for Professional Registration & Editing (Pages 9 & 11)
const ProfessionalForm: React.FC<{
  initial?: ProfessionalProfile | null;
  isEdit?: boolean;
}> = ({ initial, isEdit = false }) => {
  const {
    currentUser,
    categories,
    cities,
    selectedCityId,
    saveProfessionalProfile,
    compressImageFile,
  } = useApp();
  const navigate = useNavigate();

  const [name, setName] = useState(
    initial?.name || currentUser?.displayName || ''
  );
  const [commercialName, setCommercialName] = useState(
    initial?.commercialName || ''
  );
  const [whatsappPhone, setWhatsappPhone] = useState(
    initial?.whatsappPhone || ''
  );
  const [cityId, setCityId] = useState(initial?.cityId || selectedCityId);
  const currentCity =
    cities.find((c) => c.id === cityId) || cities[0];

  const [selectedHoods, setSelectedHoods] = useState<string[]>(
    initial?.neighborhoods || [currentCity.neighborhoods[0] || 'Centro']
  );
  const [selectedCats, setSelectedCats] = useState<string[]>(
    initial?.categoryIds || [categories[0]?.id || 'eletricista']
  );
  const [servicesText, setServicesText] = useState(
    initial?.servicesOffered.join(', ') || ''
  );
  const [description, setDescription] = useState(initial?.description || '');
  const [workingHours, setWorkingHours] = useState(
    initial?.workingHours || 'Segunda a Sábado, das 08h às 18h'
  );
  const [attendanceTypes, setAttendanceTypes] = useState<AttendanceType[]>(
    initial?.attendanceTypes || ['domiciliar']
  );
  const [startingPrice, setStartingPrice] = useState(
    initial?.startingPrice ? String(initial.startingPrice) : ''
  );
  const [photoUrl, setPhotoUrl] = useState(initial?.photoUrl || '');
  const [portfolioUrls, setPortfolioUrls] = useState<string[]>(
    initial?.portfolioUrls || []
  );
  const [publicContactConsent, setPublicContactConsent] = useState(
    initial?.publicContactConsent ?? true
  );
  const [isAvailable, setIsAvailable] = useState(initial?.isAvailable ?? true);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const toggleItem = <T extends string>(
    list: T[],
    setList: React.Dispatch<React.SetStateAction<T[]>>,
    item: T
  ) => {
    setList((prev) =>
      prev.includes(item) ? prev.filter((x) => x !== item) : [...prev, item]
    );
  };

  const handleProfilePhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    try {
      const dataUrl = await compressImageFile(file);
      setPhotoUrl(dataUrl);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Erro na foto de perfil.');
    }
  };

  const handlePortfolioPhoto = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (portfolioUrls.length >= 6) {
      setError('Máximo de 6 fotos no portfólio.');
      return;
    }
    setError(null);
    try {
      const dataUrl = await compressImageFile(file);
      setPortfolioUrls((prev) => [...prev, dataUrl].slice(0, 6));
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Erro na foto.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (name.trim().length < 2) {
      setError('Informe seu nome pessoal ou do responsável.');
      return;
    }
    if (!isValidBrazilianPhone(whatsappPhone)) {
      setError('Informe um WhatsApp válido com DDD (ex: 94 99123-4567).');
      return;
    }
    if (selectedHoods.length === 0) {
      setError('Selecione pelo menos um bairro de atendimento.');
      return;
    }
    if (selectedCats.length === 0) {
      setError('Selecione pelo menos uma categoria profissional.');
      return;
    }
    const parsedServices = servicesText
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    if (parsedServices.length === 0) {
      setError('Informe pelo menos um serviço oferecido.');
      return;
    }
    if (description.trim().length < 15) {
      setError(
        'Escreva uma descrição profissional com pelo menos 15 caracteres.'
      );
      return;
    }
    if (attendanceTypes.length === 0) {
      setError('Selecione pelo menos uma modalidade de atendimento.');
      return;
    }
    if (!publicContactConsent) {
      setError(
        'É necessário autorizar a exibição pública das informações comerciais e botão de WhatsApp.'
      );
      return;
    }

    setSaving(true);
    try {
      const catNames = categories
        .filter((c) => selectedCats.includes(c.id))
        .map((c) => c.name);

      await saveProfessionalProfile({
        name,
        commercialName: commercialName.trim() || undefined,
        cityId: currentCity.id,
        cityName: currentCity.name,
        neighborhoods: selectedHoods,
        categoryIds: selectedCats,
        categoryNames: catNames.length ? catNames : ['Serviços gerais'],
        servicesOffered: parsedServices,
        description,
        photoUrl: photoUrl || undefined,
        portfolioUrls,
        workingHours,
        attendanceTypes,
        startingPrice: startingPrice ? Number(startingPrice) : undefined,
        whatsappPhone,
        publicContactConsent,
        isAvailable,
        isDemo: false,
      });

      navigate('/painel-profissional');
    } catch (err: unknown) {
      setError(
        err instanceof Error
          ? err.message
          : 'Erro ao salvar cadastro profissional.'
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6"
    >
      {error && (
        <div
          role="alert"
          className="p-4 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800"
        >
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label
            htmlFor="prof-name"
            className="block text-xs font-semibold text-slate-700 mb-1"
          >
            Nome pessoal completo *
          </label>
          <input
            id="prof-name"
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ex: João Batista da Silva"
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
          />
        </div>

        <div>
          <label
            htmlFor="prof-comm"
            className="block text-xs font-semibold text-slate-700 mb-1"
          >
            Nome comercial / fantasia (opcional)
          </label>
          <input
            id="prof-comm"
            type="text"
            value={commercialName}
            onChange={(e) => setCommercialName(e.target.value)}
            placeholder="Ex: Silva Instalações Elétricas"
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label
            htmlFor="prof-phone"
            className="block text-xs font-semibold text-slate-700 mb-1"
          >
            WhatsApp de atendimento com DDD *
          </label>
          <input
            id="prof-phone"
            type="tel"
            required
            value={whatsappPhone}
            onChange={(e) => setWhatsappPhone(e.target.value)}
            placeholder="(94) 99123-4567"
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
          />
        </div>

        <div>
          <label
            htmlFor="prof-city"
            className="block text-xs font-semibold text-slate-700 mb-1"
          >
            Cidade principal *
          </label>
          <select
            id="prof-city"
            value={cityId}
            onChange={(e) => {
              setCityId(e.target.value);
              const nextCity = cities.find((c) => c.id === e.target.value);
              if (nextCity) {
                setSelectedHoods([nextCity.neighborhoods[0]]);
              }
            }}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs bg-white"
          >
            {cities
              .filter((c) => c.isActive)
              .map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} - {c.state}
                </option>
              ))}
          </select>
        </div>

        <div>
          <label
            htmlFor="prof-price"
            className="block text-xs font-semibold text-slate-700 mb-1"
          >
            Preço inicial opcional (R$)
          </label>
          <input
            id="prof-price"
            type="number"
            min={0}
            value={startingPrice}
            onChange={(e) => setStartingPrice(e.target.value)}
            placeholder="Ex: 60"
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs tabular-nums"
          />
        </div>
      </div>

      {/* Categories Selector */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="text-xs font-semibold text-slate-700">
            Categorias de atuação * (selecione uma ou mais)
          </label>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {categories
            .filter((c) => c.isActive)
            .map((cat) => {
              const active = selectedCats.includes(cat.id);
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => toggleItem(selectedCats, setSelectedCats, cat.id)}
                  className={`px-3 py-2 rounded-xl border text-left text-xs font-medium transition-colors flex items-center justify-between ${
                    active
                      ? 'bg-[#0B4F24] text-white border-[#0B4F24]'
                      : 'bg-[#F6FAF7] text-slate-700 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <span className="truncate">{cat.name}</span>
                  {active && <Check className="w-3.5 h-3.5 text-[#16A34A] shrink-0" />}
                </button>
              );
            })}
        </div>
      </div>

      {/* Neighborhoods Selector */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="text-xs font-semibold text-slate-700">
            Bairros atendidos em {currentCity.name} *
          </label>
          <button
            type="button"
            onClick={() => setSelectedHoods(currentCity.neighborhoods)}
            className="text-xs font-semibold text-[#0B4F24] underline"
          >
            Marcar todos os bairros
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {currentCity.neighborhoods.map((hood) => {
            const active = selectedHoods.includes(hood);
            return (
              <button
                key={hood}
                type="button"
                onClick={() => toggleItem(selectedHoods, setSelectedHoods, hood)}
                className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
                  active
                    ? 'bg-[#0B4F24] text-white border-[#0B4F24]'
                    : 'bg-white text-slate-700 border-slate-200'
                }`}
              >
                {hood}
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <label
          htmlFor="prof-services"
          className="block text-xs font-semibold text-slate-700 mb-1"
        >
          Serviços específicos oferecidos * (separados por vírgula)
        </label>
        <input
          id="prof-services"
          type="text"
          required
          value={servicesText}
          onChange={(e) => setServicesText(e.target.value)}
          placeholder="Ex: Instalação de ventilador, troca de fiação, revisão de quadro elétrico"
          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
        />
      </div>

      <div>
        <label
          htmlFor="prof-desc"
          className="block text-xs font-semibold text-slate-700 mb-1"
        >
          Descrição profissional e experiência *
        </label>
        <textarea
          id="prof-desc"
          required
          rows={4}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Apresente sua experiência, diferenciais e garantias de atendimento para os moradores de Breu Branco..."
          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label
            htmlFor="prof-hours"
            className="block text-xs font-semibold text-slate-700 mb-1"
          >
            Horário de atendimento *
          </label>
          <input
            id="prof-hours"
            type="text"
            required
            value={workingHours}
            onChange={(e) => setWorkingHours(e.target.value)}
            placeholder="Ex: Seg a Sáb, 08h às 18h (Plantão 24h)"
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Locais de atendimento *
          </label>
          <div className="flex flex-wrap gap-2 pt-1">
            {(
              [
                { id: 'domiciliar', label: 'A domicílio' },
                { id: 'estabelecimento', label: 'No meu estabelecimento' },
                { id: 'remoto', label: 'Remoto / Online' },
              ] as { id: AttendanceType; label: string }[]
            ).map((att) => {
              const active = attendanceTypes.includes(att.id);
              return (
                <button
                  key={att.id}
                  type="button"
                  onClick={() =>
                    toggleItem(attendanceTypes, setAttendanceTypes, att.id)
                  }
                  className={`px-3 py-2 rounded-xl border text-xs font-medium ${
                    active
                      ? 'bg-[#0B4F24] text-white border-[#0B4F24]'
                      : 'bg-white text-slate-700 border-slate-200'
                  }`}
                >
                  {att.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Profile Photo & Portfolio Upload */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2 border-t border-slate-100">
        <div className="space-y-2">
          <label className="block text-xs font-semibold text-slate-700">
            Foto de perfil ou logotipo (JPG/PNG até 5MB)
          </label>
          <div className="flex items-center gap-3">
            {photoUrl && (
              <img
                src={photoUrl}
                alt="Prévia da foto de perfil"
                className="w-14 h-14 rounded-2xl object-cover border border-slate-200"
              />
            )}
            <label className="cursor-pointer inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium text-[#0B4F24] hover:bg-slate-50">
              <Upload className="w-4 h-4" />
              <span>Escolher Foto de Perfil</span>
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={handleProfilePhoto}
                className="hidden"
              />
            </label>
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-xs font-semibold text-slate-700">
            Fotos de serviços executados (até 6 fotos reais)
          </label>
          <div className="flex items-center gap-2 flex-wrap">
            {portfolioUrls.map((url, idx) => (
              <div
                key={idx}
                className="relative w-14 h-14 rounded-xl overflow-hidden border border-slate-200"
              >
                <img
                  src={url}
                  alt={`Portfólio ${idx + 1}`}
                  className="w-full h-full object-cover"
                />
                <button
                  type="button"
                  onClick={() =>
                    setPortfolioUrls((prev) => prev.filter((_, i) => i !== idx))
                  }
                  className="absolute top-0.5 right-0.5 bg-slate-900/80 text-white rounded-full p-0.5"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
            {portfolioUrls.length < 6 && (
              <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-dashed border-slate-300 text-xs font-medium text-slate-600">
                <Upload className="w-4 h-4" />
                <span>Adicionar foto</span>
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handlePortfolioPhoto}
                  className="hidden"
                />
              </label>
            )}
          </div>
        </div>
      </div>

      <label className="flex items-start gap-2.5 pt-2 cursor-pointer">
        <input
          type="checkbox"
          required
          checked={publicContactConsent}
          onChange={(e) => setPublicContactConsent(e.target.checked)}
          className="mt-0.5 rounded border-slate-300 text-[#0B4F24]"
        />
        <span className="text-xs text-slate-600 leading-relaxed">
          Autorizo a exibição pública do meu perfil profissional, fotos de
          trabalhos e redirecionamento para meu número de WhatsApp comercial no
          JEITAKI conforme os Termos de Uso e a LGPD. Não publiquei documentos
          pessoais sensíveis nas imagens.
        </span>
      </label>

      <button
        type="submit"
        disabled={saving}
        className="w-full min-h-[48px] rounded-xl bg-[#16A34A] text-white font-bold text-sm hover:bg-[#15803d] transition-colors"
      >
        {saving
          ? 'Salvando perfil...'
          : isEdit
          ? 'Salvar Alterações do Perfil Profissional'
          : 'Enviar Cadastro Profissional para Aprovação'}
      </button>
    </form>
  );
};

// 9. PROFESSIONAL REGISTER PAGE (/seja-profissional)
export const ProfessionalRegisterPage: React.FC = () => {
  const { currentUser, myProfessionalProfile, selectedCity } = useApp();

  if (myProfessionalProfile) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12 text-center space-y-4">
        <div className="bg-white rounded-3xl border border-slate-200 p-8 space-y-4">
          <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
            Você já possui um cadastro profissional
          </h1>
          <p className="text-xs text-slate-600">
            Status atual do seu perfil:{' '}
            <strong className="text-[#0B4F24]">
              {myProfessionalProfile.status}
            </strong>
          </p>
          <div className="flex flex-wrap justify-center gap-3 pt-2">
            <Link
              to="/painel-profissional"
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-bold flex items-center"
            >
              Acessar Painel do Profissional
            </Link>
            <Link
              to="/painel-profissional/editar"
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#16A34A] text-white text-xs font-bold flex items-center"
            >
              Editar Meu Perfil
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="space-y-1">
        <p className="text-xs font-semibold text-[#16A34A]">
          Plano Básico 100% Gratuito · Sem exigência de cartão
        </p>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#0B4F24]">
          Cadastro de Profissional em {selectedCity.name} - {selectedCity.state}
        </h1>
        <p className="text-xs sm:text-sm text-slate-600">
          Divulgue seu trabalho para moradores da cidade e receba solicitações
          de orçamento diretamente no seu WhatsApp. Todo cadastro passa por
          aprovação administrativa antes de aparecer na busca pública.
        </p>
      </div>

      {!currentUser ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
          <h2 className="font-display text-base font-bold text-[#0B4F24]">
            Primeiro passo: Entre com sua conta
          </h2>
          <p className="text-xs text-slate-600">
            Para garantir que apenas você possa editar seu perfil e gerenciar
            suas solicitações, entre com sua conta Google ou e-mail antes de
            preencher seus dados profissionais.
          </p>
          <Link
            to="/entrar"
            className="inline-flex min-h-[44px] items-center px-6 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-bold"
          >
            Entrar ou Criar Conta Agora
          </Link>
        </div>
      ) : (
        <ProfessionalForm />
      )}
    </div>
  );
};

// 10. PROFESSIONAL DASHBOARD PAGE (/painel-profissional)
export const ProfessionalDashboardPage: React.FC<{
  onShareProf: (prof: ProfessionalProfile) => void;
}> = ({ onShareProf }) => {
  const {
    currentUser,
    myProfessionalProfile,
    serviceRequests,
    reviews,
    toggleProfessionalAvailability,
    updateServiceRequestStatus,
  } = useApp();

  if (!currentUser) {
    return (
      <div className="max-w-md mx-auto px-4 py-14 text-center space-y-4">
        <h1 className="font-display text-xl font-bold text-[#0B4F24]">
          Entre para acessar o Painel do Profissional
        </h1>
        <Link
          to="/entrar"
          className="inline-flex min-h-[44px] items-center px-6 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-bold"
        >
          Fazer Login
        </Link>
      </div>
    );
  }

  if (!myProfessionalProfile) {
    return (
      <div className="max-w-lg mx-auto px-4 py-14 text-center space-y-4">
        <h1 className="font-display text-xl font-bold text-[#0B4F24]">
          Você ainda não cadastrou um perfil profissional
        </h1>
        <Link
          to="/seja-profissional"
          className="inline-flex min-h-[44px] items-center px-6 py-2.5 rounded-xl bg-[#16A34A] text-white text-xs font-bold"
        >
          Cadastrar Meu Perfil Gratuitamente
        </Link>
      </div>
    );
  }

  const myRequests = serviceRequests.filter(
    (r) =>
      r.professionalId === myProfessionalProfile.id ||
      r.professionalUserId === currentUser.uid
  );
  const myReviews = reviews.filter(
    (r) => r.professionalId === myProfessionalProfile.id
  );

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header & Approval Banner */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs text-slate-500">
            Status cadastral:{' '}
            <strong className="text-[#0B4F24]">
              {myProfessionalProfile.status === 'approved'
                ? 'Aprovado e visível na busca pública'
                : myProfessionalProfile.status === 'pending'
                ? 'Aguardando aprovação do administrador'
                : myProfessionalProfile.status === 'correction_needed'
                ? 'Correção solicitada pela administração'
                : myProfessionalProfile.status}
            </strong>
          </div>
          <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
            {myProfessionalProfile.commercialName || myProfessionalProfile.name}
          </h1>
          {myProfessionalProfile.verificationNote && (
            <p className="text-xs text-amber-800 font-medium">
              Observação da administração: {myProfessionalProfile.verificationNote}
            </p>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() =>
              toggleProfessionalAvailability(!myProfessionalProfile.isAvailable)
            }
            className={`min-h-[44px] px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 border ${
              myProfessionalProfile.isAvailable
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-amber-50 border-amber-200 text-amber-900'
            }`}
          >
            {myProfessionalProfile.isAvailable ? (
              <>
                <PauseCircle className="w-4 h-4" />
                <span>Recebendo pedidos (Pausar)</span>
              </>
            ) : (
              <>
                <PlayCircle className="w-4 h-4" />
                <span>Agenda pausada (Reativar)</span>
              </>
            )}
          </button>

          <Link
            to="/painel-profissional/editar"
            className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-[#0B4F24] hover:bg-slate-50 flex items-center gap-1.5"
          >
            <Edit3 className="w-4 h-4" />
            <span>Editar Perfil</span>
          </Link>

          <Link
            to={`/profissional/${myProfessionalProfile.slug}`}
            className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-[#0B4F24] hover:bg-slate-50 flex items-center gap-1.5"
          >
            <Eye className="w-4 h-4" />
            <span>Ver Página Pública</span>
          </Link>

          <button
            type="button"
            onClick={() => onShareProf(myProfessionalProfile)}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-[#0B4F24] text-[#F59E0B] text-xs font-bold flex items-center gap-1.5"
          >
            <QrCode className="w-4 h-4" />
            <span>Meu QR Code</span>
          </button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 tabular-nums">
        <div className="bg-white rounded-2xl border border-slate-200 p-4">
          <span className="text-xs text-slate-500 block">
            Visualizações do Perfil
          </span>
          <span className="font-display text-2xl font-bold text-[#0B4F24] mt-1 block">
            {myProfessionalProfile.viewsCount}
          </span>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-4">
          <span className="text-xs text-slate-500 block">
            Solicitações Recebidas
          </span>
          <span className="font-display text-2xl font-bold text-[#0B4F24] mt-1 block">
            {myRequests.length}
          </span>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-4">
          <span className="text-xs text-slate-500 block">
            Cliques no WhatsApp
          </span>
          <span className="font-display text-2xl font-bold text-[#0B4F24] mt-1 block">
            {myProfessionalProfile.whatsappClicksCount}
          </span>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-4">
          <span className="text-xs text-slate-500 block">
            Serviços Concluídos
          </span>
          <span className="font-display text-2xl font-bold text-[#16A34A] mt-1 block">
            {myProfessionalProfile.completedJobsCount}
          </span>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-4">
          <span className="text-xs text-slate-500 block">Avaliação Média</span>
          <span className="font-display text-2xl font-bold text-[#0B4F24] mt-1 block">
            {myReviews.length > 0
              ? `${myProfessionalProfile.ratingAvg.toFixed(1)} ★`
              : '—'}
          </span>
        </div>
      </div>

      {/* Received Service Requests */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
        <h2 className="font-display text-lg font-bold text-[#0B4F24]">
          Solicitações de Orçamento Recebidas ({myRequests.length})
        </h2>

        {myRequests.length === 0 ? (
          <p className="text-xs text-slate-500 py-4">
            Nenhuma solicitação recebida ainda. Compartilhe o link ou QR Code do
            seu perfil em grupos e redes sociais de {myProfessionalProfile.cityName}!
          </p>
        ) : (
          <div className="space-y-4">
            {myRequests.map((req) => (
              <div
                key={req.id}
                className="p-4 rounded-2xl bg-[#F6FAF7] border border-slate-200 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="font-bold text-[#0B4F24]">
                    Cliente: {req.clientName} · Bairro: {req.neighborhood}
                  </span>
                  <span className="text-slate-500 tabular-nums">
                    {new Date(req.createdAt).toLocaleString('pt-BR')} · Status:{' '}
                    <strong className="text-[#0B4F24]">
                      {STATUS_LABELS[req.status]}
                    </strong>
                  </span>
                </div>

                <p className="text-xs text-slate-700">
                  <strong>{req.serviceTitle}:</strong> {req.description}
                </p>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-200/80">
                  <a
                    href={`https://wa.me/55${req.clientPhone.replace(
                      /\D/g,
                      ''
                    )}?text=${encodeURIComponent(
                      `Olá ${req.clientName}! Recebi sua solicitação de orçamento para ${req.serviceTitle} pelo JEITAKI.`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="min-h-[38px] px-3 py-1.5 rounded-xl bg-[#16A34A] text-white text-xs font-bold inline-flex items-center gap-1.5"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Chamar Cliente ({req.clientPhone})</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>

                  <div className="flex flex-wrap items-center gap-2">
                    <label
                      htmlFor={`status-${req.id}`}
                      className="text-xs text-slate-600"
                    >
                      Atualizar etapa:
                    </label>
                    <select
                      id={`status-${req.id}`}
                      value={req.status}
                      onChange={(e) =>
                        updateServiceRequestStatus(
                          req.id,
                          e.target.value as ServiceRequestStatus,
                          e.target.value === 'concluida'
                        )
                      }
                      className="px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-xs font-medium"
                    >
                      <option value="nova">Nova</option>
                      <option value="em_contato">Em contato</option>
                      <option value="orcamento_enviado">
                        Orçamento enviado
                      </option>
                      <option value="aceita">Aceita</option>
                      <option value="em_andamento">Serviço em andamento</option>
                      <option value="concluida">
                        Confirmar conclusão (Profissional)
                      </option>
                      <option value="cancelada">Cancelada</option>
                    </select>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// 11. PROFESSIONAL EDIT PAGE (/painel-profissional/editar)
export const ProfessionalEditPage: React.FC = () => {
  const { currentUser, myProfessionalProfile } = useApp();

  if (!currentUser || !myProfessionalProfile) {
    return (
      <div className="max-w-md mx-auto px-4 py-14 text-center space-y-4">
        <h1 className="font-display text-xl font-bold text-[#0B4F24]">
          Perfil profissional não localizado
        </h1>
        <Link
          to="/seja-profissional"
          className="inline-flex min-h-[44px] items-center px-5 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-bold"
        >
          Criar Perfil Profissional
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#0B4F24]">
            Editar Meu Perfil Profissional
          </h1>
          <p className="text-xs text-slate-600">
            Atualize seus serviços, bairros atendidos, fotos de trabalhos e
            horários.
          </p>
        </div>
        <Link
          to="/painel-profissional"
          className="text-xs font-semibold text-[#0B4F24] underline"
        >
          Voltar ao Painel
        </Link>
      </div>

      <ProfessionalForm initial={myProfessionalProfile} isEdit={true} />
    </div>
  );
};
