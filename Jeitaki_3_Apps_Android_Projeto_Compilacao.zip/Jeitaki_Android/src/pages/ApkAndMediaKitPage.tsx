import React, { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import {
  Check,
  Copy,
  Download,
  ExternalLink,
  FileCode2,
  Image as ImageIcon,
  MessageCircle,
  Package,
  QrCode,
  Share2,
  ShieldCheck,
  Smartphone,
  Sparkles,
} from 'lucide-react';
import { OFFICIAL_BRAND_LOGO } from '../components/CategoryIcon';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const ApkAndMediaKitPage: React.FC = () => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const defaultPublicUrl =
    typeof window !== 'undefined' &&
    !window.location.origin.includes('localhost')
      ? window.location.origin
      : 'https://ais-pre-b3pfo4mohumpj77pva4qcl-388517199602.us-east1.run.app';

  const [customPublicUrl, setCustomPublicUrl] = useState(defaultPublicUrl);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [generatingPoster, setGeneratingPoster] = useState(false);
  const qrContainerRef = useRef<HTMLDivElement>(null);

  const cleanTargetUrl = customPublicUrl.trim() || defaultPublicUrl;
  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(
    cleanTargetUrl
  )}`;

  const copyText = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2500);
    } catch {
      // ignore
    }
  };

  const whatsappMoradoresText = `🌱 *Chegou o Jeita Aqui — Breu Branco!* 🏡✨
_"Precisou? Tem quem resolva!"_

Agora ficou muito mais fácil encontrar *Eletricista, Pedreiro, Encanador, Diarista, Técnico de Ar-Condicionado, Pintor, Mecânico, Montador de Móveis e outros profissionais* aqui em *Breu Branco - PA*!

✅ Sem taxa para moradores
✅ Solicite orçamento rápido e fale direto no WhatsApp do profissional
✅ Funciona direto no celular sem pesar a memória

📲 *Acesse ou instale agora no seu celular:*
${cleanTargetUrl}`;

  const whatsappProfissionaisText = `👷‍♂️🔧 *Trabalha por conta própria em Breu Branco - PA?*

Cadastre seu perfil *100% GRÁTIS* no aplicativo *Jeita Aqui — Breu Branco* e receba pedidos de orçamento dos moradores direto no seu WhatsApp!

📌 Categorias abertas: Eletricista, Pedreiro, Encanador, Diarista, Refrigeração, Câmeras/Alarmes, Pintor, Mecânico, Montador de Móveis, Jardineiro, Informática e Serviços Gerais.

📲 *Cadastre seu perfil profissional gratuitamente aqui:*
${cleanTargetUrl}/seja-profissional`;

  const handleDownloadCapacitorConfig = () => {
    const configContent = JSON.stringify(
      {
        appId: 'br.com.jeitaaqui.breubranco',
        appName: 'Jeita Aqui Breu Branco',
        webDir: 'dist',
        server: {
          url: cleanTargetUrl,
          cleartext: false,
          androidScheme: 'https',
        },
        plugins: {
          SplashScreen: {
            launchShowDuration: 1500,
            backgroundColor: '#0B4F24',
            androidScaleType: 'CENTER_CROP',
            showSpinner: false,
          },
        },
      },
      null,
      2
    );
    const blob = new Blob([configContent], {
      type: 'application/json;charset=utf-8;',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'capacitor.config.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadPosterPNG = async () => {
    setGeneratingPoster(true);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 1080;
      canvas.height = 1350;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Background gradient (Forest Green to Deep Emerald)
      const bgGrad = ctx.createLinearGradient(0, 0, 0, 1350);
      bgGrad.addColorStop(0, '#0B4F24');
      bgGrad.addColorStop(0.55, '#073B1A');
      bgGrad.addColorStop(1, '#052912');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, 1080, 1350);

      // Decorative Golden Top Bar
      ctx.fillStyle = '#F59E0B';
      ctx.fillRect(0, 0, 1080, 18);

      // White Card Container for Official Logo
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.roundRect(290, 60, 500, 390, 36);
      ctx.fill();

      // Load Official Logo
      const logoImg = new Image();
      logoImg.crossOrigin = 'anonymous';
      logoImg.src = OFFICIAL_BRAND_LOGO;
      await new Promise((res, rej) => {
        logoImg.onload = res;
        logoImg.onerror = rej;
      });
      ctx.drawImage(logoImg, 345, 75, 390, 360);

      // Headline & Slogan
      ctx.textAlign = 'center';
      ctx.fillStyle = '#F59E0B';
      ctx.font = 'bold 42px Poppins, sans-serif';
      ctx.fillText('“Precisou? Tem quem resolva!”', 540, 520);

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 48px Poppins, sans-serif';
      ctx.fillText('Encontre Profissionais de Confiança', 540, 585);
      ctx.fillText('em Breu Branco - PA', 540, 645);

      ctx.fillStyle = '#D1FAE5';
      ctx.font = '500 26px Inter, sans-serif';
      ctx.fillText(
        'Eletricista · Pedreiro · Encanador · Diarista · Ar-Condicionado · Pintor · Mecânico e mais',
        540,
        705
      );

      // QR Code White Box
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.roundRect(330, 750, 420, 420, 32);
      ctx.fill();

      // Convert SVG QR Code to Image and draw onto Canvas
      const svgEl = qrContainerRef.current?.querySelector('svg');
      if (svgEl) {
        const svgData = new XMLSerializer().serializeToString(svgEl);
        const svgBlob = new Blob([svgData], {
          type: 'image/svg+xml;charset=utf-8',
        });
        const svgUrl = URL.createObjectURL(svgBlob);
        const qrImg = new Image();
        qrImg.src = svgUrl;
        await new Promise((res, rej) => {
          qrImg.onload = res;
          qrImg.onerror = rej;
        });
        ctx.drawImage(qrImg, 365, 785, 350, 350);
        URL.revokeObjectURL(svgUrl);
      }

      // Bottom Call to Action
      ctx.fillStyle = '#F59E0B';
      ctx.font = 'bold 30px Poppins, sans-serif';
      ctx.fillText(
        'Aponte a câmera do celular para o QR Code acima',
        540,
        1235
      );

      ctx.fillStyle = '#FFFFFF';
      ctx.font = '500 22px Inter, sans-serif';
      ctx.fillText(cleanTargetUrl, 540, 1285);

      const dataUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = 'Cartaz-JeitaAqui-BreuBranco.png';
      a.click();
    } finally {
      setGeneratingPoster(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-10">
      {/* Hero Banner with Official Logo & APK / PWA Overview */}
      <section className="bg-[#0B4F24] text-white rounded-3xl p-6 sm:p-10 border border-emerald-900 shadow-lg">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-4 flex flex-col items-center">
            <div className="bg-white rounded-3xl p-5 shadow-md max-w-[260px] w-full flex flex-col items-center text-center">
              <img
                src={OFFICIAL_BRAND_LOGO}
                alt="Logo Oficial Jeita Aqui Breu Branco"
                referrerPolicy="no-referrer"
                className="w-48 h-48 object-contain"
              />
              <span className="mt-2 text-[11px] font-bold text-[#0B4F24] tracking-tight">
                Identidade Visual Oficial Aplicada
              </span>
            </div>
          </div>

          <div className="lg:col-span-8 space-y-4">
            <p className="text-xs font-semibold text-[#F59E0B]">
              Central de Instalação Mobile, Empacotamento .APK e Kit de Divulgação
            </p>
            <h1
              className="font-display text-2xl sm:text-4xl font-extrabold text-white leading-tight"
              style={{ textWrap: 'balance' }}
            >
              Jeita Aqui Breu Branco pronto para instalar e divulgar
            </h1>
            <p className="text-sm text-emerald-100 leading-relaxed max-w-2xl">
              Seu aplicativo já está configurado com a identidade visual oficial{' '}
              <strong>Jeita Aqui — Breu Branco</strong>, ícones de tela inicial
              de alta resolução (192px, 512px e Maskable Android), manifesto
              nativo e suporte completo para instalação imediata ou geração do
              arquivo instalador <code>.apk</code>.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              {isInstalled ? (
                <div className="px-4 py-2.5 rounded-xl bg-emerald-800/80 border border-emerald-600 text-xs font-semibold text-white inline-flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#F59E0B]" />
                  <span>Aplicativo já instalado neste aparelho</span>
                </div>
              ) : (
                isInstallable && (
                  <button
                    type="button"
                    onClick={install}
                    className="min-h-[48px] px-6 py-3 rounded-xl bg-[#F59E0B] text-[#0B4F24] font-bold text-sm hover:bg-[#fbbf24] transition-colors inline-flex items-center gap-2"
                  >
                    <Download className="w-5 h-5" />
                    <span>Instalar Direto no Celular Agora</span>
                  </button>
                )
              )}

              <a
                href="#gerar-apk"
                className="min-h-[48px] px-5 py-3 rounded-xl bg-[#16A34A] text-white font-bold text-xs sm:text-sm hover:bg-[#15803d] transition-colors inline-flex items-center gap-2"
              >
                <Package className="w-4 h-4" />
                <span>Baixar Arquivo .APK para Android</span>
              </a>

              <a
                href="#kit-divulgacao"
                className="min-h-[48px] px-5 py-3 rounded-xl border border-emerald-600 text-white font-semibold text-xs sm:text-sm hover:bg-emerald-900/60 transition-colors inline-flex items-center gap-2"
              >
                <QrCode className="w-4 h-4 text-[#F59E0B]" />
                <span>Baixar Cartaz e Textos para WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* URL Configuration Bar */}
      <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="font-display text-base font-bold text-[#0B4F24]">
              Endereço Público do Aplicativo (URL Oficial)
            </h2>
            <p className="text-xs text-slate-600">
              Confirme abaixo o link público publicado do seu aplicativo. Ele é
              usado no QR Code, nos convites de WhatsApp e para gerar o arquivo{' '}
              <code>.apk</code>.
            </p>
          </div>
          <button
            type="button"
            onClick={() => copyText('url', cleanTargetUrl)}
            className="min-h-[40px] px-4 py-2 rounded-xl bg-[#0B4F24] text-white text-xs font-semibold hover:bg-[#0E662F] inline-flex items-center gap-2 self-start sm:self-auto shrink-0"
          >
            <Copy className="w-4 h-4 text-[#F59E0B]" />
            <span>
              {copiedKey === 'url' ? 'Link Copiado!' : 'Copiar Link do App'}
            </span>
          </button>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <label htmlFor="public-app-url-input" className="sr-only">
            URL pública do aplicativo
          </label>
          <input
            id="public-app-url-input"
            type="url"
            value={customPublicUrl}
            onChange={(e) => setCustomPublicUrl(e.target.value)}
            className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm text-[#0B4F24] font-mono bg-[#F6FAF7]"
          />
        </div>
      </section>

      {/* Two Ways to Distribute on Android & iOS */}
      <section id="gerar-apk" className="space-y-6">
        <div>
          <h2 className="font-display text-2xl font-bold text-[#0B4F24]">
            Como instalar e gerar o arquivo .APK para Android
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Transparência técnica: escolha entre a instalação direta sem bloqueio
            do Android ou o download do arquivo <code>.apk</code> compilado.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Card 1: Direct WebAPK Installation (Best for WhatsApp sharing) */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col justify-between space-y-5">
            <div className="space-y-3">
              <div className="w-11 h-11 rounded-xl bg-[#F6FAF7] text-[#0B4F24] flex items-center justify-center">
                <Smartphone className="w-6 h-6 text-[#16A34A]" />
              </div>
              <p className="text-xs font-bold text-[#16A34A]">
                1. Mais Fácil para os Moradores (Recomendado)
              </p>
              <h3 className="font-display text-lg font-bold text-[#0B4F24]">
                Instalação Direta por Link (WebAPK Nativo do Chrome)
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Quando você envia um arquivo <code>.apk</code> solto no WhatsApp,
                o celular Android bloqueia a instalação mostrando o aviso de{' '}
                <em>&ldquo;Fonte Desconhecida / App Nocivo&rdquo;</em>, o que
                assusta muitos moradores.
              </p>
              <p className="text-xs text-slate-600 leading-relaxed">
                Já pelo <strong>link oficial HTTPS</strong>, o próprio Google
                Chrome do morador cria e instala o aplicativo assinado com a
                logo <strong>Jeita Aqui Breu Branco</strong> na tela inicial em
                1 toque, sem nenhum alerta de bloqueio e funcionando também em
                iPhone!
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100 space-y-2">
              <div className="p-3 rounded-xl bg-[#F6FAF7] text-[11px] text-slate-700 space-y-1">
                <p className="font-bold text-[#0B4F24]">
                  Como o morador instala em 5 segundos:
                </p>
                <p>
                  • <strong>No Android:</strong> Abrir o link no Chrome e tocar
                  em <strong>&ldquo;Instalar aplicativo&rdquo;</strong>.
                </p>
                <p>
                  • <strong>No iPhone:</strong> Abrir no Safari, tocar em{' '}
                  <strong>Compartilhar</strong> e em{' '}
                  <strong>&ldquo;Adicionar à Tela de Início&rdquo;</strong>.
                </p>
              </div>
            </div>
          </div>

          {/* Card 2: 1-Click Signed APK Generator via PWABuilder */}
          <div className="bg-white rounded-2xl border-2 border-[#16A34A] p-6 flex flex-col justify-between space-y-5 shadow-xs">
            <div className="space-y-3">
              <div className="w-11 h-11 rounded-xl bg-[#0B4F24] text-[#F59E0B] flex items-center justify-center">
                <Package className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-[#0B4F24]">
                2. Gerar Arquivo .APK e .AAB Assinado em 1 Minuto
              </p>
              <h3 className="font-display text-lg font-bold text-[#0B4F24]">
                Compilador Oficial PWABuilder (Sem Programar)
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                O ambiente web do Google AI Studio roda em servidor Node.js e
                não possui o SDK Java/Android de 4 GB instalado localmente. Por
                isso, deixamos todos os arquivos exigidos pelo Android (
                <code>manifest.webmanifest</code>, <code>assetlinks.json</code>{' '}
                e ícones oficiais <code>512x512</code>) 100% prontos!
              </p>
              <ol className="text-xs text-slate-700 space-y-2 list-decimal list-inside bg-[#F6FAF7] p-3.5 rounded-xl border border-slate-200">
                <li>
                  Primeiro, clique em <strong>Publish (Publicar)</strong> no
                  topo do Google AI Studio para ativar o link público.
                </li>
                <li>
                  Clique no botão verde abaixo para abrir o{' '}
                  <strong>PWABuilder</strong> já com o seu link preenchido.
                </li>
                <li>
                  Clique em <strong>&ldquo;Package for stores&rdquo;</strong>{' '}
                  &rarr; <strong>&ldquo;Android&rdquo;</strong> &rarr;{' '}
                  <strong>&ldquo;Download Package&rdquo;</strong>.
                </li>
                <li>
                  Abra o arquivo <code>.zip</code> baixado: lá dentro está o seu{' '}
                  <strong>arquivo .APK assinado</strong> pronto para enviar no
                  WhatsApp e o <strong>.AAB</strong> para a Google Play Store!
                </li>
              </ol>
            </div>

            <div className="pt-3 border-t border-slate-100 space-y-2.5">
              <a
                href={pwaBuilderUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full min-h-[48px] px-4 py-3 rounded-xl bg-[#16A34A] text-white font-bold text-xs sm:text-sm hover:bg-[#15803d] transition-colors flex items-center justify-center gap-2"
              >
                <span>Gerar e Baixar .APK no PWABuilder</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Card 3: Native Capacitor + GitHub Actions Automated APK */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col justify-between space-y-5">
            <div className="space-y-3">
              <div className="w-11 h-11 rounded-xl bg-[#F6FAF7] text-[#0B4F24] flex items-center justify-center">
                <FileCode2 className="w-6 h-6 text-[#F59E0B]" />
              </div>
              <p className="text-xs font-bold text-[#F59E0B]">
                3. Projeto Android Nativo Incluso no Código
              </p>
              <h3 className="font-display text-lg font-bold text-[#0B4F24]">
                Pacote Capacitor + Compilador GitHub Actions
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Também já incluímos dentro do código-fonte do projeto os
                arquivos de empacotamento Android nativo:
              </p>
              <ul className="text-xs text-slate-600 space-y-1.5">
                <li className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#16A34A] shrink-0" />
                  <span>
                    <code>/capacitor.config.json</code> (ID:{' '}
                    <code>br.com.jeitaaqui.breubranco</code>)
                  </span>
                </li>
                <li className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#16A34A] shrink-0" />
                  <span>
                    <code>/public/.well-known/assetlinks.json</code> (Vínculo
                    Android TWA)
                  </span>
                </li>
                <li className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#16A34A] shrink-0" />
                  <span>
                    <code>/.github/workflows/build-android-apk.yml</code>{' '}
                    (Compila o <code>.apk</code> automaticamente na nuvem ao
                    exportar para o GitHub)
                  </span>
                </li>
              </ul>
            </div>

            <div className="pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={handleDownloadCapacitorConfig}
                className="w-full min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-[#0B4F24] hover:bg-slate-50 flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4 text-[#16A34A]" />
                <span>Baixar capacitor.config.json</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Promotional Kit for Breu Branco (Poster + WhatsApp Broadcast Copy) */}
      <section
        id="kit-divulgacao"
        className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6"
      >
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <p className="text-xs font-bold text-[#16A34A]">
              Comece a Divulgar Hoje em Breu Branco - PA
            </p>
            <h2 className="font-display text-2xl font-bold text-[#0B4F24]">
              Kit de Divulgação Oficial (Cartaz QR Code + Textos Prontos)
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Baixe o cartaz em alta resolução para postar no Status do
              WhatsApp, Instagram ou imprimir em comércios de Breu Branco.
            </p>
          </div>
          <button
            type="button"
            disabled={generatingPoster}
            onClick={handleDownloadPosterPNG}
            className="min-h-[48px] px-6 py-3 rounded-xl bg-[#0B4F24] text-white font-bold text-xs sm:text-sm hover:bg-[#0E662F] transition-colors inline-flex items-center gap-2 shrink-0"
          >
            <ImageIcon className="w-4 h-4 text-[#F59E0B]" />
            <span>
              {generatingPoster
                ? 'Gerando Cartaz PNG...'
                : 'Baixar Cartaz Oficial com QR Code (PNG)'}
            </span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Visual Poster Preview with Official Logo & QR */}
          <div className="lg:col-span-5">
            <div className="bg-gradient-to-b from-[#0B4F24] to-[#052912] rounded-3xl p-6 text-white text-center space-y-4 border-t-8 border-[#F59E0B] shadow-md">
              <div className="bg-white rounded-2xl p-4 mx-auto max-w-[210px] shadow-xs">
                <img
                  src={OFFICIAL_BRAND_LOGO}
                  alt="Logo Jeita Aqui Breu Branco"
                  referrerPolicy="no-referrer"
                  className="w-40 h-36 mx-auto object-contain"
                />
              </div>

              <div className="space-y-1">
                <p className="text-sm font-bold text-[#F59E0B]">
                  &ldquo;Precisou? Tem quem resolva!&rdquo;
                </p>
                <h3 className="font-display text-lg font-extrabold text-white">
                  Encontre Profissionais em Breu Branco - PA
                </h3>
                <p className="text-[11px] text-emerald-100">
                  Eletricista · Pedreiro · Encanador · Diarista · Refrigeração ·
                  Pintor · Mecânico
                </p>
              </div>

              <div
                ref={qrContainerRef}
                className="bg-white p-4 rounded-2xl inline-block mx-auto shadow-xs"
              >
                <QRCodeSVG
                  value={cleanTargetUrl}
                  size={170}
                  bgColor="#FFFFFF"
                  fgColor="#0B4F24"
                  level="M"
                />
              </div>

              <div className="space-y-1">
                <p className="text-xs font-bold text-[#F59E0B]">
                  Aponte a câmera do celular para acessar
                </p>
                <p className="text-[11px] text-emerald-200 break-all font-mono">
                  {cleanTargetUrl}
                </p>
              </div>
            </div>
          </div>

          {/* Right: Ready-to-Share WhatsApp Messages */}
          <div className="lg:col-span-7 space-y-5">
            <div className="p-5 rounded-2xl bg-[#F6FAF7] border border-slate-200 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-display text-sm font-bold text-[#0B4F24] flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#F59E0B]" />
                  <span>
                    Mensagem 1: Para Grupos de Moradores de Breu Branco
                  </span>
                </h3>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      copyText('msg_moradores', whatsappMoradoresText)
                    }
                    className="min-h-[38px] px-3 py-1.5 rounded-xl bg-white border border-slate-300 text-xs font-semibold text-[#0B4F24] hover:bg-slate-50 inline-flex items-center gap-1.5"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>
                      {copiedKey === 'msg_moradores'
                        ? 'Copiado!'
                        : 'Copiar Texto'}
                    </span>
                  </button>
                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(
                      whatsappMoradoresText
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="min-h-[38px] px-3 py-1.5 rounded-xl bg-[#16A34A] text-white text-xs font-bold hover:bg-[#15803d] inline-flex items-center gap-1.5"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Enviar no WhatsApp</span>
                  </a>
                </div>
              </div>
              <pre className="text-xs text-slate-700 whitespace-pre-wrap font-sans bg-white p-3.5 rounded-xl border border-slate-200 leading-relaxed">
                {whatsappMoradoresText}
              </pre>
            </div>

            <div className="p-5 rounded-2xl bg-[#F6FAF7] border border-slate-200 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-display text-sm font-bold text-[#0B4F24] flex items-center gap-2">
                  <Share2 className="w-4 h-4 text-[#16A34A]" />
                  <span>
                    Mensagem 2: Para Convidar Profissionais e Autônomos
                  </span>
                </h3>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      copyText('msg_profs', whatsappProfissionaisText)
                    }
                    className="min-h-[38px] px-3 py-1.5 rounded-xl bg-white border border-slate-300 text-xs font-semibold text-[#0B4F24] hover:bg-slate-50 inline-flex items-center gap-1.5"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>
                      {copiedKey === 'msg_profs' ? 'Copiado!' : 'Copiar Texto'}
                    </span>
                  </button>
                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(
                      whatsappProfissionaisText
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="min-h-[38px] px-3 py-1.5 rounded-xl bg-[#0B4F24] text-white text-xs font-bold hover:bg-[#0E662F] inline-flex items-center gap-1.5"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-[#F59E0B]" />
                    <span>Convidar no WhatsApp</span>
                  </a>
                </div>
              </div>
              <pre className="text-xs text-slate-700 whitespace-pre-wrap font-sans bg-white p-3.5 rounded-xl border border-slate-200 leading-relaxed">
                {whatsappProfissionaisText}
              </pre>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <Link
                to="/seja-profissional"
                className="text-xs font-bold text-[#0B4F24] hover:text-[#16A34A] underline underline-offset-4"
              >
                Testar página de Cadastro de Profissionais &rarr;
              </Link>
              <Link
                to="/admin"
                className="text-xs font-bold text-[#0B4F24] hover:text-[#16A34A] underline underline-offset-4"
              >
                Ir para o Painel Administrativo &rarr;
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
