/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import {
  BrowserRouter,
  Route,
  Routes,
  useLocation,
  Navigate,
} from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { VariantNavbar } from './components/VariantNavbar';
import { APP_VARIANT } from './appVariant';
import { Footer } from './components/Footer';
import {
  PWAInstallModal,
  QuoteRequestModal,
  ReportModal,
  ShareQRModal,
} from './components/Modals';
import {
  CategoryPage,
  HomePage,
  ProfessionalPublicPage,
  SearchPage,
  StandaloneQuotePage,
} from './pages/HomeAndSearchPages';
import {
  AuthPage,
  MyAccountPage,
  MyRequestsPage,
  ProfessionalDashboardPage,
  ProfessionalEditPage,
  ProfessionalRegisterPage,
} from './pages/UserAndProfPages';
import {
  AdminCategoriesCitiesPage,
  AdminDashboardPage,
  AdminProfessionalsPage,
  AdminReportsPage,
  AdminRequestsPage,
  NotFoundPage,
  PrivacyPage,
  SupportAndReportsPage,
  TermsPage,
} from './pages/AdminAndLegalPages';
import { ApkAndMediaKitPage } from './pages/ApkAndMediaKitPage';
import { ProfessionalProfile } from './types/jeitaki';

const ScrollToTop: React.FC = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const AppShell: React.FC = () => {
  const [quoteProf, setQuoteProf] = useState<ProfessionalProfile | null>(null);
  const [pwaModalOpen, setPwaModalOpen] = useState(false);
  const [shareModal, setShareModal] = useState<{
    open: boolean;
    title?: string;
    subtitle?: string;
    url?: string;
  }>({ open: false });
  const [reportTarget, setReportTarget] = useState<{
    type: 'professional' | 'review';
    id: string;
    name: string;
  } | null>(null);

  const handleShareProf = (prof: ProfessionalProfile) => {
    const origin =
      typeof window !== 'undefined' ? window.location.origin : '';
    setShareModal({
      open: true,
      title: `${prof.commercialName || prof.name} no JEITAKI`,
      subtitle: `${prof.categoryNames.join(', ')} em ${prof.cityName} - PA`,
      url: `${origin}/profissional/${prof.slug}`,
    });
  };

  return (
    <div className="min-h-screen flex flex-col pb-16 md:pb-0 bg-[#F6FAF7] text-[#0B4F24]">
      <ScrollToTop />
      <VariantNavbar />

      <main className="flex-1">
        {APP_VARIANT === 'cliente' ? (
          <Routes>
            <Route path="/" element={<HomePage onRequestQuote={setQuoteProf} onOpenShareQR={() => setShareModal({ open:true })} />} />
            <Route path="/busca" element={<SearchPage onRequestQuote={setQuoteProf} />} />
            <Route path="/categoria/:slug" element={<CategoryPage onRequestQuote={setQuoteProf} />} />
            <Route path="/profissional/:slugOrId" element={<ProfessionalPublicPage onRequestQuote={setQuoteProf} onShareProf={handleShareProf} onReportTarget={setReportTarget} />} />
            <Route path="/orcamento/:profId" element={<StandaloneQuotePage onRequestQuote={setQuoteProf} />} />
            <Route path="/entrar" element={<AuthPage />} />
            <Route path="/minha-conta" element={<MyAccountPage />} />
            <Route path="/minhas-solicitacoes" element={<MyRequestsPage />} />
            <Route path="/baixar-app" element={<ApkAndMediaKitPage />} />
            <Route path="/suporte" element={<SupportAndReportsPage />} />
            <Route path="/termos" element={<TermsPage />} />
            <Route path="/privacidade" element={<PrivacyPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        ) : APP_VARIANT === 'profissional' ? (
          <Routes>
            <Route path="/" element={<Navigate to="/painel-profissional" replace />} />
            <Route path="/entrar" element={<AuthPage />} />
            <Route path="/minha-conta" element={<MyAccountPage />} />
            <Route path="/seja-profissional" element={<ProfessionalRegisterPage />} />
            <Route path="/painel-profissional" element={<ProfessionalDashboardPage onShareProf={handleShareProf} />} />
            <Route path="/painel-profissional/editar" element={<ProfessionalEditPage />} />
            <Route path="/minhas-solicitacoes" element={<MyRequestsPage />} />
            <Route path="/suporte" element={<SupportAndReportsPage />} />
            <Route path="/termos" element={<TermsPage />} />
            <Route path="/privacidade" element={<PrivacyPage />} />
            <Route path="*" element={<Navigate to="/painel-profissional" replace />} />
          </Routes>
        ) : (
          <Routes>
            <Route path="/" element={<Navigate to="/admin" replace />} />
            <Route path="/entrar" element={<AuthPage />} />
            <Route path="/minha-conta" element={<MyAccountPage />} />
            <Route path="/admin" element={<AdminDashboardPage />} />
            <Route path="/admin/profissionais" element={<AdminProfessionalsPage />} />
            <Route path="/admin/solicitacoes" element={<AdminRequestsPage />} />
            <Route path="/admin/categorias-cidades" element={<AdminCategoriesCitiesPage />} />
            <Route path="/admin/relatorios" element={<AdminReportsPage />} />
            <Route path="/suporte" element={<SupportAndReportsPage />} />
            <Route path="/termos" element={<TermsPage />} />
            <Route path="/privacidade" element={<PrivacyPage />} />
            <Route path="*" element={<Navigate to="/admin" replace />} />
          </Routes>
        )}
      </main>

      {APP_VARIANT === 'cliente' && (
        <Footer onOpenPWA={() => setPwaModalOpen(true)} onOpenShareQR={() => setShareModal({ open: true })} />
      )}

      {/* Global Interactive Modals */}
      <QuoteRequestModal
        professional={quoteProf}
        onClose={() => setQuoteProf(null)}
      />

      <ShareQRModal
        isOpen={shareModal.open}
        title={shareModal.title}
        subtitle={shareModal.subtitle}
        url={shareModal.url}
        onClose={() => setShareModal({ open: false })}
      />

      <PWAInstallModal
        isOpen={pwaModalOpen}
        onClose={() => setPwaModalOpen(false)}
      />

      <ReportModal
        target={reportTarget}
        onClose={() => setReportTarget(null)}
      />
    </div>
  );
};

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <AppShell />
      </AppProvider>
    </BrowserRouter>
  );
}
