export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export type UserRole = 'client' | 'professional' | 'admin';

export interface UserProfile {
  uid: string;
  displayName: string;
  role: UserRole;
  cityId: string;
  neighborhood?: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserPrivate {
  uid: string;
  email: string;
  phone?: string;
  lgpdConsent: boolean;
  deletionRequested?: boolean;
  createdAt: string;
  updatedAt: string;
}

export type ProfessionalStatus =
  | 'pending'
  | 'approved'
  | 'rejected'
  | 'correction_needed'
  | 'suspended';

export type AttendanceType = 'domiciliar' | 'remoto' | 'estabelecimento';

export interface ProfessionalProfile {
  id: string;
  userId: string;
  name: string;
  commercialName?: string;
  slug: string;
  cityId: string;
  cityName: string;
  neighborhoods: string[];
  categoryIds: string[];
  categoryNames: string[];
  servicesOffered: string[];
  description: string;
  photoUrl?: string;
  portfolioUrls?: string[];
  workingHours: string;
  attendanceTypes: AttendanceType[];
  startingPrice?: number;
  whatsappPhone: string;
  publicContactConsent: boolean;
  status: ProfessionalStatus;
  verificationNote?: string;
  documentVerified?: boolean;
  isAvailable: boolean;
  isDemo: boolean;
  featuredPlan: 'free' | 'destaque';
  ratingAvg: number;
  ratingCount: number;
  completedJobsCount: number;
  viewsCount: number;
  whatsappClicksCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface City {
  id: string;
  name: string;
  state: string;
  country: string;
  slug: string;
  isActive: boolean;
  neighborhoods: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  description: string;
  isActive: boolean;
  order: number;
  searchCount: number;
  createdAt: string;
  updatedAt: string;
}

export type ServiceRequestStatus =
  | 'nova'
  | 'em_contato'
  | 'orcamento_enviado'
  | 'aceita'
  | 'em_andamento'
  | 'concluida'
  | 'cancelada';

export interface ServiceRequest {
  id: string;
  clientId: string;
  clientName: string;
  clientPhone: string;
  professionalId: string;
  professionalUserId: string;
  professionalName: string;
  categoryId?: string;
  serviceTitle: string;
  description: string;
  cityId: string;
  cityName: string;
  neighborhood: string;
  preferredDate?: string;
  photoUrls?: string[];
  status: ServiceRequestStatus;
  whatsappClicked: boolean;
  clientConfirmedCompletion: boolean;
  professionalConfirmedCompletion: boolean;
  reviewed: boolean;
  consentShared: boolean;
  lastUpdatedBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Review {
  id: string;
  requestId: string;
  clientId: string;
  clientName: string;
  professionalId: string;
  professionalUserId: string;
  rating: number;
  comment: string;
  status: 'pending' | 'published' | 'hidden' | 'flagged';
  createdAt: string;
  updatedAt: string;
}

export interface Report {
  id: string;
  reporterId: string;
  reporterName?: string;
  reporterContact?: string;
  targetType: 'professional' | 'review' | 'lgpd_deletion' | 'category_suggestion' | 'support';
  targetId: string;
  reason: string;
  details: string;
  status: 'open' | 'reviewed' | 'resolved' | 'dismissed';
  createdAt: string;
  updatedAt: string;
}

export interface PlatformSettings {
  id: string;
  heroTitle: string;
  heroSubtitle: string;
  bannerTitle: string;
  bannerSubtitle: string;
  bannerActive: boolean;
  termsContent: string;
  privacyContent: string;
  monetizationEnabled: boolean;
  highlightPlanPrice: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  adminUid: string;
  adminEmail: string;
  action: string;
  targetType: string;
  targetId: string;
  details: string;
  createdAt: string;
}

export interface AdminUser {
  uid: string;
  email: string;
  role: 'super_admin' | 'moderator';
  createdAt: string;
}

export interface SearchFilters {
  cityId: string;
  neighborhood?: string;
  categoryId?: string;
  query?: string;
  onlyAvailable?: boolean;
  maxPrice?: number;
  minRating?: number;
  includeDemo?: boolean;
}

export interface PlatformMetrics {
  totalProfessionals: number;
  approvedProfessionals: number;
  pendingProfessionals: number;
  requestsCreated: number;
  whatsappClicks: number;
  quotesSent: number;
  hiresConfirmed: number;
  completedConfirmed: number;
}
