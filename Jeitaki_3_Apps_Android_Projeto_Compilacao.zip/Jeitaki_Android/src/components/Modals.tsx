import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import {
  AlertTriangle,
  Check,
  Copy,
  Download,
  ExternalLink,
  MessageCircle,
  QrCode,
  Share2,
  Smartphone,
  Upload,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { OFFICIAL_BRAND_LOGO } from './CategoryIcon';
import { ProfessionalProfile, ServiceRequest } from '../types/jeitaki';
import {
  buildWhatsAppQuoteUrl,
  isValidBrazilianPhone,
} from '../utils/jeitakiLogic';

// 1. Quote Request Modal (Solicitar Orçamento)
export const QuoteRequestModal: React.FC<{
  professional: ProfessionalProfile | null;
  onClose: () => void;
}> = ({ professional, onClose }) => {
  const {
    currentUser,
    userProfile,
    userPrivate,
    selectedCity,
    createServiceRequest,
    markWhatsAppClicked,
    compressImageFile,
  } = useApp();

  const [serviceTitle, setServiceTitle] = useState(
    professional?.servicesOffered[0] || ''
  );
  const [description, setDescription] = useState('');
  const [neighborhood, setNeighborhood] = useState(
    userProfile?.neighborhood ||
      professional?.neighborhoods[0] ||
      selectedCity.neighborhoods[0] ||
      'Centro'
  );
  const [preferredDate, setPreferredDate] = useState('');
  const [clientName, setClientName] = useState(
    userProfile?.displayName || currentUser?.displayName || ''
  );
  const [clientPhone, setClientPhone] = useState(userPrivate?.phone || '');
  const [photoUrls, setPhotoUrls] = useState<string[]>([]);
  const [consentShared, setConsentShared] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [createdRequest, setCreatedRequest] = useState<ServiceRequest | null>(
    null
  );
  const [copiedMsg, setCopiedMsg] = useState(false);

  useEffect(() => {
    if (professional) {
      setServiceTitle(professional.servicesOffered[0] || '');
      setNeighborhood(
        userProfile?.neighborhood ||
          professional.neighborhoods[0] ||
          selectedCity.neighborhoods[0] ||
          'Centro'
      );
      setClientName(userProfile?.displayName || currentUser?.displayName || '');
      setClientPhone(userPrivate?.phone || '');
      setDescription('');
      setPreferredDate('');
      setPhotoUrls([]);
      setConsentShared(true);
      setError(null);
      setCreatedRequest(null);
      setCopiedMsg(false);
    }
  }, [professional, userProfile, userPrivate, currentUser, selectedCity]);

  if (!professional) return null;

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || !files.length) return;
    if (photoUrls.length >= 3) {
      setError('Você pode anexar no máximo 3 fotos por solicitação.');
      return;
    }
    setError(null);
    try {
      const compressed = await compressImageFile(files[0]);
      setPhotoUrls((prev) => [...prev, compressed].slice(0, 3));
    } catch (err: unknown) {
      setError(
        err instanceof Error ? err.message : 'Erro ao anexar foto.'
      );
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (serviceTitle.trim().length < 2) {
      setError('Informe qual serviço você deseja solicitar.');
      return;
    }
    if (description.trim().length < 5) {
      setError('Descreva brevemente o que precisa ser resolvido.');
      return;
    }
    if (!neighborhood.trim()) {
      setError('Selecione o seu bairro.');
      return;
    }
    if (clientName.trim().length < 2) {
      setError('Informe seu nome para identificação.');
      return;
    }
    if (!isValidBrazilianPhone(clientPhone)) {
      setError('Informe um telefone/WhatsApp válido com DDD (ex: 94 99123-4567).');
      return;
    }
    if (!consentShared) {
      setError(
        'É necessário concordar com o compartilhamento dos dados da solicitação com o profissional.'
      );
      return;
    }

    setSubmitting(true);
    try {
      const req = await createServiceRequest({
        professional,
        serviceTitle,
        description,
        neighborhood,
        preferredDate,
        clientName,
        clientPhone,
        photoUrls,
        consentShared,
      });
      setCreatedRequest(req);
    } catch (err: unknown) {
      setError(
        err instanceof Error
          ? err.message
          : 'Não foi possível registrar a solicitação. Tente novamente.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const whatsappData = buildWhatsAppQuoteUrl({
    phone: professional.whatsappPhone,
    serviceTitle: createdRequest?.serviceTitle || serviceTitle,
    neighborhood: createdRequest?.neighborhood || neighborhood,
    cityName: professional.cityName || 'Breu Branco',
    description: createdRequest?.description || description,
  });

  const handleCopyMessage = async () => {
    try {
      await navigator.clipboard.writeText(whatsappData.message);
      setCopiedMsg(true);
      setTimeout(() => setCopiedMsg(false), 3000);
    } catch {
      // Fallback
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-quote-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/60 backdrop-blur-sm p-0 sm:p-4"
    >
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-2xl shadow-xl border border-slate-200 max-h-[92vh] overflow-y-auto">
        <div className="sticky top-0 bg-white px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2
              id="modal-quote-title"
              className="font-display text-lg font-bold text-[#0B4F24]"
            >
              {createdRequest
                ? 'Solicitação Registrada!'
                : 'Solicitar Orçamento'}
            </h2>
            <p className="text-xs text-slate-500">
              Profissional:{' '}
              <span className="font-semibold text-[#0B4F24]">
                {professional.commercialName || professional.name}
              </span>
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar janela de orçamento"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {createdRequest ? (
            <div className="space-y-5">
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-start gap-3">
                <Check className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div className="text-xs text-emerald-950 space-y-1">
                  <p className="font-semibold text-sm">
                    Pedido #{createdRequest.id.slice(-6)} salvo no JEITAKI!
                  </p>
                  <p>
                    Agora você pode abrir a conversa no WhatsApp do profissional
                    com a mensagem já preenchida para combinar os detalhes.
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700">
                  Mensagem preparada para o WhatsApp:
                </label>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 leading-relaxed">
                  {whatsappData.message}
                </div>
              </div>

              <div className="space-y-3">
                <a
                  href={whatsappData.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() =>
                    markWhatsAppClicked(createdRequest.id, professional.id)
                  }
                  className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#16A34A] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-sm hover:bg-[#15803d] transition-colors"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Abrir Conversa no WhatsApp</span>
                  <ExternalLink className="w-4 h-4" />
                </a>

                <button
                  type="button"
                  onClick={handleCopyMessage}
                  className="w-full min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-semibold text-xs flex items-center justify-center gap-2 hover:bg-slate-50 transition-colors"
                >
                  <Copy className="w-4 h-4" />
                  <span>
                    {copiedMsg
                      ? 'Mensagem copiada com sucesso!'
                      : 'Copiar mensagem (caso o navegador bloqueie a abertura)'}
                  </span>
                </button>
              </div>

              <p className="text-[11px] text-slate-500 text-center leading-normal">
                Nota: O JEITAKI apenas abre a conversa no seu aplicativo WhatsApp
                para você confirmar o envio da mensagem diretamente ao
                profissional.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div
                  role="alert"
                  className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800 flex items-start gap-2"
                >
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label
                  htmlFor="quote-service"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Serviço desejado *
                </label>
                {professional.servicesOffered.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {professional.servicesOffered.map((srv) => (
                      <button
                        key={srv}
                        type="button"
                        onClick={() => setServiceTitle(srv)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                          serviceTitle === srv
                            ? 'bg-[#0B4F24] text-white'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {srv}
                      </button>
                    ))}
                  </div>
                )}
                <input
                  id="quote-service"
                  type="text"
                  required
                  value={serviceTitle}
                  onChange={(e) => setServiceTitle(e.target.value)}
                  placeholder="Ex: Instalação de tomada, limpeza residencial..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-[#0B4F24]"
                />
              </div>

              <div>
                <label
                  htmlFor="quote-desc"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Breve descrição da necessidade *
                </label>
                <textarea
                  id="quote-desc"
                  required
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Explique o que aconteceu ou o que você precisa fazer..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-[#0B4F24]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="quote-hood"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Bairro em {professional.cityName} *
                  </label>
                  <select
                    id="quote-hood"
                    value={neighborhood}
                    onChange={(e) => setNeighborhood(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm bg-white focus:outline-none focus:border-[#0B4F24]"
                  >
                    {selectedCity.neighborhoods.map((h) => (
                      <option key={h} value={h}>
                        {h}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="quote-date"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Data ou período desejado (opcional)
                  </label>
                  <input
                    id="quote-date"
                    type="text"
                    value={preferredDate}
                    onChange={(e) => setPreferredDate(e.target.value)}
                    placeholder="Ex: Amanhã à tarde, Urgente..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-[#0B4F24]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="quote-name"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Seu nome *
                  </label>
                  <input
                    id="quote-name"
                    type="text"
                    required
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    placeholder="Como prefere ser chamado"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-[#0B4F24]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="quote-phone"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Seu WhatsApp com DDD *
                  </label>
                  <input
                    id="quote-phone"
                    type="tel"
                    required
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    placeholder="(94) 99123-4567"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-[#0B4F24]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Fotos opcionais do local/problema (máx. 3 imagens JPG/PNG até 5MB)
                </label>
                <div className="flex items-center gap-3 flex-wrap">
                  {photoUrls.map((url, idx) => (
                    <div
                      key={idx}
                      className="relative w-16 h-16 rounded-xl overflow-hidden border border-slate-200"
                    >
                      <img
                        src={url}
                        alt={`Anexo ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setPhotoUrls((prev) =>
                            prev.filter((_, i) => i !== idx)
                          )
                        }
                        aria-label="Remover foto anexada"
                        className="absolute top-0.5 right-0.5 bg-slate-900/80 text-white rounded-full p-0.5"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                  {photoUrls.length < 3 && (
                    <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-dashed border-slate-300 text-xs font-medium text-slate-600 hover:border-[#0B4F24]">
                      <Upload className="w-4 h-4" />
                      <span>Adicionar foto</span>
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        onChange={handlePhotoUpload}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
              </div>

              <label className="flex items-start gap-2.5 pt-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={consentShared}
                  onChange={(e) => setConsentShared(e.target.checked)}
                  className="mt-0.5 rounded border-slate-300 text-[#0B4F24] focus:ring-[#16A34A]"
                />
                <span className="text-xs text-slate-600 leading-relaxed">
                  Concordo em registrar esta solicitação no JEITAKI e
                  compartilhar as informações acima com o profissional para
                  atendimento conforme a Política de Privacidade (LGPD).
                </span>
              </label>

              <button
                type="submit"
                disabled={submitting}
                className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#16A34A] text-white font-bold text-sm hover:bg-[#15803d] transition-colors disabled:opacity-50"
              >
                {submitting
                  ? 'Registrando solicitação...'
                  : 'Confirmar e Gerar Contato WhatsApp'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

// 2. Share & QR Code Modal
export const ShareQRModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  url?: string;
}> = ({
  isOpen,
  onClose,
  title = 'Divulgar JEITAKI em Breu Branco',
  subtitle = 'Aponte a câmera do celular para o QR Code ou compartilhe o link direto no WhatsApp.',
  url,
}) => {
  const [copied, setCopied] = useState(false);
  if (!isOpen) return null;

  const targetUrl =
    url || (typeof window !== 'undefined' ? window.location.origin : '');
  const whatsappShareUrl = `https://wa.me/?text=${encodeURIComponent(
    `${title} — Precisou? Tem quem resolva! Acesse: ${targetUrl}`
  )}`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(targetUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // ignore
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="share-qr-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4"
    >
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-slate-200 p-6 space-y-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#0B4F24] text-[#F59E0B] flex items-center justify-center shrink-0">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h2
                id="share-qr-title"
                className="font-display text-base font-bold text-[#0B4F24]"
              >
                {title}
              </h2>
              <p className="text-xs text-slate-500">{subtitle}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar janela de QR Code"
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex flex-col items-center justify-center p-6 rounded-2xl bg-[#F6FAF7] border border-slate-200">
          <img
            src={OFFICIAL_BRAND_LOGO}
            alt="Logo Jeita Aqui Breu Branco"
            referrerPolicy="no-referrer"
            className="w-24 h-24 object-contain mb-3"
          />
          <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs">
            <QRCodeSVG
              value={targetUrl}
              size={180}
              bgColor="#FFFFFF"
              fgColor="#0B4F24"
              level="M"
            />
          </div>
          <p className="mt-3 text-xs font-medium text-slate-600 break-all text-center">
            {targetUrl}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            type="button"
            onClick={handleCopy}
            className="min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-[#0B4F24] hover:bg-slate-50 flex items-center justify-center gap-2"
          >
            <Copy className="w-4 h-4" />
            <span>{copied ? 'Link Copiado!' : 'Copiar Link'}</span>
          </button>
          <a
            href={whatsappShareUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-[#16A34A] text-white text-xs font-bold hover:bg-[#15803d] flex items-center justify-center gap-2"
          >
            <Share2 className="w-4 h-4" />
            <span>Enviar no WhatsApp</span>
          </a>
        </div>

        <div className="pt-2 border-t border-slate-100 text-center">
          <Link
            to="/baixar-app"
            onClick={onClose}
            className="text-xs font-bold text-[#0B4F24] hover:text-[#16A34A] underline underline-offset-4"
          >
            Baixar Cartaz Oficial PNG + Gerador de .APK &rarr;
          </Link>
        </div>
      </div>
    </div>
  );
};

// 3. PWA Installation Instructions Modal
export const PWAInstallModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
}> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="pwa-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4"
    >
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-xl border border-slate-200 p-6 space-y-5 max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <img
              src={OFFICIAL_BRAND_LOGO}
              alt="Logo Jeita Aqui Breu Branco"
              referrerPolicy="no-referrer"
              className="w-11 h-11 rounded-xl border border-slate-200 p-0.5 object-contain shrink-0"
            />
            <div>
              <h2
                id="pwa-modal-title"
                className="font-display text-base font-bold text-[#0B4F24]"
              >
                Instalar Jeita Aqui no Celular ou Baixar .APK
              </h2>
              <p className="text-xs text-slate-500">
                Instale direto na tela inicial ou baixe o pacote Android (.apk).
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar instruções de instalação"
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isInstalled ? (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 font-medium">
            O Jeita Aqui já está instalado no seu dispositivo!
          </div>
        ) : (
          isInstallable && (
            <button
              type="button"
              onClick={install}
              className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#16A34A] text-white font-bold text-sm flex items-center justify-center gap-2 hover:bg-[#15803d]"
            >
              <Download className="w-5 h-5" />
              <span>Instalar Agora Automaticamente</span>
            </button>
          )
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-[#F6FAF7] border border-slate-200 space-y-2">
            <h3 className="text-xs font-bold text-[#0B4F24]">
              No Android (Chrome / Edge)
            </h3>
            <ol className="text-xs text-slate-600 space-y-1.5 list-decimal list-inside">
              <li>
                Toque nos <strong>três pontinhos (⋮)</strong> no canto superior
                do navegador.
              </li>
              <li>
                Selecione <strong>&ldquo;Instalar aplicativo&rdquo;</strong> ou{' '}
                <strong>&ldquo;Adicionar à tela inicial&rdquo;</strong>.
              </li>
              <li>Confirme para criar o ícone do Jeita Aqui no seu celular.</li>
            </ol>
          </div>

          <div className="p-4 rounded-xl bg-[#F6FAF7] border border-slate-200 space-y-2">
            <h3 className="text-xs font-bold text-[#0B4F24]">
              No iPhone / iPad (Safari)
            </h3>
            <ol className="text-xs text-slate-600 space-y-1.5 list-decimal list-inside">
              <li>
                Abra o Jeita Aqui pelo navegador <strong>Safari</strong>.
              </li>
              <li>
                Toque no botão <strong>Compartilhar</strong> (ícone de quadrado
                com seta para cima na barra inferior).
              </li>
              <li>
                Role para baixo e toque em{' '}
                <strong>&ldquo;Adicionar à Tela de Início&rdquo;</strong>.
              </li>
            </ol>
          </div>
        </div>

        <Link
          to="/baixar-app"
          onClick={onClose}
          className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-[#0B4F24] text-white text-xs font-bold hover:bg-[#0E662F] flex items-center justify-center gap-2"
        >
          <Download className="w-4 h-4 text-[#F59E0B]" />
          <span>Ir para Central de Download .APK e Kit de Divulgação</span>
        </Link>
      </div>
    </div>
  );
};

// 4. Report Modal (Denunciar Perfil ou Avaliação)
export const ReportModal: React.FC<{
  target: {
    type: 'professional' | 'review';
    id: string;
    name: string;
  } | null;
  onClose: () => void;
}> = ({ target, onClose }) => {
  const { createReport, userProfile, userPrivate } = useApp();
  const [reason, setReason] = useState('Informações falsas ou enganosas');
  const [details, setDetails] = useState('');
  const [reporterName, setReporterName] = useState(
    userProfile?.displayName || ''
  );
  const [reporterContact, setReporterContact] = useState(
    userPrivate?.email || userPrivate?.phone || ''
  );
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (target) {
      setReason('Informações falsas ou enganosas');
      setDetails('');
      setReporterName(userProfile?.displayName || '');
      setReporterContact(userPrivate?.email || userPrivate?.phone || '');
      setDone(false);
      setError(null);
    }
  }, [target, userProfile, userPrivate]);

  if (!target) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (details.trim().length < 5) {
      setError('Descreva o motivo da denúncia com pelo menos 5 caracteres.');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      await createReport({
        targetType: target.type,
        targetId: target.id,
        reason,
        details,
        reporterName,
        reporterContact,
      });
      setDone(true);
    } catch (err: unknown) {
      setError(
        err instanceof Error ? err.message : 'Erro ao enviar denúncia.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="report-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4"
    >
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-slate-200 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2
            id="report-modal-title"
            className="font-display text-base font-bold text-[#0B4F24]"
          >
            Denunciar {target.type === 'professional' ? 'Perfil' : 'Avaliação'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar janela de denúncia"
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {done ? (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
              Sua denúncia sobre <strong>{target.name}</strong> foi registrada e
              enviada para análise da moderação do JEITAKI.
            </div>
            <button
              type="button"
              onClick={onClose}
              className="w-full min-h-[44px] rounded-xl bg-[#0B4F24] text-white text-xs font-semibold"
            >
              Fechar
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5">
            {error && (
              <div className="p-3 rounded-xl bg-red-50 text-xs text-red-700 border border-red-200">
                {error}
              </div>
            )}
            <p className="text-xs text-slate-600">
              Item reportado: <strong className="text-[#0B4F24]">{target.name}</strong>
            </p>
            <div>
              <label
                htmlFor="report-reason"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Motivo principal
              </label>
              <select
                id="report-reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs bg-white"
              >
                <option value="Informações falsas ou enganosas">
                  Informações falsas ou enganosas
                </option>
                <option value="Conduta inadequada ou desrespeitosa">
                  Conduta inadequada ou desrespeitosa
                </option>
                <option value="Suspeita de fraude ou cobrança indevida">
                  Suspeita de fraude ou cobrança indevida
                </option>
                <option value="Telefone inexistente ou de outra pessoa">
                  Telefone inexistente ou de outra pessoa
                </option>
                <option value="Outro motivo">Outro motivo</option>
              </select>
            </div>
            <div>
              <label
                htmlFor="report-details"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Detalhes do ocorrido *
              </label>
              <textarea
                id="report-details"
                required
                rows={3}
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Descreva com clareza para ajudar nossa equipe de moderação..."
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <input
                type="text"
                value={reporterName}
                onChange={(e) => setReporterName(e.target.value)}
                placeholder="Seu nome (opcional)"
                className="px-3 py-2 rounded-xl border border-slate-300 text-xs"
              />
              <input
                type="text"
                value={reporterContact}
                onChange={(e) => setReporterContact(e.target.value)}
                placeholder="Seu contato (opcional)"
                className="px-3 py-2 rounded-xl border border-slate-300 text-xs"
              />
            </div>
            <button
              type="submit"
              disabled={submitting}
              className="w-full min-h-[44px] rounded-xl bg-[#0B4F24] text-white text-xs font-bold hover:bg-[#0E662F]"
            >
              {submitting ? 'Enviando...' : 'Enviar Denúncia para Moderação'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
