import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Briefcase,
  ClipboardList,
  Home,
  Search,
  Shield,
  User,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useOnlineStatus } from '../hooks/usePWAInstall';
import { JeitakiLogo } from './CategoryIcon';

export const Navbar: React.FC = () => {
  const { currentUser, userProfile, isAdmin, myProfessionalProfile } = useApp();
  const location = useLocation();
  const isOnline = useOnlineStatus();

  const isActive = (path: string) =>
    path === '/'
      ? location.pathname === '/'
      : location.pathname.startsWith(path);

  return (
    <>
      {!isOnline && (
        <div
          role="status"
          className="bg-[#F59E0B] text-[#0B4F24] px-4 py-1.5 text-xs font-semibold text-center"
        >
          Modo offline ativo — exibindo páginas e categorias em cache local.
        </div>
      )}

      {/* Top Navigation Bar — 3-Zone Contract */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-8">
          {/* Zone 1: Single Brand Wordmark */}
          <Link
            to="/"
            aria-label="Jeita Aqui Breu Branco Página Inicial"
            className="focus-visible:outline-2 focus-visible:outline-[#16A34A] rounded-lg whitespace-nowrap shrink-0"
          >
            <JeitakiLogo darkText={true} />
          </Link>

          {/* Zone 2: 4-5 Concise Single-Line Navigation Links */}
          <nav
            aria-label="Navegação Principal"
            className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600"
          >
            <Link
              to="/busca"
              className={`hover:text-[#0B4F24] transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                isActive('/busca')
                  ? 'border-[#16A34A] text-[#0B4F24] font-semibold'
                  : 'border-transparent'
              }`}
            >
              Profissionais
            </Link>
            <Link
              to="/seja-profissional"
              className={`hover:text-[#0B4F24] transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                isActive('/seja-profissional') || isActive('/painel-profissional')
                  ? 'border-[#16A34A] text-[#0B4F24] font-semibold'
                  : 'border-transparent'
              }`}
            >
              Área do Profissional
            </Link>
            <Link
              to="/minhas-solicitacoes"
              className={`hover:text-[#0B4F24] transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                isActive('/minhas-solicitacoes')
                  ? 'border-[#16A34A] text-[#0B4F24] font-semibold'
                  : 'border-transparent'
              }`}
            >
              Solicitações
            </Link>
            <Link
              to="/baixar-app"
              className={`hover:text-[#0B4F24] transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                isActive('/baixar-app')
                  ? 'border-[#F59E0B] text-[#0B4F24] font-semibold'
                  : 'border-transparent'
              }`}
            >
              Baixar App / APK
            </Link>
            {isAdmin ? (
              <Link
                to="/admin"
                className={`hover:text-[#0B4F24] transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 flex items-center gap-1 ${
                  isActive('/admin')
                    ? 'border-[#16A34A] text-[#0B4F24] font-semibold'
                    : 'border-transparent text-[#0B4F24]'
                }`}
              >
                <Shield className="w-4 h-4 text-[#16A34A]" />
                Admin
              </Link>
            ) : (
              <Link
                to="/suporte"
                className={`hover:text-[#0B4F24] transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                  isActive('/suporte')
                    ? 'border-[#16A34A] text-[#0B4F24] font-semibold'
                    : 'border-transparent'
                }`}
              >
                Suporte
              </Link>
            )}
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            {currentUser ? (
              <Link
                to="/minha-conta"
                className="min-h-[40px] px-4 py-2 rounded-xl bg-[#0B4F24] text-white text-xs sm:text-sm font-semibold hover:bg-[#0E662F] transition-colors flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                <User className="w-4 h-4 text-[#F59E0B]" />
                <span className="truncate max-w-[130px]">
                  {userProfile?.displayName ||
                    currentUser.displayName ||
                    'Minha Conta'}
                </span>
              </Link>
            ) : (
              <Link
                to="/entrar"
                className="min-h-[40px] px-4 py-2 rounded-xl bg-[#0B4F24] text-white text-xs sm:text-sm font-semibold hover:bg-[#0E662F] transition-colors flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                <User className="w-4 h-4 text-[#F59E0B]" />
                <span>Entrar</span>
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* Mobile Fixed Bottom Navigation Bar */}
      <nav
        aria-label="Menu Inferior Mobile"
        className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 h-14 px-2 grid grid-cols-5 items-center"
      >
        <Link
          to="/"
          className={`min-h-[44px] flex flex-col items-center justify-center rounded-lg transition-colors ${
            isActive('/')
              ? 'text-[#0B4F24] font-semibold'
              : 'text-slate-500 hover:text-[#0B4F24]'
          }`}
        >
          <Home
            className={`w-5 h-5 ${
              isActive('/') ? 'text-[#16A34A]' : 'text-slate-500'
            }`}
          />
          <span className="text-[10px] mt-0.5 whitespace-nowrap">Início</span>
        </Link>

        <Link
          to="/busca"
          className={`min-h-[44px] flex flex-col items-center justify-center rounded-lg transition-colors ${
            isActive('/busca') || isActive('/categoria')
              ? 'text-[#0B4F24] font-semibold'
              : 'text-slate-500 hover:text-[#0B4F24]'
          }`}
        >
          <Search
            className={`w-5 h-5 ${
              isActive('/busca') || isActive('/categoria')
                ? 'text-[#16A34A]'
                : 'text-slate-500'
            }`}
          />
          <span className="text-[10px] mt-0.5 whitespace-nowrap">Buscar</span>
        </Link>

        <Link
          to="/minhas-solicitacoes"
          className={`min-h-[44px] flex flex-col items-center justify-center rounded-lg transition-colors ${
            isActive('/minhas-solicitacoes')
              ? 'text-[#0B4F24] font-semibold'
              : 'text-slate-500 hover:text-[#0B4F24]'
          }`}
        >
          <ClipboardList
            className={`w-5 h-5 ${
              isActive('/minhas-solicitacoes')
                ? 'text-[#16A34A]'
                : 'text-slate-500'
            }`}
          />
          <span className="text-[10px] mt-0.5 whitespace-nowrap">Pedidos</span>
        </Link>

        <Link
          to={myProfessionalProfile ? '/painel-profissional' : '/seja-profissional'}
          className={`min-h-[44px] flex flex-col items-center justify-center rounded-lg transition-colors ${
            isActive('/painel-profissional') || isActive('/seja-profissional')
              ? 'text-[#0B4F24] font-semibold'
              : 'text-slate-500 hover:text-[#0B4F24]'
          }`}
        >
          <Briefcase
            className={`w-5 h-5 ${
              isActive('/painel-profissional') || isActive('/seja-profissional')
                ? 'text-[#16A34A]'
                : 'text-slate-500'
            }`}
          />
          <span className="text-[10px] mt-0.5 whitespace-nowrap">
            Profissional
          </span>
        </Link>

        <Link
          to={isAdmin ? '/admin' : currentUser ? '/minha-conta' : '/entrar'}
          className={`min-h-[44px] flex flex-col items-center justify-center rounded-lg transition-colors ${
            isActive('/minha-conta') || isActive('/entrar') || isActive('/admin')
              ? 'text-[#0B4F24] font-semibold'
              : 'text-slate-500 hover:text-[#0B4F24]'
          }`}
        >
          {isAdmin ? (
            <Shield
              className={`w-5 h-5 ${
                isActive('/admin') ? 'text-[#16A34A]' : 'text-slate-500'
              }`}
            />
          ) : (
            <User
              className={`w-5 h-5 ${
                isActive('/minha-conta') || isActive('/entrar')
                  ? 'text-[#16A34A]'
                  : 'text-slate-500'
              }`}
            />
          )}
          <span className="text-[10px] mt-0.5 whitespace-nowrap">
            {isAdmin ? 'Admin' : currentUser ? 'Conta' : 'Entrar'}
          </span>
        </Link>
      </nav>
    </>
  );
};
