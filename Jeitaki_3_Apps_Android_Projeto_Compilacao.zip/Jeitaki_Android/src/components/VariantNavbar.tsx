import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { BriefcaseBusiness, ClipboardList, Home, LogIn, Search, ShieldCheck, UserRound } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { APP_VARIANT, APP_LABELS } from '../appVariant';
import { JeitakiLogo } from './CategoryIcon';

export const VariantNavbar: React.FC = () => {
  const { currentUser, isAdmin } = useApp();
  const location = useLocation();
  const selected = (url: string) => location.pathname === url || location.pathname.startsWith(url + '/');
  const nav = APP_VARIANT === 'cliente' ? [
    { to:'/', label:'Início', icon:Home },
    { to:'/busca', label:'Buscar', icon:Search },
    { to:'/minhas-solicitacoes', label:'Pedidos', icon:ClipboardList },
    { to:'/minha-conta', label:'Minha conta', icon:UserRound },
  ] : APP_VARIANT === 'profissional' ? [
    { to:'/painel-profissional', label:'Painel', icon:BriefcaseBusiness },
    { to:'/seja-profissional', label:'Cadastro', icon:ClipboardList },
    { to:'/minha-conta', label:'Minha conta', icon:UserRound },
  ] : [
    { to:'/admin', label:'Painel', icon:ShieldCheck },
    { to:'/admin/profissionais', label:'Profissionais', icon:BriefcaseBusiness },
    { to:'/admin/solicitacoes', label:'Pedidos', icon:ClipboardList },
    { to:'/minha-conta', label:'Minha conta', icon:UserRound },
  ];
  return (
    <>
      <header className="bg-white/95 border-b border-emerald-100 sticky top-0 z-40 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 min-h-[72px] flex items-center justify-between gap-4">
          <Link to={APP_VARIANT==='cliente'?'/':APP_VARIANT==='profissional'?'/painel-profissional':'/admin'}
            className="flex items-center min-w-0 gap-3">
            <JeitakiLogo size="sm" />
            <span className="hidden sm:block text-xs font-bold px-2 py-1.5 rounded-lg bg-emerald-50 text-[#0B4F24]">{APP_LABELS[APP_VARIANT]}</span>
          </Link>
          <nav className="hidden md:flex items-center gap-2" aria-label="Navegação principal">
            {nav.map(({ to,label,icon:Icon }) => <Link key={to} to={to}
              className={`flex gap-2 items-center rounded-xl px-3 py-2 text-sm font-semibold ${selected(to)?'bg-[#0B4F24] text-white':'text-[#0B4F24] hover:bg-emerald-50'}`}><Icon size={17}/>{label}</Link>)}
          </nav>
          {!currentUser ? <Link className="bg-[#0B4F24] text-white rounded-xl px-4 py-2 font-bold text-sm flex items-center gap-2" to="/entrar"><LogIn size={18}/>Entrar</Link> :
            <span className="text-[11px] text-emerald-900 truncate max-w-28 sm:max-w-44">{isAdmin&&APP_VARIANT==='admin'?'Administrador':currentUser.email}</span>}
        </div>
      </header>
      <nav className={`md:hidden fixed bottom-0 left-0 right-0 border-t z-50 bg-white/95 backdrop-blur-md flex justify-around items-center min-h-16 px-1 pb-safe shadow-lg`} aria-label="Menu inferior">
        {nav.map(({to,label,icon:Icon})=><Link key={to} to={to} className={`flex flex-col gap-0.5 text-[10px] font-semibold px-2 py-2 rounded-xl items-center ${selected(to)?'text-[#0B4F24] bg-emerald-50':'text-gray-600'}`}><Icon size={21}/>{label}</Link>)}
      </nav>
    </>
  );
};
