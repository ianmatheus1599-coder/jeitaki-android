import React from 'react';
import { Link } from 'react-router-dom';
import { Download, MapPin, QrCode, ShieldAlert } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { JeitakiLogo } from './CategoryIcon';

export const Footer: React.FC<{
  onOpenPWA: () => void;
  onOpenShareQR: () => void;
}> = ({ onOpenPWA, onOpenShareQR }) => {
  const { cities, selectedCityId, setSelectedCityId, selectedCity } = useApp();
  const activeCities = cities.filter((c) => c.isActive);

  return (
    <footer className="bg-[#0B4F24] text-emerald-100 border-t border-emerald-900 pb-20 md:pb-10 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-emerald-800/70">
          {/* Column 1: Brand & Mission */}
          <div className="space-y-3">
            <JeitakiLogo darkText={false} />
            <p className="text-sm text-[#F59E0B] font-semibold">
              &ldquo;Precisou? Tem quem resolva!&rdquo;
            </p>
            <p className="text-xs text-emerald-100/90 leading-relaxed">
              Marketplace local criado para conectar moradores a profissionais
              autônomos e pequenos negócios em {selectedCity.name} -{' '}
              {selectedCity.state} e região.
            </p>
            <div className="pt-2 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#F59E0B] shrink-0" />
              <label htmlFor="footer-city-select" className="sr-only">
                Selecionar cidade
              </label>
              <select
                id="footer-city-select"
                value={selectedCityId}
                onChange={(e) => setSelectedCityId(e.target.value)}
                className="bg-emerald-950/80 text-white text-xs rounded-lg px-3 py-2 border border-emerald-700 focus:outline-none focus:border-[#F59E0B]"
              >
                {activeCities.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} - {c.state}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Column 2: Para Moradores */}
          <div className="space-y-2.5">
            <h3 className="text-sm font-semibold text-white">Para Moradores</h3>
            <ul className="space-y-2 text-xs text-emerald-100/90">
              <li>
                <Link to="/busca" className="hover:text-white transition-colors">
                  Buscar Profissionais
                </Link>
              </li>
              <li>
                <Link
                  to="/minhas-solicitacoes"
                  className="hover:text-white transition-colors"
                >
                  Acompanhar Solicitações
                </Link>
              </li>
              <li>
                <Link
                  to="/baixar-app"
                  className="hover:text-[#F59E0B] transition-colors inline-flex items-center gap-1.5 text-left font-semibold text-white"
                >
                  <Download className="w-3.5 h-3.5 text-[#F59E0B]" />
                  Baixar Aplicativo (.APK / Celular)
                </Link>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenPWA}
                  className="hover:text-[#F59E0B] transition-colors inline-flex items-center gap-1.5 text-left"
                >
                  <Download className="w-3.5 h-3.5 text-[#F59E0B]" />
                  Instruções de Instalação (Android e iPhone)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenShareQR}
                  className="hover:text-[#F59E0B] transition-colors inline-flex items-center gap-1.5 text-left"
                >
                  <QrCode className="w-3.5 h-3.5 text-[#F59E0B]" />
                  Gerar QR Code de Divulgação
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Para Profissionais */}
          <div className="space-y-2.5">
            <h3 className="text-sm font-semibold text-white">
              Para Profissionais
            </h3>
            <ul className="space-y-2 text-xs text-emerald-100/90">
              <li>
                <Link
                  to="/seja-profissional"
                  className="hover:text-white transition-colors"
                >
                  Cadastrar Perfil Gratuitamente
                </Link>
              </li>
              <li>
                <Link
                  to="/painel-profissional"
                  className="hover:text-white transition-colors"
                >
                  Painel do Profissional
                </Link>
              </li>
              <li>
                <Link
                  to="/painel-profissional/editar"
                  className="hover:text-white transition-colors"
                >
                  Editar Meu Perfil e Horários
                </Link>
              </li>
              <li>
                <Link
                  to="/admin"
                  className="hover:text-white transition-colors"
                >
                  Painel Administrativo
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 4: Legal, Segurança e Suporte */}
          <div className="space-y-2.5">
            <h3 className="text-sm font-semibold text-white">
              Transparência e LGPD
            </h3>
            <ul className="space-y-2 text-xs text-emerald-100/90">
              <li>
                <Link to="/termos" className="hover:text-white transition-colors">
                  Termos de Uso
                </Link>
              </li>
              <li>
                <Link
                  to="/privacidade"
                  className="hover:text-white transition-colors"
                >
                  Política de Privacidade e LGPD
                </Link>
              </li>
              <li>
                <Link
                  to="/suporte"
                  className="hover:text-white transition-colors inline-flex items-center gap-1.5"
                >
                  <ShieldAlert className="w-3.5 h-3.5 text-[#F59E0B]" />
                  Suporte, Denúncias e Exclusão de Dados
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-emerald-200/80">
          <p>
            © {new Date().getFullYear()} Jeita Aqui (JEITAKI) —{' '}
            {selectedCity.name}, {selectedCity.state}, Brasil. Todos os direitos
            reservados.
          </p>
          <p className="max-w-xl text-[11px] text-emerald-200/80">
            Aviso importante: O Jeita Aqui conecta moradores a prestadores de
            serviços independentes. A negociação e a execução do serviço são
            combinadas diretamente entre as partes.
          </p>
        </div>
      </div>
    </footer>
  );
};
