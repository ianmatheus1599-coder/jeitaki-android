import React from 'react';
import {
  Briefcase,
  CheckCircle2,
  Droplets,
  Hammer,
  Laptop,
  Package,
  Paintbrush,
  ShieldCheck,
  Snowflake,
  Sparkles,
  Trees,
  Wrench,
  Zap,
} from 'lucide-react';

export const CategoryIcon: React.FC<{
  name: string;
  className?: string;
}> = ({ name, className = 'w-6 h-6' }) => {
  switch (name) {
    case 'Zap':
      return <Zap className={className} />;
    case 'Hammer':
      return <Hammer className={className} />;
    case 'Droplets':
      return <Droplets className={className} />;
    case 'Sparkles':
      return <Sparkles className={className} />;
    case 'Snowflake':
      return <Snowflake className={className} />;
    case 'ShieldCheck':
      return <ShieldCheck className={className} />;
    case 'Paintbrush':
      return <Paintbrush className={className} />;
    case 'Wrench':
      return <Wrench className={className} />;
    case 'Package':
      return <Package className={className} />;
    case 'Trees':
      return <Trees className={className} />;
    case 'Laptop':
      return <Laptop className={className} />;
    default:
      return <Briefcase className={className} />;
  }
};

export const OFFICIAL_BRAND_LOGO =
  '/assets/aistudio/Logo_Comunit_rio_Jeita_Aqui_Breu_Branco_cc5c8578.png';

export const JeitakiLogo: React.FC<{
  darkText?: boolean;
  size?: 'sm' | 'md' | 'lg';
}> = ({ darkText = true, size = 'md' }) => {
  const imgSize =
    size === 'lg' ? 'w-12 h-12' : size === 'sm' ? 'w-8 h-8' : 'w-10 h-10';
  const textSize =
    size === 'lg' ? 'text-2xl' : size === 'sm' ? 'text-lg' : 'text-xl';

  return (
    <span className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0">
      <img
        src={OFFICIAL_BRAND_LOGO}
        alt="Logo Jeita Aqui Breu Branco"
        referrerPolicy="no-referrer"
        className={`${imgSize} rounded-xl bg-white p-0.5 object-contain shadow-xs shrink-0`}
      />
      <span
        className={`font-display ${textSize} font-extrabold tracking-tight`}
      >
        <span className={darkText ? 'text-[#0B4F24]' : 'text-white'}>
          Jeita
        </span>
        <span className="text-[#F59E0B]">Aqui</span>
      </span>
    </span>
  );
};

