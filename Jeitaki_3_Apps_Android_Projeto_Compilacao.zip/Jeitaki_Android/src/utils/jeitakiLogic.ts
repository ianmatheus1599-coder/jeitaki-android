import {
  Category,
  PlatformMetrics,
  ProfessionalProfile,
  Review,
  SearchFilters,
  ServiceRequest,
  ServiceRequestStatus,
} from '../types/jeitaki';

export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80) || 'perfil';
}

export function formatWhatsAppNumber(rawPhone: string): string {
  const digits = rawPhone.replace(/\D/g, '');
  if (!digits) return '';
  if (digits.startsWith('55') && digits.length >= 12 && digits.length <= 13) {
    return digits;
  }
  if (digits.length >= 10 && digits.length <= 11) {
    return `55${digits}`;
  }
  return digits;
}

export function isValidBrazilianPhone(rawPhone: string): boolean {
  const formatted = formatWhatsAppNumber(rawPhone);
  return /^55\d{10,11}$/.test(formatted);
}

export function buildWhatsAppQuoteUrl(params: {
  phone: string;
  serviceTitle: string;
  neighborhood: string;
  cityName?: string;
  description: string;
}): { url: string; message: string } {
  const city = params.cityName?.trim() || 'Breu Branco';
  const service = params.serviceTitle.trim();
  const neighborhood = params.neighborhood.trim();
  const desc = params.description.trim();

  const message = `Olá! Encontrei seu perfil no Jeitaki e gostaria de solicitar um orçamento para ${service}, no bairro ${neighborhood}, em ${city}. Descrição: ${desc}. Podemos conversar?`;
  const cleanPhone = formatWhatsAppNumber(params.phone);
  const encodedMessage = encodeURIComponent(message);
  const url = `https://wa.me/${cleanPhone}?text=${encodedMessage}`;

  return { url, message };
}

export function filterAndSortProfessionals(
  professionals: ProfessionalProfile[],
  filters: SearchFilters
): ProfessionalProfile[] {
  const normalizedQuery = (filters.query || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();

  const filtered = professionals.filter((prof) => {
    // Only approved profiles are visible in public searches
    if (prof.status !== 'approved') return false;

    // Exclude demo profiles unless includeDemo is explicitly enabled
    if (prof.isDemo && !filters.includeDemo) return false;

    // Filter by city
    if (filters.cityId && prof.cityId !== filters.cityId) return false;

    // Filter by availability if requested
    if (filters.onlyAvailable && !prof.isAvailable) return false;

    // Filter by category
    if (
      filters.categoryId &&
      filters.categoryId !== 'todas' &&
      !prof.categoryIds.includes(filters.categoryId)
    ) {
      return false;
    }

    // Filter by neighborhood
    if (
      filters.neighborhood &&
      filters.neighborhood !== 'todos' &&
      !prof.neighborhoods.some(
        (n) => n.toLowerCase() === filters.neighborhood!.toLowerCase()
      )
    ) {
      return false;
    }

    // Filter by maximum starting price (when professional informed price)
    if (
      typeof filters.maxPrice === 'number' &&
      filters.maxPrice > 0 &&
      typeof prof.startingPrice === 'number' &&
      prof.startingPrice > 0 &&
      prof.startingPrice > filters.maxPrice
    ) {
      return false;
    }

    // Filter by minimum rating only when sufficient reviews exist (ratingCount >= 1)
    if (typeof filters.minRating === 'number' && filters.minRating > 0) {
      if (prof.ratingCount < 1 || prof.ratingAvg < filters.minRating) {
        return false;
      }
    }

    // Filter by text query (name, commercialName, categories, services, description)
    if (normalizedQuery) {
      const searchable = [
        prof.name,
        prof.commercialName || '',
        prof.description,
        ...prof.categoryNames,
        ...prof.servicesOffered,
        ...prof.neighborhoods,
      ]
        .join(' ')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '');

      if (!searchable.includes(normalizedQuery)) {
        return false;
      }
    }

    return true;
  });

  // Sort by: 1) Availability, 2) Neighborhood match, 3) Featured plan, 4) Rating & Completed jobs
  return filtered.sort((a, b) => {
    if (a.isAvailable !== b.isAvailable) {
      return a.isAvailable ? -1 : 1;
    }
    if (filters.neighborhood && filters.neighborhood !== 'todos') {
      const aHasHood = a.neighborhoods.includes(filters.neighborhood);
      const bHasHood = b.neighborhoods.includes(filters.neighborhood);
      if (aHasHood !== bHasHood) return aHasHood ? -1 : 1;
    }
    if (a.featuredPlan !== b.featuredPlan) {
      return a.featuredPlan === 'destaque' ? -1 : 1;
    }
    if (b.ratingAvg !== a.ratingAvg) {
      return b.ratingAvg - a.ratingAvg;
    }
    return b.completedJobsCount - a.completedJobsCount;
  });
}

const OFFENSIVE_WORDS = [
  'idiota',
  'imbecil',
  'vagabundo',
  'lixo',
  'golpista',
  'ladrao',
  'ladrão',
  'otario',
  'otário',
];

export function validateReviewSubmission(params: {
  clientId: string;
  professionalUserId: string;
  request: ServiceRequest | undefined;
  existingReviews: Review[];
  rating: number;
  comment: string;
}): { valid: boolean; error?: string } {
  if (!params.clientId || params.clientId === 'visitante') {
    return { valid: false, error: 'Você precisa estar autenticado para avaliar um serviço.' };
  }
  if (!params.request) {
    return { valid: false, error: 'Solicitação de serviço não encontrada.' };
  }
  if (params.request.clientId !== params.clientId) {
    return { valid: false, error: 'Apenas o cliente titular da solicitação pode avaliar este atendimento.' };
  }
  if (params.clientId === params.professionalUserId) {
    return { valid: false, error: 'Autoavaliações não são permitidas na plataforma.' };
  }
  if (params.request.status !== 'concluida') {
    return { valid: false, error: 'A avaliação só é liberada após a conclusão confirmada do serviço.' };
  }
  const duplicate = params.existingReviews.some(
    (r) => r.requestId === params.request!.id
  );
  if (duplicate || params.request.reviewed) {
    return { valid: false, error: 'Este atendimento já foi avaliado anteriormente.' };
  }
  if (!Number.isFinite(params.rating) || params.rating < 1 || params.rating > 5) {
    return { valid: false, error: 'Selecione uma nota válida entre 1 e 5 estrelas.' };
  }
  const cleanComment = params.comment.trim();
  if (cleanComment.length < 5 || cleanComment.length > 600) {
    return { valid: false, error: 'O comentário deve ter entre 5 e 600 caracteres.' };
  }
  const lowerComment = cleanComment.toLowerCase();
  if (OFFENSIVE_WORDS.some((w) => lowerComment.includes(w))) {
    return {
      valid: false,
      error: 'Seu comentário contém termos ofensivos. Para relatar conduta inadequada, utilize a opção Denunciar.',
    };
  }
  return { valid: true };
}

export function calculatePlatformMetrics(
  requests: ServiceRequest[],
  professionals: ProfessionalProfile[],
  _categories: Category[],
  includeDemo = false
): PlatformMetrics {
  const realProfs = includeDemo
    ? professionals
    : professionals.filter((p) => !p.isDemo);

  const totalProfessionals = realProfs.length;
  const approvedProfessionals = realProfs.filter((p) => p.status === 'approved').length;
  const pendingProfessionals = realProfs.filter((p) => p.status === 'pending').length;

  const requestsCreated = requests.length;
  const whatsappClicks = requests.filter((r) => r.whatsappClicked).length;

  const quoteStatuses: ServiceRequestStatus[] = [
    'orcamento_enviado',
    'aceita',
    'em_andamento',
    'concluida',
  ];
  const hireStatuses: ServiceRequestStatus[] = [
    'aceita',
    'em_andamento',
    'concluida',
  ];

  const quotesSent = requests.filter((r) => quoteStatuses.includes(r.status)).length;
  const hiresConfirmed = requests.filter((r) => hireStatuses.includes(r.status)).length;
  const completedConfirmed = requests.filter((r) => r.status === 'concluida').length;

  return {
    totalProfessionals,
    approvedProfessionals,
    pendingProfessionals,
    requestsCreated,
    whatsappClicks,
    quotesSent,
    hiresConfirmed,
    completedConfirmed,
  };
}

export function exportToCSV(rows: Record<string, unknown>[]): string {
  if (!rows.length) return '';
  const headers = Object.keys(rows[0]);
  const escapeCell = (val: unknown): string => {
    const str = val === null || val === undefined ? '' : String(val);
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  const lines = [
    headers.join(','),
    ...rows.map((row) => headers.map((h) => escapeCell(row[h])).join(',')),
  ];
  return lines.join('\n');
}

export const STATUS_LABELS: Record<ServiceRequestStatus, string> = {
  nova: 'Nova solicitação',
  em_contato: 'Em contato',
  orcamento_enviado: 'Orçamento enviado',
  aceita: 'Proposta aceita',
  em_andamento: 'Serviço em andamento',
  concluida: 'Concluída',
  cancelada: 'Cancelada',
};
