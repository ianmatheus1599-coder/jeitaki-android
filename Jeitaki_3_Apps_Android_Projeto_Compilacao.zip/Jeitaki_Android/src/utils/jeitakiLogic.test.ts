import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildWhatsAppQuoteUrl,
  calculatePlatformMetrics,
  exportToCSV,
  filterAndSortProfessionals,
  formatWhatsAppNumber,
  isValidBrazilianPhone,
  validateReviewSubmission,
} from './jeitakiLogic';
import { ProfessionalProfile, ServiceRequest } from '../types/jeitaki';

test('formatWhatsAppNumber and isValidBrazilianPhone handle Pará area code 94 numbers', () => {
  assert.equal(formatWhatsAppNumber('(94) 99123-4567'), '5594991234567');
  assert.equal(formatWhatsAppNumber('5594981112222'), '5594981112222');
  assert.equal(isValidBrazilianPhone('(94) 99123-4567'), true);
  assert.equal(isValidBrazilianPhone('12345'), false);
});

test('buildWhatsAppQuoteUrl formats the exact Breu Branco contextualized message', () => {
  const { url, message } = buildWhatsAppQuoteUrl({
    phone: '(94) 99123-4567',
    serviceTitle: 'Troca de disjuntor',
    neighborhood: 'Centro',
    cityName: 'Breu Branco',
    description: 'Queda de energia no quadro principal',
  });

  assert.equal(
    message,
    'Olá! Encontrei seu perfil no Jeitaki e gostaria de solicitar um orçamento para Troca de disjuntor, no bairro Centro, em Breu Branco. Descrição: Queda de energia no quadro principal. Podemos conversar?'
  );
  assert.ok(url.startsWith('https://wa.me/5594991234567?text='));
  assert.ok(url.includes(encodeURIComponent('Troca de disjuntor')));
});

test('filterAndSortProfessionals excludes non-approved and demo profiles by default', () => {
  const baseProf: ProfessionalProfile = {
    id: 'prof-1',
    userId: 'user-1',
    name: 'Carlos Silva',
    slug: 'carlos-silva',
    cityId: 'breu-branco-pa',
    cityName: 'Breu Branco',
    neighborhoods: ['Centro', 'Bela Vista'],
    categoryIds: ['eletricista'],
    categoryNames: ['Eletricista'],
    servicesOffered: ['Instalação elétrica', 'Padrão Equatorial'],
    description: 'Eletricista residencial e comercial em Breu Branco.',
    workingHours: 'Seg a Sáb, 08h às 18h',
    attendanceTypes: ['domiciliar'],
    whatsappPhone: '5594991234567',
    publicContactConsent: true,
    status: 'approved',
    isAvailable: true,
    isDemo: false,
    featuredPlan: 'free',
    ratingAvg: 4.8,
    ratingCount: 5,
    completedJobsCount: 12,
    viewsCount: 40,
    whatsappClicksCount: 15,
    createdAt: '2026-11-01T10:00:00Z',
    updatedAt: '2026-11-01T10:00:00Z',
  };

  const pendingProf: ProfessionalProfile = {
    ...baseProf,
    id: 'prof-2',
    status: 'pending',
  };

  const demoProf: ProfessionalProfile = {
    ...baseProf,
    id: 'prof-3',
    isDemo: true,
  };

  const publicResults = filterAndSortProfessionals(
    [baseProf, pendingProf, demoProf],
    { cityId: 'breu-branco-pa' }
  );
  assert.equal(publicResults.length, 1);
  assert.equal(publicResults[0].id, 'prof-1');

  const withDemo = filterAndSortProfessionals(
    [baseProf, pendingProf, demoProf],
    { cityId: 'breu-branco-pa', includeDemo: true }
  );
  assert.equal(withDemo.length, 2);
});

test('validateReviewSubmission blocks self-reviews, uncompleted requests, and duplicates', () => {
  const completedRequest: ServiceRequest = {
    id: 'req-1',
    clientId: 'client-1',
    clientName: 'Maria Souza',
    clientPhone: '94991112222',
    professionalId: 'prof-1',
    professionalUserId: 'prof-user-1',
    professionalName: 'Carlos Silva',
    serviceTitle: 'Reparo elétrico',
    description: 'Troca de tomada',
    cityId: 'breu-branco-pa',
    cityName: 'Breu Branco',
    neighborhood: 'Centro',
    status: 'concluida',
    whatsappClicked: true,
    clientConfirmedCompletion: true,
    professionalConfirmedCompletion: true,
    reviewed: false,
    consentShared: true,
    createdAt: '2026-11-01T10:00:00Z',
    updatedAt: '2026-11-01T12:00:00Z',
  };

  // Self-review must fail
  const selfReview = validateReviewSubmission({
    clientId: 'prof-user-1',
    professionalUserId: 'prof-user-1',
    request: { ...completedRequest, clientId: 'prof-user-1' },
    existingReviews: [],
    rating: 5,
    comment: 'Excelente atendimento rápido',
  });
  assert.equal(selfReview.valid, false);

  // Uncompleted service must fail
  const uncompleted = validateReviewSubmission({
    clientId: 'client-1',
    professionalUserId: 'prof-user-1',
    request: { ...completedRequest, status: 'em_contato' },
    existingReviews: [],
    rating: 5,
    comment: 'Muito bom profissional',
  });
  assert.equal(uncompleted.valid, false);

  // Valid completed review passes
  const validReview = validateReviewSubmission({
    clientId: 'client-1',
    professionalUserId: 'prof-user-1',
    request: completedRequest,
    existingReviews: [],
    rating: 5,
    comment: 'Serviço impecável e pontual no bairro Centro!',
  });
  assert.equal(validReview.valid, true);
});

test('calculatePlatformMetrics strictly separates WhatsApp clicks from completed services', () => {
  const req1: ServiceRequest = {
    id: 'r1',
    clientId: 'c1',
    clientName: 'Ana',
    clientPhone: '94991112233',
    professionalId: 'p1',
    professionalUserId: 'u1',
    professionalName: 'Pedro',
    serviceTitle: 'Pintura',
    description: 'Pintura de sala',
    cityId: 'breu-branco-pa',
    cityName: 'Breu Branco',
    neighborhood: 'Novo Horizonte',
    status: 'em_contato',
    whatsappClicked: true,
    clientConfirmedCompletion: false,
    professionalConfirmedCompletion: false,
    reviewed: false,
    consentShared: true,
    createdAt: '2026-11-01T10:00:00Z',
    updatedAt: '2026-11-01T10:00:00Z',
  };

  const req2: ServiceRequest = {
    ...req1,
    id: 'r2',
    status: 'concluida',
    clientConfirmedCompletion: true,
    professionalConfirmedCompletion: true,
  };

  const metrics = calculatePlatformMetrics([req1, req2], [], []);
  assert.equal(metrics.requestsCreated, 2);
  assert.equal(metrics.whatsappClicks, 2);
  assert.equal(metrics.completedConfirmed, 1);
  assert.equal(metrics.hiresConfirmed, 1);
});

test('exportToCSV escapes commas and quotes properly', () => {
  const csv = exportToCSV([
    { nome: 'João, o Eletricista', cidade: 'Breu Branco', nota: 5 },
  ]);
  assert.equal(csv, 'nome,cidade,nota\n"João, o Eletricista",Breu Branco,5');
});
