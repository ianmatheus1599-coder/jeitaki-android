-- =============================================================================
-- JEITAKI — MIGRATION SQL COMPLETA E VERSIONADA (PostgreSQL / Supabase)
-- Cidade inicial: Breu Branco - PA, Brasil
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. CITIES
CREATE TABLE IF NOT EXISTS public.cities (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'PA',
  country TEXT NOT NULL DEFAULT 'Brasil',
  slug TEXT NOT NULL UNIQUE,
  is_active BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. NEIGHBORHOODS
CREATE TABLE IF NOT EXISTS public.neighborhoods (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  city_id TEXT NOT NULL REFERENCES public.cities(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(city_id, name)
);

-- 3. PROFILES (Clientes, Profissionais e Administradores)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'client' CHECK (role IN ('client', 'professional', 'admin')),
  city_id TEXT REFERENCES public.cities(id),
  neighborhood TEXT,
  lgpd_consent BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. ADMIN_USERS
CREATE TABLE IF NOT EXISTS public.admin_users (
  user_id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL DEFAULT 'super_admin' CHECK (role IN ('super_admin', 'moderator')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. CATEGORIES
CREATE TABLE IF NOT EXISTS public.categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  icon TEXT NOT NULL DEFAULT 'Briefcase',
  description TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  display_order INT NOT NULL DEFAULT 1,
  search_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. SERVICES
CREATE TABLE IF NOT EXISTS public.services (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  category_id TEXT NOT NULL REFERENCES public.categories(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. PROFESSIONAL_PROFILES
CREATE TABLE IF NOT EXISTS public.professional_profiles (
  id TEXT PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  commercial_name TEXT,
  slug TEXT NOT NULL UNIQUE,
  city_id TEXT NOT NULL REFERENCES public.cities(id),
  description TEXT NOT NULL,
  photo_url TEXT,
  working_hours TEXT NOT NULL,
  attendance_types TEXT[] NOT NULL DEFAULT ARRAY['domiciliar'],
  starting_price NUMERIC(10,2),
  whatsapp_phone TEXT NOT NULL,
  public_contact_consent BOOLEAN NOT NULL DEFAULT true,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'correction_needed', 'suspended')),
  verification_note TEXT,
  document_verified BOOLEAN NOT NULL DEFAULT false,
  is_available BOOLEAN NOT NULL DEFAULT true,
  is_demo BOOLEAN NOT NULL DEFAULT false,
  featured_plan TEXT NOT NULL DEFAULT 'free' CHECK (featured_plan IN ('free', 'destaque')),
  rating_avg NUMERIC(3,2) NOT NULL DEFAULT 0,
  rating_count INT NOT NULL DEFAULT 0,
  completed_jobs_count INT NOT NULL DEFAULT 0,
  views_count INT NOT NULL DEFAULT 0,
  whatsapp_clicks_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 8. PROFESSIONAL_SERVICES
CREATE TABLE IF NOT EXISTS public.professional_services (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  professional_id TEXT NOT NULL REFERENCES public.professional_profiles(id) ON DELETE CASCADE,
  category_id TEXT NOT NULL REFERENCES public.categories(id) ON DELETE CASCADE,
  service_title TEXT NOT NULL,
  starting_price NUMERIC(10,2),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9. PROFESSIONAL_SERVICE_AREAS
CREATE TABLE IF NOT EXISTS public.professional_service_areas (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  professional_id TEXT NOT NULL REFERENCES public.professional_profiles(id) ON DELETE CASCADE,
  city_id TEXT NOT NULL REFERENCES public.cities(id) ON DELETE CASCADE,
  neighborhood_name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(professional_id, city_id, neighborhood_name)
);

-- 10. PROFESSIONAL_PORTFOLIO
CREATE TABLE IF NOT EXISTS public.professional_portfolio (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  professional_id TEXT NOT NULL REFERENCES public.professional_profiles(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  caption TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. SERVICE_REQUESTS
CREATE TABLE IF NOT EXISTS public.service_requests (
  id TEXT PRIMARY KEY,
  client_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  client_name TEXT NOT NULL,
  client_phone TEXT NOT NULL,
  professional_id TEXT NOT NULL REFERENCES public.professional_profiles(id) ON DELETE CASCADE,
  category_id TEXT REFERENCES public.categories(id),
  service_title TEXT NOT NULL,
  description TEXT NOT NULL,
  city_id TEXT NOT NULL REFERENCES public.cities(id),
  neighborhood TEXT NOT NULL,
  preferred_date TEXT,
  photo_urls TEXT[] DEFAULT ARRAY[]::TEXT[],
  status TEXT NOT NULL DEFAULT 'nova' CHECK (status IN ('nova', 'em_contato', 'orcamento_enviado', 'aceita', 'em_andamento', 'concluida', 'cancelada')),
  whatsapp_clicked BOOLEAN NOT NULL DEFAULT false,
  client_confirmed_completion BOOLEAN NOT NULL DEFAULT false,
  professional_confirmed_completion BOOLEAN NOT NULL DEFAULT false,
  reviewed BOOLEAN NOT NULL DEFAULT false,
  consent_shared BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 12. SERVICE_REQUEST_STATUS_HISTORY
CREATE TABLE IF NOT EXISTS public.service_request_status_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  request_id TEXT NOT NULL REFERENCES public.service_requests(id) ON DELETE CASCADE,
  previous_status TEXT,
  new_status TEXT NOT NULL,
  changed_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 13. REVIEWS
CREATE TABLE IF NOT EXISTS public.reviews (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL UNIQUE REFERENCES public.service_requests(id) ON DELETE CASCADE,
  client_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  professional_id TEXT NOT NULL REFERENCES public.professional_profiles(id) ON DELETE CASCADE,
  rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('published', 'hidden', 'flagged')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 14. REPORTS (Denúncias, Suporte e Solicitações LGPD)
CREATE TABLE IF NOT EXISTS public.reports (
  id TEXT PRIMARY KEY,
  reporter_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  reporter_name TEXT,
  reporter_contact TEXT,
  target_type TEXT NOT NULL CHECK (target_type IN ('professional', 'review', 'lgpd_deletion', 'category_suggestion', 'support')),
  target_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  details TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'reviewed', 'resolved', 'dismissed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 15. BANNERS
CREATE TABLE IF NOT EXISTS public.banners (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  subtitle TEXT NOT NULL,
  cta_text TEXT NOT NULL DEFAULT 'Cadastrar Gratuitamente',
  cta_link TEXT NOT NULL DEFAULT '/seja-profissional',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 16. AUDIT_LOGS
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id TEXT PRIMARY KEY,
  admin_user_id UUID NOT NULL REFERENCES public.profiles(id),
  action TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT NOT NULL,
  details TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 17. ANALYTICS_EVENTS
CREATE TABLE IF NOT EXISTS public.analytics_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  event_type TEXT NOT NULL CHECK (event_type IN ('request_created', 'whatsapp_click', 'quote_sent', 'hire_confirmed', 'service_completed', 'category_search')),
  city_id TEXT REFERENCES public.cities(id),
  category_id TEXT REFERENCES public.categories(id),
  professional_id TEXT REFERENCES public.professional_profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ÍNDICES DE PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_prof_city_status ON public.professional_profiles(city_id, status);
CREATE INDEX IF NOT EXISTS idx_req_client ON public.service_requests(client_id);
CREATE INDEX IF NOT EXISTS idx_req_prof ON public.service_requests(professional_id);
CREATE INDEX IF NOT EXISTS idx_reviews_prof ON public.reviews(professional_id, status);

-- ROW LEVEL SECURITY (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.professional_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Perfis aprovados visíveis publicamente"
  ON public.professional_profiles FOR SELECT
  USING (status = 'approved' OR auth.uid() = user_id);

CREATE POLICY "Profissional edita apenas o próprio perfil"
  ON public.professional_profiles FOR UPDATE
  USING (auth.uid() = user_id);
