import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const ts = require('typescript');
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const scan=(dir)=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(x=>x.isDirectory()?scan(path.join(dir,x.name)): [path.join(dir,x.name)]);
const src=scan(path.join(root,'src')).filter(f=>/\.(?:ts|tsx)$/.test(f));
let errors=0;
for(const file of src){
  const source=fs.readFileSync(file,'utf8');
  const sf=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,file.endsWith('tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS);
  for(const d of sf.parseDiagnostics){
    const loc=sf.getLineAndCharacterOfPosition(d.start||0);
    console.error(`${path.relative(root,file)}:${loc.line+1}: ${ts.flattenDiagnosticMessageText(d.messageText,' ')}`);
    errors++;
  }
  for(const m of source.matchAll(/\bfrom\s*['"]([.@][^'"]+)['"]/g)){
    const spec=m[1];
    if(!spec.startsWith('./')&&!spec.startsWith('../')&&!spec.startsWith('@/'))continue;
    const p=spec.startsWith('@/')?path.join(root,spec.slice(2)):path.resolve(path.dirname(file),spec);
    const candidates=[p,p+'.ts',p+'.tsx',p+'.js',p+'.jsx',path.join(p,'index.ts'),path.join(p,'index.tsx'),p+'.json'];
    if(!candidates.some(c=>fs.existsSync(c)&&fs.statSync(c).isFile())){
      console.error(`${path.relative(root,file)}: import local inexistente: ${spec}`);errors++;
    }
  }
}
for(const f of ['firebase-applet-config.json','package.json','firebase-blueprint.json']){
  try{JSON.parse(fs.readFileSync(path.join(root,f),'utf8'));}catch(e){console.error(`${f}: JSON invalido: ${e.message}`);errors++;}
}
const config=JSON.parse(fs.readFileSync(path.join(root,'firebase-applet-config.json'),'utf8'));
if(!config.projectId||!config.appId||!config.apiKey) {console.error('Falta firebaseConfig');errors++;}
for(const v of ['cliente','profissional','admin']){
  for(const f of ['icon-only.png','icon-foreground.png','icon-background.png','splash.png','splash-dark.png']){
    if(!fs.existsSync(path.join(root,'assets/versions',v,f))){console.error('Asset ausente: '+v+'/'+f);errors++;}
  }
}
if(errors){console.error(`\n${errors} problema(s) encontrados.`);process.exit(1)}
console.log(`VALIDADO: ${src.length} arquivos TS/TSX, imports locais, Firebase web config e 3 conjuntos de icones. Esta nao e uma compilacao Android nem teste de banco.`);
