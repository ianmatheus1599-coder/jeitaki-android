# JEITAKI — "Precisou? Tem quem resolva!"

> **AVISO DE STATUS DA EXPORTAÇÃO ANDROID (06/11/2026):** há 3 versões separadas preparadas no código e uma automação de compilação em `.github/workflows/build-android-apks.yml`, porém os APKs ainda **não foram compilados nem instalados/testados**. A configuração Firebase incluída foi exportada do Google AI Studio e sua disponibilidade fora do AI Studio não foi confirmada. Leia [COMO_GERAR_OS_3_APKS.md](COMO_GERAR_OS_3_APKS.md).


Marketplace local de prestadores de serviços desenvolvido para **Breu Branco - PA, Brasil**, com arquitetura multi-cidades pronta para expansão a **Tucuruí**, **Goianésia do Pará** e outras localidades brasileiras.

## 1. Visão Geral da Arquitetura e Banco de Dados Conectado

O aplicativo **JEITAKI** já está conectado a um banco de dados real e persistente (**Google Cloud Firestore + Firebase Authentication**) provisionado diretamente no seu ambiente do Google AI Studio, protegido por regras de segurança no nível de documento/linha (`firestore.rules` validadas por ESLint e auditoria Red Team).

Além disso, incluímos em `supabase/migrations/001_initial_schema.sql` a migration SQL completa e versionada com as 17 entidades relacionais e políticas RLS caso você deseje espelhar ou migrar para um projeto externo no Supabase futuramente.

## 2. Como Autorizar sua Conta como Administrador (Procedimento Seguro)

O JEITAKI **não possui senha administrativa fixa no código** nem painel aberto ao público:
1. O seu e-mail proprietário (`ianmatheus1599@gmail.com`) já está autorizado nas regras de segurança do banco (`firestore.rules`) exigindo autenticação verificada (`email_verified == true`).
2. Abra o aplicativo e clique em **Entrar** -> **Continuar com Conta Google** usando o seu e-mail `ianmatheus1599@gmail.com`.
3. O botão **Admin** aparecerá imediatamente no cabeçalho superior e no menu inferior do celular (`/admin`).
4. No painel `/admin`, clique em **"Sincronizar Base no Banco"** para gravar todas as cidades, bairros de Breu Branco e as 12 categorias iniciais diretamente no banco.

## 3. Como Publicar na Internet (Link Público HTTPS)

1. No canto superior direito do **Google AI Studio**, clique no botão **Deploy / Share App** (Publicar / Compartilhar Aplicativo).
2. O AI Studio publica o aplicativo diretamente no **Google Cloud Run** com certificado **HTTPS automático**, manifesto PWA e Service Worker ativos.
3. Após a publicação, utilize o **Shared App URL** como o endereço público para divulgar no WhatsApp e gerar o QR Code no rodapé do aplicativo.
