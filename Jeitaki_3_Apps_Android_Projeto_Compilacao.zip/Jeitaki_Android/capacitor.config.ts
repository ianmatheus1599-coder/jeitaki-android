// Each release is built with VITE_APP_VARIANT=cliente|profissional|admin.
// One Firebase database is shared; every app has a unique Android package name.
const variant = process.env.VITE_APP_VARIANT || 'cliente';
const apps: Record<string, {appId:string; appName:string}> = {
  cliente: { appId:'br.com.jeitaki.breubranco.cliente', appName:'Jeitaki Cliente' },
  profissional: { appId:'br.com.jeitaki.breubranco.profissional', appName:'Jeitaki Profissional' },
  admin: { appId:'br.com.jeitaki.breubranco.admin', appName:'Jeitaki Admin' },
};
const app = apps[variant] || apps.cliente;
export default {
  ...app,
  webDir:'dist',
  server:{ androidScheme:'https' },
  plugins:{ SplashScreen:{launchShowDuration:1800,backgroundColor:'#0B4F24',showSpinner:false}},
};
