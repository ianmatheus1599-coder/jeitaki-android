import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig(() => {
  const variant = ['cliente', 'profissional', 'admin'].includes(process.env.VITE_APP_VARIANT || '')
    ? process.env.VITE_APP_VARIANT! : 'cliente';
  const label = { cliente: 'Jeitaki Cliente', profissional: 'Jeitaki Profissional', admin: 'Jeitaki Admin' }[variant];
  return {
    plugins: [
      react(),
      tailwindcss(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: [
          'icon.svg',
          'apple-touch-icon.png',
          'pwa-192x192.png',
          'pwa-512x512.png',
          'pwa-maskable-512x512.png',
          'assets/aistudio/Logo_Comunit_rio_Jeita_Aqui_Breu_Branco_cc5c8578.png',
        ],
        manifest: {
          id: '/' + variant,
          name: label + ' — Precisou? Tem quem resolva!',
          short_name: label,
          description: 'Encontre profissionais e prestadores de serviços em Breu Branco, Pará.',
          theme_color: '#0B4F24',
          background_color: '#F6FAF7',
          display: 'standalone',
          orientation: 'portrait',
          start_url: variant === 'cliente' ? '/' : variant === 'profissional' ? '/painel-profissional' : '/admin',
          scope: '/',
          lang: 'pt-BR',
          categories: ['business', 'lifestyle', 'utilities'],
          icons: [
            {
              src: '/icons/' + variant + '-192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/icons/' + variant + '-512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/icons/' + variant + '-512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
          globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
          navigateFallback: '/index.html',
          runtimeCaching: [
            {
              urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'google-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
            {
              urlPattern: /^https:\/\/fonts\.gstatic\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'gstatic-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
          ],
        },
        devOptions: {
          enabled: true,
          type: 'module',
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
