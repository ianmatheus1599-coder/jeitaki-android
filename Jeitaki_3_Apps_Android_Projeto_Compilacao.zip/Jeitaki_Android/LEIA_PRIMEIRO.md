# JEITAKI — 3 aplicativos Android a partir do mesmo projeto

**O código foi separado em três versões, mas os APKs ainda não foram compilados.** Este ZIP é o projeto-fonte pronto para tentar compilar por GitHub Actions. Não confunda o ZIP com três APKs instaláveis.

| Versão | Identificador Android | Função |
|---|---|---|
| Cliente | `br.com.jeitaki.breubranco.cliente` | Busca, profissionais, pedidos, avaliações, conta |
| Profissional | `br.com.jeitaki.breubranco.profissional` | Cadastro e painel de prestadores, pedidos recebidos, conta |
| Admin | `br.com.jeitaki.breubranco.admin` | Aprovação de profissionais, solicitações, categorias, relatórios |

Todas usam o **MESMO banco Firebase/Firestore**, a partir do arquivo `firebase-applet-config.json` que estava no seu export do Google AI Studio. Isso não cria outro banco nem confirma que seu acesso ao banco está liberado.

## Se quiser gerar os três APKs sem instalar programas no computador

1. Abra [GitHub — criar repositório](https://github.com/new). Faça login.
2. Nome do repositório: `jeitaki-tres-apks`, visibilidade **Private**, e clique **Create repository**. Não adicione README/License na criação.
3. No seu computador, **extraia** este ZIP. Na página do repositório, clique em **uploading an existing file** / **Add file → Upload files** e envie **todos os arquivos e pastas dentro da pasta extraída**, INCLUINDO a pasta `.github`. Um arquivo ZIP sozinho NÃO funciona (GitHub não extrai ZIP automaticamente).
4. Clique em **Commit changes**.
5. Entre na aba **Actions** e selecione **Gerar 3 APKs Jeitaki (Cliente, Profissional e Administrador)** → **Run workflow**. Caso não apareça o botão, abra uma das execuções automáticas do workflow no push inicial.
6. Se os três trabalhos ficarem verdes, abra a execução e role até **Artifacts**, no rodapé. Baixe `Jeitaki-cliente-APK`, `Jeitaki-profissional-APK` e `Jeitaki-admin-APK` (cada um virá como ZIP contendo `app-debug.apk`). Extraia cada arquivo e renomeie o APK, se desejar.
7. Os arquivos gerados são **APKs de teste** assinados com certificado de debug, e não são versões finais prontas para Play Store. Para atualização regular e distribuição pública, criar assinaturas de release estáveis e testar no Android.

**ATENÇÃO:** A conexão GitHub no ChatGPT, sozinha, não enviou o projeto nem executou Actions. É necessário seguir as etapas acima ou autorizar uma ferramenta que permita escrever no seu repositório.

## Firebase — etapas indispensáveis antes de usar com clientes reais

- O código ainda referencia o Firebase do export do Google AI Studio (nome do banco em `firebase-applet-config.json`). É obrigatório verificar se esse Firestore aceita chamadas dos aplicativos Android.
- Confira se **Firebase Authentication → Email/Password** está habilitado. Em APKs usa-se **e-mail e senha**, porque o login Google com popup Web não funciona corretamente dentro de WebViews Android. Para usar Google como login nativo precisaremos integrar SDK e fingerprint SHA-1 em outra etapa.
- As regras em `firestore.rules` **foram revisadas localmente**, mas não foram publicadas no Firebase por esta entrega. Antes de liberar usuários, aplique, teste e audite as regras no Firebase real.
- A conta administradora deve ser autorizada no Firebase. A restrição foi mantida conforme o projeto original do usuário, não é possível conferir se a autorização funciona sem testar login real.
- Publicar os APKs não publica um endereço web de apresentação/QR code. Endereço e hospedagem web são outra etapa.
- Revise os textos de privacidade e suporte, desative perfis de demonstração e revise os limites de uso e as políticas de dados antes de divulgar ao público.
- Dados de usuários ficam sujeitos à franquia de uso do Firebase/Firestore (que não é ilimitada). O App Store / Play Store tem etapas e custos próprios.

## O que foi alterado

- `src/appVariant.ts`: define se o executável é Cliente, Profissional ou Admin.
- `src/components/VariantNavbar.tsx`: navegação separada por aplicativo.
- `src/App.tsx`: três grupos de rotas independentes.
- `capacitor.config.ts`: identificadores e nomes Android próprios para cada variante.
- `.github/workflows/build-android-apks.yml`: automação de build que monta os três APKs.
- `assets/versions/`: ícones e telas de abertura separados para cada aplicação.
- `vite.config.ts`: manifesto PWA com nome e ícone por versão.
- `src/context/AppContext.tsx` e `firestore.rules`: atualização de fluxo de avaliação moderada, autenticação obrigatória para pedidos e revisão do perfil profissional alterado.

## Testes efetuados nesta entrega

- Verificação de sintaxe de 21 arquivos TS/TSX: sem erros de parsing.
- 6 testes unitários da lógica original com Node: passaram.
- Arquivos de configuração JSON e empacotamento: verificados.

**Não foi possível executar `npm install`, `vite build`, compilar `.apk` por Gradle nem testar Firebase real**, pois o ambiente de construção desta conversa não dispõe de Android SDK nem de rede de instalação de dependências. O workflow de GitHub é uma configuração pronta para TENTAR compilar, **não uma compilação comprovada**. Caso o workflow falhe, envie a captura do erro para corrigirmos o código específico.
