# JEITAKI — Gerar 3 APKs Android

**Estado:** projeto de compilação preparado e verificado estaticamente; **nenhum APK foi compilado neste ambiente**. O projeto precisa de um executor Android (GitHub Actions ou computador com Android SDK e dependências baixadas).

## O que está incluído

| Versão | Pacote Android exclusivo | Objetivo |
|---|---|---|
| Jeitaki Cliente | `br.com.jeitaki.breubranco.cliente` | Busca, profissionais, orçamentos e solicitações |
| Jeitaki Profissional | `br.com.jeitaki.breubranco.profissional` | Cadastro, atendimento e painel do profissional |
| Jeitaki Admin | `br.com.jeitaki.breubranco.admin` | Administração e moderação (acesso só de administrador autenticado) |

As versões compartilham a mesma configuração Firebase incluída no arquivo `firebase-applet-config.json`, exportado originalmente do Google AI Studio. O arquivo tem **identificadores web públicos**, não credenciais de serviço. O acesso às coleções do Firebase depende de permissões reais e das regras implantadas naquele projeto; a presença do arquivo não prova que o banco esteja liberado para os APKs. **Não conceda acesso administrativo com base apenas em ter instalado o APK Admin.**

## Compilação automatizada gratuita (sujeita à franquia do GitHub)

1. Entre em https://github.com/new com a conta GitHub conectada ao ChatGPT.
2. Crie repositório chamado `jeitaki-android` (preferencialmente **Private**), com `main` como branch principal, e marque **Add a README** para inicializar a branch.
3. Volte ao ChatGPT e diga **"Criei o repositório jeitaki-android"**. O assistente pode então tentar transferir o código usando a integração GitHub — desde que o conector tenha acesso a esse repositório. Se não houver permissão, será necessária autorização de acesso ao repositório.
4. Depois que os arquivos do projeto estiverem publicados, abra `Actions` no repositório, selecione **Jeitaki - Gerar os 3 APKs Android** e clique **Run workflow**. Um `push` na `main` também aciona a compilação.
5. Quando a compilação terminar com sucesso, clique na execução e baixe os três arquivos na seção **Artifacts**: `Jeitaki-cliente-APK`, `Jeitaki-profissional-APK` e `Jeitaki-admin-APK`. Cada ZIP de artifact contém um `Jeitaki-<versão>-teste.apk` verdadeiro.

A automação faz `npm install`, `npm run build`, prepara o Capacitor 8, executa Gradle `assembleDebug` e disponibiliza três APKs de **teste**, assinados com uma chave de debug. Essa assinatura não serve para publicação na Play Store ou atualizações estáveis em produção. Para distribuir aos usuários finais, depois será necessário gerar builds de release com chave de assinatura própria e seguir os requisitos de distribuição.

## Banco de dados, login e autorização

- Os APKs são aplicativos Android que utilizam WebView via Capacitor. Eles não criam um Firebase novo; usam os dados do arquivo de configuração da exportação AI Studio.
- Verifique no projeto Firebase se Firestore e Authentication estão ativos. Firestore **não é automaticamente provisionado** só por gerar o APK.
- Se alterar as regras de acesso, valide as consultas e escreva regras na console/CLI para o banco correto (o arquivo de configuração menciona um banco não padrão).
- Login por Google popup em WebView pode não ser suportado; a interface Android oferece login por e-mail e senha, que precisa estar habilitado no Firebase Authentication. **Não use um aplicativo Admin sem login e autorização reais.**
- A identidade do administrador e as regras `firestore.rules` originais precisam ser auditadas antes de expor o banco a usuários reais.

## Testes que ainda precisam ser executados

- Compilar os três APKs em GitHub Actions.
- Instalar cada APK em aparelho Android e confirmar abertura, autenticação, navegação e funcionamento do botão de WhatsApp.
- Validar banco real, regras Firestore e isolamento de dados entre cliente, profissional e admin com contas distintas.
- Verificar o fluxo de aprovação de profissionais e solicitações reais.

## Compilação local para técnico (opcional)

Com Node 22, JDK 21 e SDK Android já instalados:

```bash
npm install
npm run check:static
export VITE_APP_VARIANT=cliente  # ou profissional, ou admin
npm run build
cp assets/versions/$VITE_APP_VARIANT/*.png assets/ # os nomes devem permanecer originais
npx cap add android
npx cap sync android
npx capacitor-assets generate --android
cd android && ./gradlew assembleDebug
```

Para cada versão, deve-se remover e regenerar a pasta `android` (ou usar checkout limpo) para garantir nome, identificador e ícones correspondentes. O arquivo final estará em `android/app/build/outputs/apk/debug/app-debug.apk`.
